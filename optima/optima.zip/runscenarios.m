%% RUNSCENARIOS
% Run the scenarios defined by makescenarios.m
% Version 2013may05

function scenarios=runscenarios(data,partnerships,transitions,equations,parametersets,vec2structtable,whichscenarios,nlabs)

disp('Runscenarios:')
tic

disp('  Setting options...')
% options.turnofftransmission=2013;

nscenarios=length(whichscenarios); % Count how many scenarios there are to run
scenarios=struct; % Initalize scenarios output
nsets=length(parametersets); % Number of simulation sets

for scen=1:nscenarios
    thisscen=whichscenarios(scen);
    tmp1=cell(nsets,1); % Save full parameter set
    tmp2=cell(nsets,1); % Save simulation output
    if nlabs>1
        parfor s=1:nsets % Ugly to duplicate code but the only way to handle par/normal for loop switch
            paramstruct=convertparams('vec2struct',vec2structtable,parametersets{s});
            [pg,pm]=setupmodel(data,partnerships,transitions,equations,paramstruct,thisscen); % 0 for don't runscenario: that could get confusing!
            pm=equilibrium(pg,pm); % Set up initial population sizes
            sim=model(pg,pm,1,options);
            tmp1{s}=pm;
            tmp2{s}=sim;
            fprintf('  %i/%i of %i/%i\n',s,nsets,scen,nscenarios);
        end
    else
        for s=1:nsets
            paramstruct=convertparams('vec2struct',vec2structtable,parametersets{s});
            [pg,pm]=setupmodel(data,partnerships,transitions,equations,paramstruct,thisscen); % 0 for don't runscenario: that could get confusing!
            pm=equilibrium(pg,pm); % Set up initial population sizes
            sim=model(pg,pm,1,options);
            tmp1{s}=pm;
            tmp2{s}=sim;
            fprintf('  %i/%i of %i/%i\n',s,nsets,scen,nscenarios);
        end
    end
    scenarios(scen).name=tmp1{1}.name; % Save the label of this scenario
    scenarios(scen).parametersets=tmp1; % Save parameter sets
    scenarios(scen).simsets=tmp2; % Save output
end

fprintf('Runscenarios: '), toc
end
