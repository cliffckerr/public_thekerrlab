%% PREVTOOL
% This code calculates the epidemic dynamics. It consists of five modules,
% which by default are run in the following order:
% 1. Load data. The Excel spreadsheet is read in and converted into a data
% structure.
% 2. Initialize parameters. This sets the behavioral parameter values to
% their optimal values but does not take epidemiology into account at all.
% 3. Fit parameters. This takes into account both behavioral and
% epidemiological data and tries to find the best fit.
% 4. Make posteriors. This takes the best-fit parameters and calculates the
% distribution of parameters that provide "reasonable" fits.
% 5. Run scenarios. This will run each counterfactual for purposes of past
% evaluation or return-on-investment analysis.
% Version: 2013jul17

clc; disp('W E L C O M E   T O   P R E V T O O L   2 . 0')
starttime=clock; % Calculate how long everything takes
opt=setoptions(); % Set global options
warning('off','MATLAB:load:variableNotFound') % Don't worry if some variables can't be loaded; that's normal


%% Handle data and priors
if opt.nlabs>1 && matlabpool('size')~=opt.nlabs, matlabpool(opt.nlabs), end % Start Matlabpool if not open already
if opt.pseudorandom>=0, rng(opt.pseudorandom), randomization=opt.pseudorandom; else randomization=randi(1e5,1); end % Reset random number generator

% Initialize the file by saving the name of the spreadsheet used to create it
if ~exist(opt.matfilename,'file')
    spreadsheetname=opt.spreadsheetname; % Can't save a field of a structure separately
    save(opt.matfilename,'spreadsheetname') % Initialize file so that append commands work
    fprintf('Saved spreadsheet name to %s.\n',opt.matfilename)
end

% Load the data from the spreadsheet
if opt.do.loaddata==1 || opt.do.runeverything
    [data,realdata,partnerships,transitions,equations]=loaddata(opt.spreadsheetname); % Real data has negative values removed
    save(opt.matfilename,'data','realdata','partnerships','transitions','equations','-append');
    fprintf('Saved data to %s.\n',opt.matfilename)
else
    load(opt.matfilename,'data','realdata','partnerships','transitions','equations');
end

% Create parameter structure based on behavioral data
if opt.do.createpars==1 || opt.do.runeverything
    parstruct=createpars(data,partnerships,transitions,equations,opt.create,opt.nlabs);
    save(opt.matfilename,'parstruct','-append');
    fprintf('Saved initial priors to %s.\n',opt.matfilename)
else
    load(opt.matfilename,'parstruct');
end

%% Handle posteriors
if opt.do.makeposteriors==1 || opt.do.runeverything
    tmpresults=struct; % Initialize structure for storing temporary results
    
    % Run in parallel -- because of the way parfor loops work, this code has to be duplicated
    if opt.nlabs>1 % Yes, being run in parallel
        parfor i=1:opt.nlabs % Create each 
            RandStream.setGlobalStream(RandStream.create('mt19937ar','Seed',i+randomization)); % Set random number generate for this stream
            [parametersets, simsets, fiterrors, vec2structtable]=makeposteriors(data,parstruct,equations,opt.post,i,1); %#ok<PFBNS> % 1 is for the scenario to run
            tmpresults(i).parametersets=parametersets; tmpresults(i).simsets=simsets; tmpresults(i).fiterrors=fiterrors; tmpresults(i).vec2structtable=vec2structtable;
        end
    else
        RandStream.setGlobalStream(RandStream.create('mt19937ar','Seed',randomization));
        [tmpresults(1).parametersets, tmpresults(1).simsets, tmpresults(1).fiterrors, tmpresults(1).vec2structtable]=makeposteriors(data,parstruct,equations,opt.post,1,1);
    end
    
    % Save results into final form
    vec2structtable=tmpresults(1).vec2structtable; % Save conversion from vector to structure
    parametersets={}; simsets={}; fiterrors=[];
    for i=1:opt.nlabs
        parametersets=[parametersets(:); tmpresults(i).parametersets(:)];
        simsets=[simsets(:);tmpresults(i).simsets(:)];
        fiterrors=[fiterrors; tmpresults(i).fiterrors]; %#ok<*AGROW> This is small so it doesn't matter that it isn't efficient.
    end
    
    save(opt.matfilename,'parametersets','simsets','fiterrors','vec2structtable','-append')
else
    load(opt.matfilename,'parametersets','simsets','fiterrors','vec2structtable');
end



%% Handle scenarios
if opt.do.runscenarios==1 || opt.do.runeverything
    scenarios=runscenarios(data,equations,parametersets,vec2structtable,whichscenarios,opt.nlabs);
    save(opt.matfilename,'scenarios','-append');
    fprintf('Saved scenarios to %s.\n',opt.matfilename)
else
    load(opt.matfilename,'scenarios');
end

%% Handle results
if opt.do.results==1 || opt.do.runeverything
    results
end


%% Finish up
lastupdated=datestr(clock); % Just as a reminder of when things were last run
save(opt.matfilename,'lastupdated','-append')
fprintf('\nOutput saved to %s.\n',opt.matfilename)
fprintf('Prevtool: %i s elapsed.\n',round(etime(clock,starttime)))
disp('D O N E')