%% RMNAN
% This function automates the process of NaN removal. For a vector, it
% simply returns X(~isnan(X)). For a matrix, it performs
% X(any(isnan(X),2),:) = [].
%
% Usage:
%
% X = rmnan(X)
%
% Version: 2012feb11

function varargout=rmnan(varargin)

if nargin==1
    X=varargin{1};
    if length(X)==numel(X) % If only one non-singleton dimension
        X=X(~isnan(X));
    elseif ndims(X)==2
        X(any(isnan(X),2),:)=[];
    else
        error('This function cannot currently handle more than 2 dimensions!')
    end
    varargout{1}=X; % Set output
else
    args=cell(nargin,1); for i=1:nargin, args{i}=varargin{i}; end % Store arguments
    for i=1:nargin % Make sure everything's a column vector
        if length(args{i})~=numel(args{i}), error('When using multiple arguments, you must supply vectors.'), end
        if i>1, if length(args{i})~=length(args{i-1}), error('Vectors must all be the same length'), end, end
        args{i}=reshape(args{i},length(args{i}),1);
    end 
    X=zeros(length(args{1}),nargin); for i=1:nargin, X(:,i)=args{i}; end % Store data
    X(any(isnan(X),2),:)=[]; % Remove NaNs
    nout=min(nargin,nargout); varargout=cell(nout,1); % Calculate how many output arguments to have -- minimum of input and output
    for i=1:nargin, varargout{i}=reshape(X(:,i),[],1); end % Split back into vectors
end

end