%% PLOTSCENARIOS
% This code plots the scenarios. graphfig is too hard to work with.
% Version: 2012nov12

%% Preliminary stuff
whattoplot=1:5; % 1=prevalence, 2=incidence, 3=diagnoses, 4=number on treatment, 5=deaths
whichpops=1:7; % Which populations to use; 1-7 for Vietnam
quantiles=[0.25 0.5 0.75]; % What uncertainty range to use
plotuncertainties=0; % Whether or not to plot uncertainties
plotdiffs=1; % Whether to plot differences from baseline
usebest=0; % Whether to use best curve instead of median

fields={'prevalence','incidence','diagnoses','numontreat1','hivdeaths'};
plotnames={'Prevalence','Number of New Infections','Number of Diagnoses','Number on ART','Number of HIV-Related Deaths'};
plotlabels={'Prevalence (%)','Number of people (''000)','Number of people (''000)','Number people (''000)','Number of people (''000)'};
factors=[100 1/1000 1/1000 1/1000 1/1000]; % Multiplicative factors
if plotdiffs==1, for c=1:length(fields), plotnames{c}=['Change in ' plotnames{c}]; end, end % Rename plots if plotting difference

disp('Loading data...')
matfilename='wblifetime.mat';
description='Vietnam';
d=load(matfilename);
pg=d.data.general;

disp('Setting parameters...')
nscens=length(d.scenarios);
npops=length(whichpops);
npts=d.data.general.npts;
pts=d.data.general.pts;
ntrials=length(d.simsets);
scennames=cell(nscens,1); for s=1:nscens, scennames{s}=d.scenarios(s).name; end % Collect scenario names


for c=1:length(whattoplot)
    this=whattoplot(c);
    %% Gather data
    alldata=zeros(nscens,ntrials,npops,npts); % Initialize array
    sumdata=zeros(nscens,ntrials,npts); % Initialize array
    mindata=zeros(nscens,npts); % Initialize array
    meddata=zeros(nscens,npts); % Initialize array
    maxdata=zeros(nscens,npts); % Initialize array
    
    
    disp('Gathering scenarios...')
    choice=fields{this};
    for s=1:nscens
        for t=1:ntrials
            alldata(s,t,:,:)=d.scenarios(s).simsets{t}.(choice)(whichpops,:);
        end
    end
    
    disp('Summing over populations...')
    for s=1:nscens
        fprintf('  %i/%i\n',s,nscens)
        for t=1:ntrials
            if this==1 % Handle prevalence separately
                for p=1:npts
                    popsizes=d.scenarios(s).simsets{t}.pm.populationsize(:,p);
                    sumdata(s,t,p)=sum(squeeze(alldata(s,t,:,p)).*popsizes)/sum(popsizes);
                end
            else % Everything except prevalence
                sumdata(s,t,:)=sum(alldata(s,t,:,:),3);
            end
        end
    end
    
    disp('Calculating statistics...')
    for s=1:nscens
        mindata(s,:)=quantile(sumdata(s,:,:),quantiles(1),2);
        if usebest==1
            meddata(s,:)=sumdata(s,1,:);
        else
            meddata(s,:)=quantile(sumdata(s,:,:),quantiles(2),2);
        end
        maxdata(s,:)=quantile(sumdata(s,:,:),quantiles(3),2);
    end
    
    
    
    %% Plot
    disp('Plotting...')
    popcolors=vectocolor(1:nscens);
    figure('position',[500 500 600 400]); hold on
    if plotdiffs, baseline=meddata(1,:); else baseline=0; end % Whether or not to subtract baseline
    for s=1:nscens
        if plotuncertainties==1, errorshade(pts,[],factors(this)*(mindata(s,:)-baseline),factors(this)*(maxdata(s,:)-baseline),popcolors(s,:)); end
        plot(pts,factors(this)*(meddata(s,:)-baseline),'color',popcolors(s,:),'linewidth',2)
    end
    xlabel('Year')
    ylabel(plotlabels{this})
    title(plotnames{this})
    currentlims=ylim; if currentlims(1)>0, ylim([0 currentlims(2)]); end % Make 0 minimum if >0
    legend(scennames,'location','best')
    box on
end
disp('Done.')