%% CREATEPARS
% This code takes the data and uses it to come up with the prior parameter
% distributions.
%
% The parameters are described on three levels, called "phylum/phyla",
% "family/families", and "value/values". Parameter phyla are things like
% "condom usage probability for regular acts", or condomprobregular.
% Families are the dimensions along with these phyla are parameterized, for
% example, "base", "pop1", "pop2", etc., and "time". Values are the actual
% values each family takes on. There is one value per family for each
% family except time, which has pg.ncontrolyears values. For a constant,
% there is one phylum (e.g. transinjecting), one family (always called
% "base"), and one value. In contrast, in a simulation with 10 population
% groups and 2 control years, the phylum "condomprobregular" has 12
% families (base, time, and pop1 to pop10) and 13 values (one for each
% family except for time, which has two values). [Eventually, each "value"
% will actually be a vector, either of quantiles or of random numbers
% generated from the quantiles via flexidist.]
%
% Version: 2013may15

function parstruct=createpars(data,partnerships,transitions,equations,opt,nlabs) % Need to change from quantiles to values

disp('Creating model parameters...'); tic

if ~exist('data','var'), load dataeq; end % Load data from disk -- WARNING, need to revisit
pg=data.general;
parstruct.partnerships=partnerships; % Save partnerships and transitions to parstruct
parstruct.transitions=transitions;


nphyla=length(equations.phyla);
tmp=cell(nphyla,1);
if nlabs==1 % Not parallel: normal for-loop
    for phylum=1:nphyla
        thisphylum=equations.phyla{phylum};
        phylumdata=data.(thisphylum); %#ok<*PFBNS>
        families=equations.bayespars.(thisphylum);
        if ~isempty(families) % No equation if it's empty
            tmp{phylum}=performfit(pg,data,equations,thisphylum,phylumdata,families,opt);
        end
    end
else % Run in parallel
    parfor phylum=1:nphyla
        thisphylum=equations.phyla{phylum};
        phylumdata=data.(thisphylum); %#ok<*PFBNS>
        families=equations.bayespars.(thisphylum);
        if ~isempty(families) % No equation if it's empty
            tmp{phylum}=performfit(pg,data,equations,thisphylum,phylumdata,families,opt);
        end
    end
end

for phylum=find(~cellfun('isempty',tmp))'; % Only loop over the ones that have equations -- note, need to use cellfun(), can't call isempty() directly!
    parstruct.(equations.phyla{phylum})=tmp{phylum}; % Convert from cell array to structure
end



fprintf('Makepriors: '), toc
end


function thisparfit=performfit(pg,data,equations,thisphylum,phylumdata,families,opt)
% Do the actual fit: the if statement determines whether you need to do optimization or not.
if numel(families)==1 && numel(families{1})==1  % It's a single row constant: this makes life simpler, just get posterior directly
    limits=phylumdata([1 pg.nquantiles],1,1);
    assert(strcmp('base',families{1}{1}),'A constant parameter should be called ''base''!'); % It should always be 'base'
    thisparfit.base=compactify(cksqueeze(phylumdata(3,:,:)),limits,1); % See below for the inverse equation
else % No? Do optimization on the parameters
    if numel(families)>0 % But only if the equation exists
        fprintf('  Working on %s...\n',thisphylum)
        fprintf('count\t|\tcurrent\t|\tchange\n')
        
        % Find nonzero rows, columns
        if size(phylumdata,3)>1 % It's a time series
            for row=1:size(phylumdata,2); % Loop over each row
                thistimeseries=phylumdata(3,row,:); % Pull out the numbers for this row
                if any(~isnan(thistimeseries)) % Skip over entries that are blank
                    phylumdata(:,row,1)  =phylumdata(:,row,find(~isnan(thistimeseries),1,'first')); % Find first nonzero entry and copy it to the beginning of the array
                    phylumdata(:,row,end)=phylumdata(:,row,find(~isnan(thistimeseries),1,'last'  )); % Find last nonzero entry and copy it to the end of the array
                end
            end
        end
        mediandata=cksqueeze(phylumdata(3,:,:));
        
        % Initialize parameters
        nrows=size(equations.indices.(thisphylum),2); % Don't try modeling things that don't have an equation
        ncols=size(phylumdata,3);
        rawpredictions.(thisphylum)=nan(nrows,ncols);
        predictions.(thisphylum)=nan(nrows,ncols);
        families=unique([equations.bayespars.(thisphylum){:}]); % Find out what parameters are used to model this data
        nfamilies=length(families);
        
        % Make correspondence between vector index and parameter index: 1 to 1
        % except for time vectors, which need nctrlyears points. Ugly code, I'm
        % sorry.
        startcount=1;
        valuestofamilies=cell(nfamilies,1);
        for family=1:nfamilies
            thisfamily=families{family};
            if strfind(thisfamily,'time')
                endcount=startcount+pg.ncontrolyears-1;
            else
                endcount=startcount;
            end
            valuestofamilies{family}=startcount:endcount;
            startcount=endcount+1;
        end
        nvalues=endcount; % How many meta-parameters there are. Equal to the number of parameter types, except for time trend parameters.
        
        if all(isnan(mediandata(:)))
            warning('makepriors:nodata','Not a single datum entered for %s! Assuming zero',thisphylum)
            return
        end
        
        % Come up with an initial guess for the value
        limits=data.(thisphylum)([1 pg.nquantiles],1,1);
        value=mean(rmnan(mediandata(:))); % Since numterms terms multiplied together to give it. WARNING, may die if lowerlimit>0 since the root might be below the minimum value
        numterms=length(equations.bayespars.(thisphylum){1});
        valuesvector=(ones(nvalues,1)*compactify(value,limits,1))/numterms; % Initialize this parameter with the best-guess value
        
        
        % WARNING: can like way improve this! Do it by row rather than by the whole
        % matrix. Get lots of different estimates for each parameter, and then find
        % the average, and set that value. For things that change with every row, it
        % will be a very accurate estimate.
        for family=1:nfamilies
            if strfind(families{family},'time')
                if opt.timetrends==0, valuesvector(valuestofamilies{family})=mean(valuesvector(valuestofamilies{family})); end % If time trends are disabled, set all time parameters to mean value
                eval([families{family} '=controlval(pg.controlyears,valuesvector(valuestofamilies{family}),pg.datayears);']);
            else % Not time -- normal parameter
                eval([families{family} '=' num2str(valuesvector(valuestofamilies{family})) ';'])
            end
        end
        
        % Make predictions
        for row=1:nrows
            eval(['rawpredictions.' equations.indices.(thisphylum){row} '=' equations.bayeseqns.(thisphylum){row} ';'])
        end
        predictions.(thisphylum)=compactify(rawpredictions.(thisphylum),limits,0); % Force it to lie within the range
        
        
        %% Run fitting algorithm
        % Do weighting
        [datarows,datacols]=find(~isnan(mediandata));
        ndatapts=length(datarows);
        
        selected=zeros(nvalues,1); % For counting which parameters got selected and how many times
        count=0; % For counting iterations
        errorhistory=nan(opt.maxiters,1); % For storing errors as they improve
        terminate=0; % Handles spacebar termination of the loop

        
        stepsize=0.1; % Default step size
        stepincrease=1.1; % Amount by which to increase step size if error is smaller than current
        stepdecrease=0.5; % Amount by which to decrease step size if both errors are larger than current
        learnrate=10; % Amount by which to increase the probability of that parameter being selected
        punishrate=0.5; % Amount by which to punish parameters that don't improve with either increases or decreases
        priorvec=valuesvector; % Kludgy rename
        nparams=length(priorvec);
        stepsizes=stepsize*ones(nparams,1);
        probabilities=ones(nparams,1);
        currenterror=modelfun(priorvec,nfamilies,families,pg,nrows,equations,valuestofamilies,predictions,phylumdata,datarows,datacols,ndatapts,thisphylum,limits,opt,0);
        while 1
            cumprobs=cumsum(probabilities)/sum(probabilities);
            thisparam=find(cumprobs>rand,1);
            priorvecl=priorvec;
            priorvecu=priorvec;
            priorvecl(thisparam)=priorvecl(thisparam)-logical(count)*stepsizes(thisparam); % The logical(count) thing makes the first trial unchanged for plotting
            priorvecu(thisparam)=priorvecu(thisparam)+logical(count)*stepsizes(thisparam);
            [errorl,priorvecl]=modelfun(priorvecl,nfamilies,families,pg,nrows,equations,valuestofamilies,predictions,phylumdata,datarows,datacols,ndatapts,thisphylum,limits,opt,0); % Return priorvec as output argument since time trends might've gotten flattened out
            [erroru,priorvecu]=modelfun(priorvecu,nfamilies,families,pg,nrows,equations,valuestofamilies,predictions,phylumdata,datarows,datacols,ndatapts,thisphylum,limits,opt,0);
            
            if errorl<currenterror && erroru>=currenterror % Lowering it improved it
                probabilities(thisparam)=probabilities(thisparam)+learnrate*(currenterror/errorl-1); % Increase probability of picking this parameter again
                stepsizes(thisparam)=stepsizes(thisparam)*stepincrease; % Increase size of step for next time
                currenterror=errorl; % Reset current error
                priorvec=priorvecl; % Reset current parameters
            elseif erroru<currenterror && errorl>=currenterror % Raising it improved it
                probabilities(thisparam)=probabilities(thisparam)+learnrate*(currenterror/erroru-1); % Increase probability of picking this parameter again
                stepsizes(thisparam)=stepsizes(thisparam)*stepincrease; % Increase size of step for next time
                currenterror=erroru; % Reset current error
                priorvec=priorvecu; % Reset current parameters
            elseif erroru<currenterror && errorl<currenterror % They both did! Mountain
                if errorl<erroru
                    currenterror=errorl; % Reset current error
                    priorvec=priorvecl; % Reset current parameters
                elseif erroru<errorl
                    currenterror=erroru; % Reset current error
                    priorvec=priorvecu; % Reset current parameters
                end
            elseif erroru>=currenterror && errorl>=currenterror % Neither did: Valley
                stepsizes(thisparam)=stepsizes(thisparam)*stepdecrease;
                probabilities(thisparam)=probabilities(thisparam)*punishrate;
            else
                error('Something impossible happened')
            end
            
            selected(thisparam)=selected(thisparam)+1;
            
            count=count+1;
            errorhistory(count)=currenterror;
            
            if ~mod(count-1,opt.showprogress)
                if count>opt.errorlookback
                    errorthen=errorhistory(count-opt.errorlookback);
                    improvement=errorthen/currenterror-1;
                else
                    improvement=Inf;
                end
                fprintf('%i\t|\t%0.2f\t|\t%0.1f\n',[count currenterror improvement])
                if opt.verbose==1, disp([selected priorvec probabilities stepsizes]), end
            end
            if count>opt.maxiters || improvement<opt.minimprovement || currenterror<opt.minerror, break, end % Stop if done enough iterations
            if terminate==1, break, end
        end
        
        if opt.interactive
            [~]=modelfun(priorvec,nfamilies,families,pg,nrows,equations,valuestofamilies,predictions,phylumdata,datarows,datacols,ndatapts,thisphylum,limits,opt,opt.interactive);
        end
        
        
        for family=1:nfamilies
            eval(['thisparfit.' families{family} '=[' num2str(priorvec(valuestofamilies{family})') '];'])
        end
        
    end
end


end









function [err,valuesvector]=modelfun(valuesvector,nfamilies,families,pg,nrows,equations,valuestofamilies,predictions,phylumdata,datarows,datacols,ndatapts,thisphylum,limits,opt,interactive)

% Calculate values
for family=1:nfamilies
    if strfind(families{family},'time')
        if opt.timetrends==0, valuesvector(valuestofamilies{family})=mean(valuesvector(valuestofamilies{family})); end % If time trends are disabled, set all time parameters to mean value
        eval([families{family} '=controlval(pg.controlyears,valuesvector(valuestofamilies{family}),pg.datayears);']);
    else % Not time -- normal parameter
        eval([families{family} '=' num2str(valuesvector(valuestofamilies{family})) ';'])
    end
end

% Make predictions
for row=1:nrows
    try
        eval(['predictions.' equations.indices.(thisphylum){row} '=' equations.bayeseqns.(thisphylum){row} ';'])
    catch exception
        fprintf('\n\nProblem with %s\n\n',thisphylum)
        rethrow(exception)
    end
end
predictions.(thisphylum)=compactify(predictions.(thisphylum),limits,0); % Force it to lie within the range

% Compare to data
err=zeros(ndatapts,1);
for pt=1:ndatapts
    if ndims(phylumdata)>2
        dataquantiles=cksqueeze(phylumdata(:,datarows(pt),datacols(pt)));
        prediction=predictions.(thisphylum)(datarows(pt),datacols(pt));
    else
        dataquantiles=phylumdata(:,datacols(pt)); % Shouldn't this be datarows? You'd think so, but Matlab is weird about matrices.
        prediction=predictions.(thisphylum)(datacols(pt));
    end
    if ~all(dataquantiles==sort(dataquantiles)), warning('makepriors:monotonic','Data for %s not monotonic (%s).',thisphylum,num2str(dataquantiles')), end %#ok<*SPWRN>
    assert(dataquantiles(end)==max(dataquantiles),sprintf(['Hard upper limit too low: timestep too large? \n' num2str(dataquantiles')]))
    
    err(pt)=finderror(prediction,pg.quantiles,dataquantiles);
end


if interactive
    disp(' ')
    tmpdata=zeros(ndatapts,1);
    tmppred=zeros(ndatapts,1);
    if ndims(phylumdata)>2
        for pt=1:ndatapts
            tmpdata(pt)=phylumdata(3,datarows(pt),datacols(pt));
            tmppred(pt)=predictions.(thisphylum)(datarows(pt),datacols(pt));
        end
    else
        for pt=1:ndatapts
            tmpdata(pt)=phylumdata(3,datacols(pt));
            tmppred(pt)=predictions.(thisphylum)(datacols(pt));
        end
    end
    
    clf
    disp([tmpdata tmppred err])
    semilogy(tmpdata,'ko-','linewidth',2); hold on
    semilogy(tmppred,'bs-','linewidth',2);
    semilogy(err,    'rs:','linewidth',2);
    legend('Data','Prediction','Error')
    keyboard
end

err=mean(sqrt(err)); % Trying sqrt() to de-emphasize enormous errors


end

