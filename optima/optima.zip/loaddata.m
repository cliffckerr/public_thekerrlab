%% LOADDATA
% This program reads in the spreadsheet. At the moment it's hard-coded,
% although another possibility would be to use strfind commands to read in
% the parameter names.
% Version: 2013may15

function [data,realdata,partnerships,transitions,equations]=loaddata(filename)
disp('Loading data...'), tic

%% Define parameters
disp('  Loading general parameters...')
[numbers,txt]=xlsread(filename,'General');

% Read in quantities from the spreadsheet
pg.fullpopnames=txt(3,2:end); % pg stands for "parameters general" -- 2 since first column is label
pg.popnames=txt(4,2:end);
pg.popinuse=rmnan(numbers(1,:)); % Need rmnan since reads in all 14 columns
pg.popismale=rmnan(numbers(2,:));
pg.simyears=rmnan(numbers(4,:));
pg.datayears=rmnan(numbers(5,:));
pg.timestep=rmnan(numbers(6,:));
pg.maxrate=rmnan(numbers(8,:));
pg.ncd4=rmnan(numbers(9,:));
pg.cd4aids=rmnan(numbers(10,:));
pg.totalnumpops=rmnan(numbers(11,:));
pg.defaulterr=rmnan(numbers(12,:));
pg.controlyears=rmnan(numbers(13,:));
pg.quantiles=rmnan(numbers(14,:));

% Calculate derived quantities
pg.datayears=pg.datayears(1):pg.datayears(2);
pg.ndatayears=length(pg.datayears);
pg.simyears=pg.simyears(1):pg.simyears(2);
pg.pts=pg.simyears(1):pg.timestep:pg.simyears(end);
pg.npts=length(pg.pts);
pg.ncontrolyears=length(pg.controlyears);
pg.nquantiles=length(pg.quantiles);
pg.npops=sum(pg.popinuse);

% Define indices for each health category
pg.nstates=1+5*pg.ncd4; % Total number of health states; 1 is for susceptible
pg.sus=1;
pg.undiag=2+pg.ncd4*0:pg.ncd4*1+1;
pg.diag  =2+pg.ncd4*1:pg.ncd4*2+1;
pg.treat1=2+pg.ncd4*2:pg.ncd4*3+1;
pg.fail  =2+pg.ncd4*3:pg.ncd4*4+1;
pg.treat2=2+pg.ncd4*4:pg.ncd4*5+1;

% Save
data.general=pg;


%% Read in remaining sheets
%               Parameter name          Array dimensions                                 Sheet           Range        Scale  Limits       Modeled
readtimeseries('populationsize',        [pg.nquantiles,pg.totalnumpops, pg.ndatayears], 'Demographics', 'C2:AS29' ,   1000,  [0,1e9],        1)

readtimeseries('hivprevalence',         [pg.nquantiles,pg.totalnumpops, pg.ndatayears], 'Prevalences',  'C2:AS29' ,   1/100, [0,1],          0)
readtimeseries('stiprevalence',         [pg.nquantiles,pg.totalnumpops, pg.ndatayears], 'Prevalences',  'C31:AS58',   1/100, [0,1],          1)

readtimeseries('testingrate',           [pg.nquantiles,pg.totalnumpops, pg.ndatayears], 'TestTreat',    'C2:AS29',    1/100, [0,pg.maxrate], 1)
readtimeseries('testingrateaids',       [pg.nquantiles,1,               pg.ndatayears], 'TestTreat',    'C31:AS32',   1/100, [0,pg.maxrate], 1)
readtimeseries('treatment1rate',        [pg.nquantiles,pg.ncd4,         pg.ndatayears], 'TestTreat',    'C34:AS41',   1/100, [0,pg.maxrate], 1)
readtimeseries('treatment2rate',        [pg.nquantiles,1,               pg.ndatayears], 'TestTreat',    'C42:AS43',   1/100, [0,pg.maxrate], 1)
readtimeseries('birthrate',             [pg.nquantiles,1,               pg.ndatayears], 'TestTreat',    'C45:AS46',   1,     [0,12/9],       1) % If every woman is constantly pregnant for 9 months...
readtimeseries('pmtctrate',             [pg.nquantiles,1,               pg.ndatayears], 'TestTreat',    'C47:AS48',   1/100, [0,pg.maxrate], 1)
readtimeseries('numdiagnoses',          [pg.nquantiles,1,               pg.ndatayears], 'TestTreat',    'C50:AS51',   1,     [0,1e9],        0)
readtimeseries('numtreatment',          [pg.nquantiles,2,               pg.ndatayears], 'TestTreat',    'C53:AS56',   1,     [0,1e9],        0)

readtimeseries('numactsregular',        [pg.nquantiles,pg.totalnumpops, pg.ndatayears], 'SexBehavior',  'C2:AS29',    1,     [0,1e3],        1)
readtimeseries('numactscasual',         [pg.nquantiles,pg.totalnumpops, pg.ndatayears], 'SexBehavior',  'C31:AS58',   1,     [0,1e3],        1)
readtimeseries('numactsother',          [pg.nquantiles,pg.totalnumpops, pg.ndatayears], 'SexBehavior',  'C60:AS87',   1,     [0,1e4],        1)
readtimeseries('condomprobregular',     [pg.nquantiles,pg.totalnumpops, pg.ndatayears], 'SexBehavior',  'C89:AS116',  1/100, [0,1],          1)
readtimeseries('condomprobcasual',      [pg.nquantiles,pg.totalnumpops, pg.ndatayears], 'SexBehavior',  'C118:AS145', 1/100, [0,1],          1)
readtimeseries('condomprobother',       [pg.nquantiles,pg.totalnumpops, pg.ndatayears], 'SexBehavior',  'C147:AS174', 1/100, [0,1],          1)
readtimeseries('circumcisionprob',      [pg.nquantiles,pg.totalnumpops, pg.ndatayears], 'SexBehavior',  'C176:AS203', 1/100, [0,1],          1)

readtimeseries('numinjections',         [pg.nquantiles,pg.totalnumpops, pg.ndatayears], 'DrugBehavior', 'C2:AS29',    1,     [0,1e4],        1)
readtimeseries('syringesharingprob',    [pg.nquantiles,1,               pg.ndatayears], 'DrugBehavior', 'C31:AS32',   1/100, [0,1],          1)
readtimeseries('methadoneprob',         [pg.nquantiles,1,               pg.ndatayears], 'DrugBehavior', 'C33:AS34',   1/100, [0,1],          1)
readtimeseries('syringecleaningprob',   [pg.nquantiles,1,               pg.ndatayears], 'DrugBehavior', 'C35:AS36',   1/100, [0,1],          1)

readconstants('initialhivprevalence',   [pg.nquantiles,pg.totalnumpops],                'Prevalences',  'C2:AS29' ,    1/100, [0,1]) % Reread to get initial prevalence values rather than a time series
readconstants('transheteroinsertive',   [pg.nquantiles,1],                              'Constants',    'C2:E3',      1/100, [0,1])
readconstants('transheteroreceptive',   [pg.nquantiles,1],                              'Constants',    'C4:E5',      1/100, [0,1])
readconstants('transhomoinsertive',     [pg.nquantiles,1],                              'Constants',    'C6:E7',      1/100, [0,1])
readconstants('transhomoreceptive',     [pg.nquantiles,1],                              'Constants',    'C8:E9',      1/100, [0,1])
readconstants('transinjecting',         [pg.nquantiles,1],                              'Constants',    'C10:E11',    1/100, [0,1])
readconstants('transmtct',              [pg.nquantiles,1],                              'Constants',    'C12:E13',    1/100, [0,1])
readconstants('transbycd4',             [pg.nquantiles,pg.ncd4],                        'Constants',    'C15:E22',    1,     [0,100]) % A scale factor, not a probability
readconstants('transontreatment',       [pg.nquantiles,1],                              'Constants',    'C23:E24',    1,     [0,1])
readconstants('progressionrate',        [pg.nquantiles,pg.ncd4-1],                      'Constants',    'C26:E31',    1/100, [0,pg.maxrate])
readconstants('recoveryrate',           [pg.nquantiles,pg.ncd4-1],                      'Constants',    'C33:E38',    1/100, [0,pg.maxrate])
readconstants('deathbackground',        [pg.nquantiles,1],                              'Constants',    'C40:E41',    1/100, [0,pg.maxrate])
readconstants('deathinjecting',         [pg.nquantiles,1],                              'Constants',    'C42:E43',    1/100, [0,pg.maxrate])
readconstants('deathhiv',               [pg.nquantiles,pg.ncd4],                        'Constants',    'C44:E51',    1/100, [0,pg.maxrate])
readconstants('deathtreatment',         [pg.nquantiles,1],                              'Constants',    'C52:E53',    1/100, [0,pg.maxrate])
readconstants('treatment1failurerate',  [pg.nquantiles,1],                              'Constants',    'C55:E56',    1/100, [0,pg.maxrate])
readconstants('treatment2failurerate',  [pg.nquantiles,1],                              'Constants',    'C57:E58',    1/100, [0,pg.maxrate])
readconstants('condomefficacy',         [pg.nquantiles,1],                              'Constants',    'C60:E61',    1/100, [0,1])
readconstants('circumcisionefficacy',   [pg.nquantiles,1],                              'Constants',    'C62:E63',    1/100, [0,1])
readconstants('diagnosisefficacy',      [pg.nquantiles,1],                              'Constants',    'C64:E65',    1/100, [0,1])
readconstants('stitransincrease',       [pg.nquantiles,1],                              'Constants',    'C66:E67',    1/100, [0,100]) % A scale factor, not a probability
readconstants('syringecleaningefficacy',[pg.nquantiles,1],                              'Constants',    'C68:E69',    1/100, [0,1])
readconstants('methadoneefficacy',      [pg.nquantiles,1],                              'Constants',    'C70:E71',    1/100, [0,1])
readconstants('pmtctefficacy',          [pg.nquantiles,1],                              'Constants',    'C72:E73',    1/100, [0,1])
readconstants('treatriskcompensation',  [pg.nquantiles,1],                              'Constants',    'C74:E75',    1/100, [0,100]) % A scale factor, not a probability

readpartnerships('regular',             [pg.totalnumpops,pg.totalnumpops],              'Partnerships', 'B3:O16')
readpartnerships('casual',              [pg.totalnumpops,pg.totalnumpops],              'Partnerships', 'B20:O33')
readpartnerships('other',               [pg.totalnumpops,pg.totalnumpops],              'Partnerships', 'B37:O50')
readpartnerships('injecting',           [pg.totalnumpops,pg.totalnumpops],              'Partnerships', 'B54:O67')

readtransitions('asym',                 [pg.totalnumpops,pg.totalnumpops],              'Transitions',  'B3:O16',     1/100)
readtransitions('sym',                  [pg.totalnumpops,pg.totalnumpops],              'Transitions',  'B20:O33',    1/100)

readeconomics('HCcostsHIVtesting',      [pg.nquantiles,1,pg.ndatayears],                'Economics',    'D2:AS3',     1, [0,1e3])
readeconomics('CD4500',                 [pg.nquantiles,1,pg.ndatayears],                'Economics',    'D4:AS5',     1, [0,1e5])
readeconomics('CD4350500',              [pg.nquantiles,1,pg.ndatayears],                'Economics',    'D6:AS7',     1, [0,1e5])
readeconomics('CD4200350',              [pg.nquantiles,1,pg.ndatayears],                'Economics',    'D8:AS9',     1, [0,1e5])
readeconomics('CD4200',                 [pg.nquantiles,1,pg.ndatayears],                'Economics',    'D10:AS11',   1, [0,1e5])
readeconomics('ART1',                   [pg.nquantiles,1,pg.ndatayears],                'Economics',    'D12:AS13',   1, [0,1e5])
readeconomics('ART2',                   [pg.nquantiles,1,pg.ndatayears],                'Economics',    'D14:AS15',   1, [0,1e5])
readeconomics('uninfIDU',               [pg.nquantiles,1],                              'Economics',    'D18:E19',    1, [0,1])
readeconomics('untreatCD4500',          [pg.nquantiles,1],                              'Economics',    'D20:E21',    1, [0,1])
readeconomics('untreatCD4350500',       [pg.nquantiles,1],                              'Economics',    'D22:E23',    1, [0,1])
readeconomics('untreatCD4200350',       [pg.nquantiles,1],                              'Economics',    'D24:E25',    1, [0,1])
readeconomics('untreatCD4200',          [pg.nquantiles,1],                              'Economics',    'D26:E27',    1, [0,1])
readeconomics('treatCD4500',            [pg.nquantiles,1],                              'Economics',    'D28:E29',    1, [0,1])
readeconomics('treatCD4350500',         [pg.nquantiles,1],                              'Economics',    'D30:E31',    1, [0,1])
readeconomics('treatCD4200350',         [pg.nquantiles,1],                              'Economics',    'D32:E33',    1, [0,1])
readeconomics('treatCD4200',            [pg.nquantiles,1],                              'Economics',    'D34:E35',    1, [0,1])

equations.phyla=fieldnames(equations.model); % Save the list of parameter names that are fitted by the model

%% Functions

% Function for handling everything except partnerships and constants
    function readtimeseries(name,fieldsize,sheetname,range,normalization,hardlimits,modeled)
        fprintf('  Loading %s: %s...\n',sheetname,name)
        arrayrows=fieldsize(2); % For the model, need the number of actual pops, not the total theoretical number of populations
        separatepops=(arrayrows==pg.totalnumpops); % Flag for whether this parameter is separated by populations
        [~,~,rawexceldata]=xlsread(filename,sheetname,range);
        eqnarray=rawexceldata(1:2:end,end); % Pull out the full equation array
        if separatepops % Trim unused populations 
            eqnarray=eqnarray(logical(pg.popinuse));
        end
        rawexceldata=cell2mat(rawexceldata(:,1:end-1))*normalization; % end-1 since last column is for the equation
        rawexceldata=rawexceldata(:,1+2*(pg.datayears(1)-2000):2*(pg.datayears(end)-1999)); % Trim to match pg.datayears -- WARNING, assumes spreadsheet starts in 2000
        data.(name)=nan(fieldsize);
        data.(name)(1,:,:)=hardlimits(1);
        data.(name)(2,:,:)=rawexceldata(2:2:end,  2:2:end);
        data.(name)(3,:,:)=rawexceldata(1:2:end-1,1:2:end-1);
        data.(name)(4,:,:)=rawexceldata(1:2:end-1,2:2:end);
        data.(name)(5,:,:)=hardlimits(2);
        data.(name)=fixmissingerrors(data.(name),fieldsize); % Add errors if none filled in
        
         % Remove unused populations
        if separatepops 
            data.(name)=data.(name)(:,logical(pg.popinuse),:); 
            arrayrows=pg.npops;
        end
        realdata.(name)=data.(name); % Copy data array...
        realdata.(name)(realdata.(name)<0)=NaN; % Keep only data points >=0, to allow users to enter negative data into the spreadsheet for assumptions
        data.(name)=abs(data.(name)); % Convert remaining data to its absolute value, since no parameters can have negative values
        if modeled
            makeequationstrings(name,eqnarray) % Turn final column into equations
            equations.model.(name)=-inf*ones(arrayrows,pg.npts); % Initialize model parameters array, ignoring quantiles, and using correct number of time points
        end 
    end


% Function for handling partnerships
    function readpartnerships(name,fieldsize,sheetname,range)
        fprintf('  Loading %s: %s...\n',sheetname,name)
        [~,~,rawexceldata]=xlsread(filename,sheetname,range);
        partnerships.(name)=nan(fieldsize);
        partnerships.(name)(:,:)=cell2mat(rawexceldata); % This will crash if the sizes don't match, which is a feature, not a bug
        partnerships.(name)=partnerships.(name)(logical(pg.popinuse),logical(pg.popinuse)); % Trim unused populations
    end

% Function for handling population transitions -- same as partnerships
    function readtransitions(name,fieldsize,sheetname,range,normalization)
        fprintf('  Loading %s: %s...\n',sheetname,name)
        [~,~,rawexceldata]=xlsread(filename,sheetname,range);
        transitions.(name)=nan(fieldsize);
        transitions.(name)(:,:)=cell2mat(rawexceldata)*normalization; % This will crash if the sizes don't match, which is a feature, not a bug
        transitions.(name)=transitions.(name)(logical(pg.popinuse),logical(pg.popinuse)); % Trim unused populations
    end

% Function for handling constants
    function readconstants(name,fieldsize,sheetname,range,normalization,hardlimits)
        fprintf('  Loading %s: %s...\n',sheetname,name)
        arrayrows=fieldsize(2); % For the model, need the number of actual pops, not the total theoretical number of populations
        separatepops=(arrayrows==pg.totalnumpops); % Flag for whether this parameter is separated by populations
        [~,~,rawexceldata]=xlsread(filename,sheetname,range);
        eqnarray=rawexceldata(1:2:end,end); % Pull out the full equation array
        if separatepops % Trim unused populations 
            eqnarray=eqnarray(logical(pg.popinuse));
        end
        rawexceldata=cell2mat(rawexceldata(:,1:end-1))*normalization; % end-1 since last column is for the equation
        data.(name)=nan(fieldsize);
        data.(name)(1,:)=hardlimits(1);
        data.(name)(2,:)=rawexceldata(2:2:end,  2)';
        data.(name)(3,:)=rawexceldata(1:2:end-1,1)';
        data.(name)(4,:)=rawexceldata(1:2:end-1,2)';
        data.(name)(5,:)=hardlimits(2);
        data.(name)=fixmissingerrors(data.(name),fieldsize); % Add errors if none filled in
        if separatepops 
            data.(name)=data.(name)(:,logical(pg.popinuse),:); % Remove unused populations   
            arrayrows=pg.npops;
        end
        realdata.(name)=data.(name); % Copy data array...
        realdata.(name)(realdata.(name)<0)=NaN; % Keep only data points >=0, to allow users to enter negative data into the spreadsheet for assumptions
        data.(name)=abs(data.(name)); % Convert remaining data to its absolute value, since no parameters can have negative values
        makeequationstrings(name,eqnarray) % Turn final column into equations
        equations.model.(name)=zeros(arrayrows,1); % Initialize model parameters array, ignoring quantiles
    end


% Function for handling economic data
    function readeconomics(name,fieldsize,sheetname,range,normalization,hardlimits)
        fprintf('  Loading %s: %s...\n',sheetname,name)
        [~,~,rawexceldata]=xlsread(filename,sheetname,range);
        rawexceldata=cell2mat(rawexceldata(:,1:end))*normalization;
        if length(fieldsize)>2 % It's a time parameter: trim the years
            rawexceldata=rawexceldata(:,1+2*(pg.datayears(1)-2000):2*(pg.datayears(end)-1999)); % Trim to match pg.datayears -- WARNING, assumes spreadsheet starts in 2000
        end
        if length(fieldsize)==2 % It's a constant
            data.econ.(name)=nan(fieldsize);
            data.econ.(name)(1,:)=hardlimits(1);
            data.econ.(name)(2,:)=rawexceldata(2:2:end,  2)';
            data.econ.(name)(3,:)=rawexceldata(1:2:end-1,1)';
            data.econ.(name)(4,:)=rawexceldata(1:2:end-1,2)';
            data.econ.(name)(5,:)=hardlimits(2);
        else % It's a time series
            data.econ.(name)=nan(fieldsize);
            data.econ.(name)(1,:,:)=hardlimits(1);
            data.econ.(name)(2,:,:)=rawexceldata(2:2:end,  2:2:end);
            data.econ.(name)(3,:,:)=rawexceldata(1:2:end-1,1:2:end-1);
            data.econ.(name)(4,:,:)=rawexceldata(1:2:end-1,2:2:end);
            data.econ.(name)(5,:,:)=hardlimits(2);
        end
    end

% Function for checking if limits are missing, and if so fill them in automatically
        function fixeddata=fixmissingerrors(origdata,arraysize)
            if numel(arraysize)==2, arraysize(3)=1; end % Add third dimension if it doesn't exist -- slightly kludgy
            fixeddata=origdata; % Copy array
            for pop=1:arraysize(2) % Loop over population
                for t=1:arraysize(3) % Loop over time, if it exists
                    if ~isnan(origdata(3,pop,t)); % Datum has been entered
                        if isnan(origdata(2,pop,t)) % Lower quantile is missing
                            fixeddata(2,pop,t)=-origdata(3,pop,t)/pg.defaulterr; % Use the default error for this parameter; minus since not real data
                        end
                        if isnan(origdata(4,pop,t)) % Upper quantile is missing
                            if origdata(3,pop,t)*pg.defaulterr<origdata(5,pop,t) % If multiplying by the default error doesn't exceed the upper limit, do so
                                fixeddata(4,pop,t)=-origdata(3,pop,t)*pg.defaulterr;
                            else
                                fixeddata(4,pop,t)=-((pg.defaulterr-1)*origdata(5,pop,t)+origdata(3,pop,t))/pg.defaulterr; % If it does, use this method
                            end
                        end
                    end
                end
            end
        end

% Function for creating equation strings
    function makeequationstrings(name,eqnarray)
        equations.bayeseqns.(name)=cell(0);
        equations.bayespars.(name)=cell(0);
        nrows=size(eqnarray,1);
        for row=1:nrows
            if ischar(eqnarray{row}) % Don't create equations if there's no equation listed
                equations.indices.(name){row}=[name '(' num2str(row) ',:)']; % Create a string of the form condomprob(3,:)
                equations.bayeseqns.(name){row}=eqnarray{row}; % Store equation
                equations.bayespars.(name){row}=regexp(eqnarray{row},'+','split'); % Split into components
            end
        end
    end

fprintf('Loaddata: '), toc
end
