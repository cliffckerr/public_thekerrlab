%% PLOTALLOCATIONS
% This code plots and analyzes the spending allocation scenarios.
% Version: 2013apr21

%% Load allocations data
dosave=1;
plotfig1=1;
plotfig2=1;
plotfig3=1;
basename='./vietnam/revision/vietnam-apr21-dxrisk'; % Where to save figures to
datafile='./vietnam/revision/vietnam-apr21.mat';
logisticfile='./vietnam/revision/newlogspend.mat';
tmp=load('./vietnam/revision/vietnam-apr21-dxrisk-allocation.mat');
allocations=tmp.allocations;
allocation=[5994680	2707129	1056975	7591711	656930	777716	4676980]; % From vietnam/revision/spending.xlsx
nallocations=size(allocations,1)+2; % +1 for 0 spend, +1 for current spend
allocations=[0*allocation; allocations(1:10,:); allocation; allocations(11:end,:)]+1; % +1 so all groups show up when plotting
optimal=11; % Index of optimal allocation
current=12; % Index of current allocation


%% Set parameters
startyear=2013; % Year to start scenarios/start counting infections
endyear=2020; % Year to stop counting invections



%% Load data to do optimal allocation on, plus logistic curve data
disp('Loading data...')
d=load(datafile); % Load Prevtool output
tmp=load(logisticfile); s=tmp.s; % Load logistic curves
s.newiec.cond=[0.15 0.25 0 5e6]; % New values based on those that Quang sent me 21/04/2013 -- wrong format so can't read in automatically -- WARNING KLUDGY


%% Run preliminary model
disp('Running...')
[pg,pm]=setupmodel(d.data,d.equations,d.parstruct,1);
pm=equilibrium(pg,pm);

%% Specify programs
% Programs -- see Lei's email 2012nov20
disp('Specifying programs....')
scenpoints=find(pg.pts>=startyear);
costpoints=find(pg.pts>=startyear & pg.pts<=endyear);
LRP=1; FSW=2; MSM=3; NSP=4; MMT=5; STI=6; VCT=7; % Make it so I can refer to programs by their names, e.g. VCT = 7
logistic=@(x,p) (p(2)-p(1))./(1+exp(-(x-p(3))/p(4)))+p(1); % Define a simple logistic equation; see below for a more general formula


%% Calculate current infections based on spend
disp('Calculating...')
infections=zeros(nallocations,pg.npops); % -2 is if LRPs are missing
results=struct;
origpm=pm;
options.turnofftransmission=-2021; % Only run model until this date; the minus sign aborts
parfor a=1:nallocations
    allocation=allocations(a,:);
    pm=origpm;
    
    if a~=current % WARNING -- KLUDGY -- don't modify current spend because the allocation doesn't match perfectly
        % 1. Low-risk population condom usage
        for p=1:pg.npops, pm.condomprobregular(p,scenpoints)=logistic(allocation(LRP),s.iec.cond); end % General/regular acts population condom rate
        
        % 2. Female sex worker and client condom usage
        for p=[3 5], pm.condomprobother(3,scenpoints)=logistic(allocation(FSW),s.fsw.comdfsw); end % DFSW (3) and client (5) condom rate
        for p=[3 5], pm.condomprobcasual(3,scenpoints)=logistic(allocation(FSW),s.fsw.casdfsw); end % DFSW (3) and client (5) condom rate
        pm.condomprobother(4,scenpoints)=logistic(allocation(FSW),s.fsw.comifsw); % IFSW (4) condom rate
        pm.condomprobcasual(4,scenpoints)=logistic(allocation(FSW),s.fsw.casifsw); % IFSW (4) condom rate
        
        % 3. MSM condom usage
        pm.condomprobcasual(6,scenpoints)=logistic(allocation(MSM),s.msm.cas); % IFSW condom rate
        pm.condomprobother(6,scenpoints)=logistic(allocation(MSM),s.msm.com); % IFSW condom rate
        
        % 4. NSP
        pm.syringesharingprob(scenpoints)=logistic(allocation(NSP),s.nsp); % Syringe sharing
        
        % 5. MMT
        pm.methadoneprob(scenpoints)=logistic(allocation(MMT),s.mmt); % Methadone
        
        % 6. STI
        pm.stiprevalence(3,scenpoints)=logistic(allocation(STI),s.sti.dfsw); % STI prevalence
        pm.stiprevalence(4,scenpoints)=logistic(allocation(STI),s.sti.ifsw); % STI prevalence
        pm.stiprevalence(6,scenpoints)=logistic(allocation(STI),s.sti.msm); % STI prevalence
        
        % 7. VCT
        pm.testingrate(1,scenpoints)=logistic(allocation(VCT),s.vct.lrp); % LRM testing rate
        pm.testingrate(2,scenpoints)=logistic(allocation(VCT),s.vct.lrp); % LRF testing rate
        pm.testingrate(3,scenpoints)=logistic(allocation(VCT),s.vct.dfsw); % DFSW testing rate
        pm.testingrate(4,scenpoints)=logistic(allocation(VCT),s.vct.ifsw); % IFSW testing rate
        pm.testingrate(5,scenpoints)=logistic(allocation(VCT),s.vct.lrp); % CSW testing rate -- estimate
        pm.testingrate(6,scenpoints)=logistic(allocation(VCT),s.vct.msm); % MSM testing rate
        pm.testingrate(7,scenpoints)=logistic(allocation(VCT),s.vct.idu); % IDU testing rate
    end
    
    [~,pm]=setupmodel(d.data,d.equations,pm,1);
    pm=equilibrium(pg,pm);
    sim=model(pg,pm,1,options);
    results(a).sim=sim;
    infections(a,:)=sum(sim.incidence(:,costpoints)*pg.timestep,2); % Exclude LRP with 3:end instead of :
    percentcomplete(a,nallocations)
end


%% Calculate statistics

matching=find(ismember(pg.pts,startyear:endyear)); % Find year end points
for a=1:nallocations
    results(a).cuminfections=sum(sum(results(a).sim.incidence(:,matching))); % “Cumulative number of new infections”
    results(a).cumnewtreat1=sum(sum(results(a).sim.newtreat1(:,matching))); % “Cumulative number of people starting 1st line ART”
    results(a).cumnewtreat2=sum(sum(results(a).sim.newtreat2(:,matching))); % “Cumulative number of people starting 2nd ART”
    results(a).cumdeaths=sum(sum(results(a).sim.hivdeaths(:,matching))); % “Cumulative number of deaths”
end




%% Plotting
disp('Plotting...')
programnames={'LRP: Condom %','FSW: Condom %','MSM: Condom %','NSP: Sharing %','MMT: % on treatment','STI: % prevalence','VCT: Testing %/year'};
xlabels={'No spending','10% budget','20% budget','30% budget','40% budget','50% budget','60% budget','70% budget','80% budget','90% budget','100% budget','Current','120% budget','150% budget','200% budget'};

%% Plot "Fig. 7"
if plotfig1==1
    figure('position',[100 100 800 350])
    
    cksubplot([2 1],[1 1],[80 80],[0 0],[0 -5])
    pie(allocations(current,:))
    title('Current','fontweight','bold')
    
    cksubplot([2 1],[2 1],[80 80],[0 0],[15 -5])
    pie(allocations(optimal,:))
    title('Optimal','fontweight','bold')
    
    legend(programnames,'location',[0.42 0.2 0.2 0.6])
    
    if dosave==1, savefig([basename '-allocation-pies.png']), end
end


%% Plot "Fig. 8"
if plotfig2==1
    figure('position',[100 100 600 700])
    cksubplot([1 2],[1 1],[65 60],[0 0],[10 -14])
    bar(allocations/1e6,0.7,'stack','barwidth',1)
    legend(programnames,'position',[0.75 0.7 0.2 0.2])
    ylabel('Spend (million $)')
    set(gca,'xticklabel',xlabels);
    rotateticklabel(gca);
    xlim([0.5 15.5])
    
    cksubplot([1 2],[1 2],[65 60],[0 0],[10 -12])
    bar(infections/1e3,0.7,'stack','barwidth',1)
    legend(results(1).sim.popnames,'position',[0.75 0.2 0.2 0.2])
    ylabel('Cumulative new infections (''000s)')
    set(gca,'xticklabel',xlabels);
    rotateticklabel(gca);
    xlim([0.5 15.5])
    
    if dosave==1, savefig([basename '-allocation-bar.png']), end
end


%% Plot "Fig. 10"
prevorinci=[1 2];
if any(prevorinci==1) % Prevalence
    if plotfig3==1
        figure('position',[100 100 600 600])
        
        styles={'k--','r','b'};
        names={'No prevention','Optimized current budget','Current conditions'};
        for p=1:pg.npops
            subplot(4,2,p); hold on
            scens=[1 optimal current];
            for s=1:length(scens);
                plot(pg.pts,results(scens(s)).sim.prevalence(p,:)*100,styles{s},'linewidth',2)
            end
            xlabel('Year')
            ylabel('Prevalence (%)')
            title(results(1).sim.popnames{p},'fontweight','bold')
            xlim([2000 2020])
            box on
        end
        subplot(4,2,8); hold on
        set(gca,'visible','off')
        for s=1:length(scens);
            plot(0,0,styles{s},'linewidth',2)
        end
        set(gca,'xtick',[])
        set(gca,'ytick',[])
        legend(names)
        if dosave==1, savefig([basename '-allocation-prevalence.png']), end
    end
end
if any(prevorinci==2)
    if plotfig3==1
        figure('position',[100 100 600 600])
        
        styles={'k--','r','b'};
        names={'No prevention','Optimized current budget','Current conditions'};
        for p=1:pg.npops
            subplot(4,2,p); hold on
            scens=[1 optimal current];
            for s=1:length(scens);
                plot(pg.pts,results(scens(s)).sim.incidence(p,:),styles{s},'linewidth',2)
            end
            xlabel('Year')
            ylabel('Annual infections')
            title(results(1).sim.popnames{p},'fontweight','bold')
            xlim([2000 2020])
            box on
        end
        subplot(4,2,8); hold on
        set(gca,'visible','off')
        for s=1:length(scens);
            plot(0,0,styles{s},'linewidth',2)
        end
        set(gca,'xtick',[])
        set(gca,'ytick',[])
        legend(names)
        if dosave==1, savefig([basename '-allocation-incidence.png']), end
    end
end

disp('Done.')
