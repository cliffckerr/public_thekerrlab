%% SETUPMODEL
% This function calculates partnerships and gets the model ready to run.
% Version: 2012dec27

function [pg,pm]=setupmodel(data,equations,parstruct,whichscenario) 
pg=data.general;

% pars can either be control parameters specifying the model
% parameters, or the model parameters themselves. This code checks which it
% is, and converts to model parameters if necessary.
if ~isstruct(parstruct.populationsize) % Just pick a random field to test -- any would do
    pm=parstruct; % Argument is already pm -- don't need to do anything
else
    for phylum=1:length(equations.phyla);
        thisphylum=equations.phyla{phylum};
        pm.(thisphylum)=equations.model.(thisphylum); % Initialize array to be the right size
        pmequation.(thisphylum)=equations.model.(thisphylum); % Initialize array to be the right size
        families=equations.bayespars.(thisphylum);
        if numel(families) % There is an equation: it's a fitted parameter
            ndatarows=length(families);
            for row=1:ndatarows % Make parameters
                for family=1:length(families{row})
                    if strfind(families{row}{family},'time')
                        eval([families{row}{family} '=controlval(pg.controlyears, parstruct.(thisphylum).(families{row}{family}), pg.pts);']);
                    else % Not time -- normal parameter
                        eval([families{row}{family} '=parstruct.(thisphylum).' families{row}{family} ';']) % Strip "parstruct.(thisphylum)"
                    end
                end
                if family==1, indices='(round(end/2))'; else indices=''; end % Base quantities have quantiles, others don't
                eval(['pmequation.' equations.indices.(thisphylum){row} '=' equations.bayeseqns.(thisphylum){row} indices ';']) % WARNING: the round(end/2) is temporary; it pulls out the median to work with
            end
            limits=data.(thisphylum)([1 pg.nquantiles],1,1);
            pm.(thisphylum)=compactify(pmequation.(thisphylum),limits,0); % Force it to lie within the range
        else
            pm.(thisphylum)=zeros(size(pm.(thisphylum))); % If not specified, just make it zero
        end
    end
    pm=makescenarios(pm,data,whichscenario); % Handle scenarios, if they exist
    
    %% Convert transitions from matrix to list
    transitionnames={'asym','sym'}; % Symmetric and asymmetric population transitions
    for tn=transitionnames
        tname=char(tn); % Convert from cell to char
        [pm.transitions.(tname).pop1, pm.transitions.(tname).pop2]=find(~isnan(parstruct.transitions.(tname))); % Find only the entries that have transitions
        pm.transitions.(tname).rate=rmnan(parstruct.transitions.(tname)(:)); % And store the actual transition rates
    end

end


%% Partnership matrices
% Not my best code.
pm.partnerships=parstruct.partnerships; % Copy partnerships data
partnershipnames={'regular','casual','other','injecting'};
% for pname=partnershipnames
%     partnerships.(pname)=partnerships.(pname)(1:pg.npops,1:pg.npops); % WARNING, UBER KLUDGY!!! Getting desperate...
% end
pg.nsexpartnerships=sum(~isnan([pm.partnerships.regular(:); pm.partnerships.casual(:); pm.partnerships.other(:)]));
pg.ninjpartnerships=sum(~isnan(pm.partnerships.injecting(:)));
sexpartnerships=zeros(pg.nsexpartnerships,3); % 3 = interaction type | insertive population | receptive population
injpartnerships=zeros(pg.ninjpartnerships,2); % No interaction type to store
scount=0; icount=0;
for pop1=1:pg.npops
    for pop2=1:pg.npops
        for sextype=1:3 % Loop over regular, casual, other
            if ~isnan(pm.partnerships.(partnershipnames{sextype})(pop1,pop2))
                scount=scount+1;
                sexpartnerships(scount,:)=[pop1 pop2 sextype];
            end
        end
        if ~isnan(pm.partnerships.injecting(pop1,pop2))
            icount=icount+1;
            injpartnerships(icount,:)=[pop1 pop2];
        end
    end
end

for psh=1:pg.nsexpartnerships
    pm.sexpartnershippop(psh,1)=sexpartnerships(psh,1);
    pm.sexpartnershippop(psh,2)=sexpartnerships(psh,2);
    if pg.popismale(sexpartnerships(psh,2)) % Insertive population must be male, but receptive can be either
        pm.sexpartnershiptrans(psh,1)=pm.transhomoinsertive;
        pm.sexpartnershiptrans(psh,2)=pm.transhomoreceptive;
    else
        pm.sexpartnershiptrans(psh,1)=pm.transheteroinsertive;
        pm.sexpartnershiptrans(psh,2)=pm.transheteroreceptive;
    end
end
for psh=1:pg.ninjpartnerships
    pm.injpartnershippop(psh,1)=injpartnerships(psh,1);
    pm.injpartnershippop(psh,2)=injpartnerships(psh,2);
end

balancedsexacts=zeros(3,pg.npops,pg.npops,pg.npts);
balancedinjections=zeros(pg.npops,pg.npops,pg.npts);
for sextype=1:3 % Loop over regular, casual, other
    for t=1:pg.npts
        balancedsexacts(sextype,:,:,t) = balancepartnerships(pm.partnerships.(partnershipnames{sextype}), pm.populationsize(:,t), pm.(['numacts' partnershipnames{sextype}])(:,t));
    end
end

for t=1:pg.npts
    balancedinjections(:,:,t) = balancepartnerships(pm.partnerships.injecting, pm.populationsize(:,t), pm.numinjections(:,t));
end

pm.numacts=zeros(pg.nsexpartnerships,2,pg.npts); % 2 since two people/populations
if any(isnan(pm.numacts)), keyboard, end
for psh=1:pg.nsexpartnerships
    pm.numacts(psh,1,:)=balancedsexacts(sexpartnerships(psh,3),sexpartnerships(psh,1),sexpartnerships(psh,2),:); % Number of insertive acts per person
    pm.numacts(psh,2,:)=balancedsexacts(sexpartnerships(psh,3),sexpartnerships(psh,2),sexpartnerships(psh,1),:); % Number of receptive acts per person
end
if any(isnan(pm.numacts)), keyboard, end

pm.numinjectionpairs=zeros(pg.ninjpartnerships,2,pg.npts); % 2 since two people/populations
for psh=1:pg.ninjpartnerships
    pm.numinjectionpairs(psh,1,:)=balancedinjections(injpartnerships(psh,1),injpartnerships(psh,2),:);
    pm.numinjectionpairs(psh,2,:)=balancedinjections(injpartnerships(psh,2),injpartnerships(psh,1),:);
end

for psh=1:pg.nsexpartnerships
    partnershiptype=partnershipnames{sexpartnerships(psh,3)};
    pop1=pm.sexpartnershippop(psh,1);
    pop2=pm.sexpartnershippop(psh,2);
    condomprobpop1=pm.(['condomprob' partnershiptype])(pop1,:);
    condomprobpop2=pm.(['condomprob' partnershiptype])(pop2,:);
    pm.condomprob(psh,:)=(condomprobpop1+condomprobpop2)/2;
end

end





%% BALANCEPARTNERSHIPS
% This program calculates the optimal partnerships to give people.
% Version: 2012dec27

function pshipacts=balancepartnerships(mixmatrix,popsize,popacts)

% Make sure the dimensions all agree
assert(isequal(size(mixmatrix,1),size(mixmatrix,2),numel(popsize),numel(popacts)),sprintf('Input dimensions don''t match:\n%i %i %i %i',size(mixmatrix,1),size(mixmatrix,2),numel(popsize),numel(popacts))) 
npop=numel(popsize); % Number of populations



% WARNING, NOT SURE ABOUT THIS
% Make matrix symmetric
symmetricmatrix=zeros(npop);
mixmatrix(isnan(mixmatrix))=0; % Replace nans with 0s
for a=1:npop
    for b=1:npop
        symmetricmatrix(a,b)=symmetricmatrix(a,b)+(mixmatrix(a,b)+mixmatrix(b,a))/(logical(mixmatrix(a,b))+logical(mixmatrix(b,a)));
    end
end
mixmatrix=symmetricmatrix;
        


% The probability of interaction is dependent on the population size...not
% sure exactly why this works, but, um, it does :)
for a=1:npop
    mixmatrix(a,:)=mixmatrix(a,:)*popsize(a);
end

% Divide by the sum of the column to normalize the probability, then
% multiply by the number of acts and population size to get total number of
% acts
for a=1:npop
    mixmatrix(:,a)=popsize(a)*popacts(a)*mixmatrix(:,a)/sum(mixmatrix(~isnan(mixmatrix(:,a)),a));
end

% Reconcile different estimates of number of acts, which must balance
pshipacts=zeros(npop);
for a=1:npop
    for b=1:npop
        balanced=(mixmatrix(a,b)*popsize(a)+mixmatrix(b,a)*popsize(b))/(popsize(a)+popsize(b)); % here are two estimates for each interaction; reconcile them here
        pshipacts(b,a)=balanced/popsize(b); % Divide by population size to get per-person estimate
        pshipacts(a,b)=balanced/popsize(a); % ...and for the other population
    end
end

assert(sum(~isnan(pshipacts(:)))==sum(~isnan(mixmatrix(:))),'There were fewer partnerships than mixing matrix entries')

end



