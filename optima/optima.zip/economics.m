function [cost, ysum] = economics(sim,data,pts,thisyear)

yeartouse=11; % WARNING, UBER KLUDGY
countart=1; % Whether or not to count ART -- either 0 or 1

dt=data.general.timestep;
allpts=data.general.pts;

U.uninfIDU        = 1-data.econ.uninfIDU(3);
U.untreatCD4500   = 1-data.econ.untreatCD4500(3);
U.untreatCD4350500= 1-data.econ.untreatCD4350500(3);
U.untreatCD4200350= 1-data.econ.untreatCD4200350(3);
U.untreatCD4200   = 1-data.econ.untreatCD4200(3);
U.treatCD4500     = 1-data.econ.treatCD4500(3);
U.treatCD4350500  = 1-data.econ.treatCD4350500(3);
U.treatCD4200350  = 1-data.econ.treatCD4200350(3);
U.treatCD4200     = 1-data.econ.treatCD4200(3);

CD4500      = data.econ.CD4500(3,yeartouse);
CD4350500   = data.econ.CD4350500(3,yeartouse);
CD4200350   = data.econ.CD4200350(3,yeartouse);
CD4200      = data.econ.CD4200(3,yeartouse);
FirstART    = data.econ.ART1(3,yeartouse);
SecondART   = data.econ.ART2(3,yeartouse);

% if isnan(CD4500), error('Health care costs are Indian bread. Choose a different year perhaps?'), end

discR = 0.03;
discvec = 1./((1+discR).^(allpts(pts)-thisyear)); % Discount things prior to this year

y = squeeze(sum(sim.people(:,:,pts),2))';
Susceptible = y(:,1)'; 
U500        = y(:,2)';
U350500     = y(:,3)';
U200350     = y(:,4)';
U200        = y(:,5)';
D500        = y(:,6)';
D350500     = y(:,7)';
D200350     = y(:,8)';
D200        = y(:,9)';
First500    = y(:,10)';
First350500 = y(:,11)';
First200350 = y(:,12)';
First200    = y(:,13)';
Fail500     = y(:,14)';
Fail350500  = y(:,15)';
Fail200350  = y(:,16)';
Fail200     = y(:,17)';
Second500   = y(:,18)';
Second350500= y(:,19)';
Second200350= y(:,20)';
Second200   = y(:,21)';

%% Economic analysis for full span of years
for t=1:size(y,1)
    %%dalys
    cost.daly(t) = Susceptible(t)*(U.uninfIDU) ... % Have to work out how to determine the IDU populations in future. Fine for Malaysia
            + (U500(t) + D500(t) +Fail500(t))*(U.untreatCD4500) ... % Is treatment failure considered not on treatment? For now I've assumed that treated utilities apply
            + (U350500(t) + D350500(t)+Fail350500(t))*(U.untreatCD4350500) ...
            + (U200350(t) + D200350(t)+Fail200350(t))*(U.untreatCD4200350) ...
            + (U200(t) + D200(t)+Fail200(t))*(U.untreatCD4200) ... 
            + (First500(t)+Second500(t))*(U.treatCD4500)...
            + (First350500(t)+Second350500(t))*(U.treatCD4350500)...
            + (First200350(t)+Second200350(t))*(U.treatCD4200350)...
            + (First200(t)+Second200(t))*(U.treatCD4200);

    cost.healthcarecost(t) = (U500(t)+D500(t)+Fail500(t))*CD4500 ...
            + (U350500(t)+D350500(t)+Fail350500(t))*CD4350500...
            + (U200350(t)+D200350(t)+Fail200350(t))*CD4200350 ...
            + (U200(t)+D200(t)+Fail200(t))*CD4200...
            + (First200(t)+First200350(t)+First350500(t)+First500(t))*FirstART*countart ...
            + (Second200(t)+Second200350(t)+Second350500(t)+Second500(t))*SecondART*countart;
        
end
cost.daly_disc = cost.daly.*discvec;
cost.healthcarecost_disc = cost.healthcarecost.*discvec;

ysum= sum(y(:,1:21),1)*dt;
end