%% MANUALFIT
% I was hoping to avoid writing a manual fitting code, but looks like I
% won't have any such luck.
%
% 1. The first time you run it, call manualfit with no input arguments, and
% it will load the file specified by name (see below):
%   [pars,sim]=manualfit;
% 2. Modify pars to your heart's content, e.g.
%   pars.numactscasual.pop1=-3;
% 3. Rerun with pars as an input argument:
%   [pars,sim]=manualfit(pars);
% 4. Repeat steps 2 and 3 until you're happy. 
% 5. Call manualfit with two arguments to save your fitted pars structure to
% the named mat file, e.g.
%   manualfit(pars,'goodfit.mat')
% NB: make sure you include the .mat extension in the file namce, otherwise
% it won't work!!
%
% A note on modifying parameters: all parameters are allowed to vary on the
% range [-Inf,Inf]. The parameter you specify is "compactified" onto the
% range specified by the lower and upper limits for the data. For example,
% condom usage must be between [0,1]. Thus if you set pars.condomprob=-Inf,
% this will translate to an actual value of 0. Likewise, pars.condomprob=0
% will translate to an actual value of 50% (since 0 is halfway between -Inf
% and Inf).
%
% In general, it's a good idea to watch how your changes to the parameters
% affect how well the model fits the behavioral data (middle panel of the
% figure that appears) as well as the epidemiological data (top and bottom
% panels). There's no way of knowing whether pars.populationsize.pop3=-3.48
% is "reasonable" except by seeing how close the corersponding grey dot
% (model) is to the blue cross (data).
% 
% Version: 2013jun14

function [parstruct,sim]=manualfit(varargin)

opt=setoptions; % Get options, such as file name
figh=2528;
options.turnofftransmission=-opt.manfit.yearrange(2); % Don't bother running simulation after this point

disp('Loading data...')
if nargin==0 % No arguments, copy default data to temporary file (manual.mat)
    copyfile(opt.matfilename,'./manual.mat') % Copy existing file to a temporary one
elseif nargin==1 % One argument, rerun
    parstruct=varargin{1};
    opt.matfilename='./manual.mat';
elseif nargin>1 % Save
    parstruct=varargin{1};
    outname=varargin{2};
    copyfile('./manual.mat',outname) % Copy existing file to a temporary one
    lastupdated=datestr(clock); %#ok<NASGU> % Just as a reminder of when things were last run
    save(outname,'parstruct','lastupdated','-append')
    fprintf('File %s saved.\n',outname)
    return
end

d=load(opt.matfilename);
if ~exist('parstruct','var') % Only rerun if doesn't exist -- this is key since this is what's being modified!
    parstruct=d.parstruct;
end
priorvec=convertparams('struct2vec',parstruct,d.equations,0);


% Run stuff
disp('Running...')
[pg,pm]=setupmodel(d.data,d.equations,parstruct,1);
pm=equilibrium(pg,pm);
sim=model(pg,pm,1,options);

disp('Plotting...')
if ~ishandle(figh), figure(figh); set(gcf,'position',[200 200 1400 900]); else clf(figh), set(0,'currentfigure',figh), end % Only open figure if it doesn't already exist
npops=size(d.data.hivprevalence,2);


%% Prevalence
years=d.data.general.datayears;
for p=1:npops
    goodprevyears=find(~isnan(squeeze(d.data.hivprevalence(3,p,:))));
    cksubplot([npops 3],[p 1],[80 80],[3 0],[5 -1],[1 1]); hold on
    plot(d.data.general.pts,100*sim.prevalence(p,:),'color','k','linewidth',2)
    scatter(years,100*squeeze(d.realdata.hivprevalence(3,p,:)),50,'k','filled'), hold on
    for yr=1:length(goodprevyears)
        plot(years(goodprevyears(yr))*[1 1], 100*d.data.hivprevalence([2 4],p,goodprevyears(yr)),'k','linewidth',2);
    end
    xlabel('Year')
    ylabel('Prevalence (%)')
    title(sprintf('%i - %s',p,sim.popnames{p}))
    axis tight
    setylim(0,[]);
    xlim(opt.manfit.yearrange)
end


%% Behavioral data
% This code is mostly copied out of makeposteriors. It should probably be a
% separate function since I use it in three places!
if ~exist('exppoints','var') % WARNING, SUPER KLUDGY!!! Could probably make this block of code 10 if not 100 times faster
    exppoints=zeros(0,3); % For lower, median, upper
    simpoints=zeros(0,1); % Store one for each simulation
    predictions=struct;
    pg=d.data.general;
    
    binends=[];
    ticklabels=cell(0);
    count=0;
    phylumcount=0;
    startcount=1;
    temp=struct;
    for phylum=1:length(d.equations.phyla)
        thisphylum=d.equations.phyla{phylum};
        phylumdata=d.realdata.(thisphylum);
        mediandata=cksqueeze(phylumdata(3,:,:));
        % Do weighting
        [datarows,datacols]=find(~isnan(mediandata));
        ndatapts=length(datarows);
        assert(length(datarows)==length(datacols),'Number of data points don''t make sense!')
        
        families=unique([d.equations.bayespars.(thisphylum){:}]); % Find out what parameters are used to model this data
        nfamilies=length(families);
        if nfamilies>0 % Don't loop over parameter if it doesn't exist
            nrows=size(d.equations.indices.(thisphylum),2); % Don't try modeling things that don't have an equation
            ncols=size(phylumdata,3);
            predictions.(thisphylum)=nan(nrows,ncols);
                        
            valuestofamilies=cell(nfamilies,1);
            
            for family=1:nfamilies
                thisfamily=families{family};
                if strfind(thisfamily,'time')
                    endcount=startcount+pg.ncontrolyears-1;
                else
                    endcount=startcount;
                end
                valuestofamilies{family}=startcount:endcount;
                startcount=endcount+1;
            end
            temp.(thisphylum)=valuestofamilies;
            
            % Calculate values
            for family=1:nfamilies
                if strfind(families{family},'time')
                    eval([families{family} '=controlval(pg.controlyears,priorvec.vec(valuestofamilies{family}),pg.datayears);']);
                else % Not time -- normal parameter
                    eval([families{family} '=' num2str(priorvec.vec(valuestofamilies{family})) ';'])
                end
            end
            
            % Make predictions
            for row=1:nrows
                try
                    eval(['predictions.' d.equations.indices.(thisphylum){row} '=' d.equations.bayeseqns.(thisphylum){row} ';'])
                catch exception
                    fprintf('\n\nProblem with %s\n\n',thisphylum)
                    rethrow(exception)
                end
            end
            limits=d.data.(thisphylum)([1 pg.nquantiles],1,1);
            predictions.(thisphylum)=compactify(predictions.(thisphylum),limits,0); % Force it to lie within the range
            
            if any(~isnan(mediandata(:))) % Only increment these if at least one data point is entered
                phylumcount=phylumcount+1;
                binends(phylumcount)=count+1; %#ok<AGROW>
                ticklabels{phylumcount}=d.equations.phyla{phylum};
            end

            if ndims(phylumdata)>2
                for pt=1:ndatapts
                    count=count+1; % Only iterate for first sim
                    exppoints(count,:)=phylumdata(2:4,datarows(pt),datacols(pt));
                    simpoints(count)=predictions.(thisphylum)(datarows(pt),datacols(pt));
                end
            else
                for pt=1:ndatapts
                    count=count+1;
                    exppoints(count,:)=phylumdata(2:4,datacols(pt));
                    simpoints(count)=predictions.(thisphylum)(datacols(pt));
                end
            end
        end
    end
end

h=cksubplot([1 3],[1 2],[100 80],[2 5],[5 2],[1 1]); hold on
lowerlim=-5; % Smallest value to plot in log10
scatter(1:count,log10(simpoints+10^lowerlim),25,0.5*[1 1 1],'filled');
scatter(1:count,log10(exppoints(:,2)+10^lowerlim),25,'b+');
legend('Model','Data')
for i=1:length(exppoints)
    plot(i*[1 1], log10(exppoints(i,[1 3])+10^lowerlim),'b','linewidth',2);
end
xlim([1 length(exppoints)])
ylim([lowerlim 10])
set(gca,'xtick',binends)
set(gca,'xticklabel',ticklabels)
rotateticklabel(h,[],8);
ylabel('log_{10}(value)')
title(sprintf('Behavioral parameters | Name: %s | Date: %s',opt.matfilename,datestr(now)),'fontweight','bold')



%% Other epidemiological data
row=[1 1 2]; % Plot pg.npops different diagnoses curves, then one each for treatment 1 & 2
simfields={'diagnoses'; 'numontreat1'; 'numontreat2'};
datafields={'numdiagnoses';'numtreatment';'numtreatment'};
titles={'Diagnoses','1st-line treatment','2nd-line treatment'};
ylabels={'Number of diagnoses','Number on 1st-line','Number on 2nd-line'};

popcolors=vectocolor(1:pg.npops);
popcolors=[popcolors;zeros(2,3)];
for f=1:length(row)
    datafld=datafields{f};
    simfld=simfields{f};
    goodyears=find(~isnan(squeeze(d.data.(datafld)(3,row(f),:))));
    cksubplot([3 3],[f 3],[80 50],[3 5],[7 0],[1 1]); hold on % Create new axis but not for new diagnoses data
    thisdata=sum(sim.(simfld),1);
    plot(pg.pts,thisdata,'color',popcolors(f,:),'linewidth',2)
    if f==1
        expdata=squeeze(sum(d.realdata.(datafld)(3,:,:),2));
        explims=squeeze(sum(d.realdata.(datafld)([2 4],:,:),2));
    else
        expdata=squeeze(d.realdata.(datafld)(3,row(f),:));
        explims=squeeze(d.realdata.(datafld)([2 4],row(f),:));
    end
    scatter(years,expdata,50,'filled','markerfacecolor',popcolors(f,:)), hold on
    for yr=1:length(goodyears)
        plot(years(goodyears(yr))*[1 1], explims(:,goodyears(yr)),'color',popcolors(f,:)','linewidth',2);
    end
    xlabel('Year')
    ylabel(ylabels{f})
    title(titles{f},'fontweight','bold')
    setylim(0,[]);
    xlim(opt.manfit.yearrange)
end

end
