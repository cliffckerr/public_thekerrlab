%% MAKESCENARIOS
% This code makes the scenarios; runscenarios runs them. What it does is
% replace certain fields of pm with new versions.
% Version 2013may05

function pm=makescenarios(pm,data,whichscenario)

pm.name='Default'; % Initialize

end