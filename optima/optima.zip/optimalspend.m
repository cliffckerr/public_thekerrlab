%% OPTIMALSPEND
% This program finds the optimal spending allocation for a set of programs.
% How it works:
% - Prevtool data are loaded.
% - The current total spend and allocation is specified.
% - The model is run with those values from 2010-2020.
% - Each program is allowed to take on a value from [$0,$Inf]. The sum of all program spends is then divided to give the desired total.
% - The parameter values corresponding to the current spend level will be calculated.
% - The output quantity will be the number of infections in the time period.
% - This quantity will be optimized via a scatterchoice algorithm.
% - All output quantities from the optimal allocation will be saved.
% - This process will be repeated for different total spending levels.
% Version: 2013apr24

function [allocations,everyallocation,sims]=optimalspend

%% Set parameters
tic
doplot=1;
dosave=1;
donotify=1;
dorandomize=1;
startyear=2013; % Year to start scenarios
endyear=2018; % Year to stop counting
maxiters=2;
datafile='./vietnam/revision/vietnam-apr21.mat';
logisticfile='./vietnam/revision/newlogspend.mat';
savename='./vietnam/revision/vietnam-apr24-tmp.mat';
if doplot==1, figure('position',[200 200 800 600]), end


%% Load data to do optimal allocation on, plus logistic curve data
disp('Loading data...')
d=load(datafile); % Load Prevtool output
tmp=load(logisticfile); s=tmp.s; % Load logistic curves
s.newiec.cond=[0.15 0.25 0 5e6]; % New values based on those that Quang sent me 21/04/2013 -- wrong format so can't read in automatically -- WARNING KLUDGY


%% Run preliminary model
disp('Initializing...')
[pg,pm]=setupmodel(d.data,d.partnerships,d.parstruct,1);
pm=equilibrium(pg,pm);

%% Specify programs
disp('Specifying programs....')
programnames={'LRP: Condom %','FSW: Condom %','MSM: Condom %','NSP: Sharing %','MMT: % on treatment','STI: % prevalence','VCT: Testing %/year'};
nprograms=length(programnames);
allocation=[5994680	2707129	1056975	7591711	656930	777716	4676980]'; % From vietnam/revision/spending.xlsx
original=allocation; % Save original allocation
origtotal=sum(original);

scenpoints=find(pg.pts>=startyear); % Which year to start the scenario
costpoints=find(pg.pts>=startyear & pg.pts<=endyear); % What years to calculate intervention over


%% Calculate the optimal allocation
disp('Running...')
starttime=now*86400;
budgets=[1 1e-6]; %[0.1:0.1:1 1.2 1.5 2];
nbudgets=length(budgets);
allocations=zeros(nbudgets,nprograms);
everyallocation=cell(nbudgets,1);
if ~matlabpool('size'), matlabpool, end
parfor b=1:nbudgets
    everyallocation{b}=zeros(maxiters,nprograms);
    distribution=original; % Set the original distribution...sloppy I know
    if dorandomize==1
        randomize=rand(nprograms,1);
        distribution=distribution.*randomize; % Randomize
        distribution=distribution*origtotal/sum(distribution); % Correct mean
    end
    allocation=distribution*budgets(b);
    totalspend=sum(allocation);
    [allocations(b,:),everyallocation{b},sims{b}]=scatterchoice(allocation,s,scenpoints,costpoints,totalspend,d,pm,pg,maxiters,everyallocation{b},starttime,doplot,programnames);
    percentcomplete(b,nbudgets)
end

if dosave==1
    save(savename,'allocations','everyallocation','sims','budgets','programnames')
    fprintf('Results saved to %s.\n',savename)
end
     
    
if donotify==1, notify, end
toc

end





%% SCATTERCHOICE
% This function chooses a random parameter to optimize, then computes
% the error function of an increase or decrease in that parameter. If
% either the increase or decrease improves the fit, it keeps that value
% and increases its step size in that direction as well as the
% probability it will step with that parameter, the latter proportional
% to the amount the fit improved. If neither the increase nor decrease
% improve the fit, then it reduces the step size.
function [allocation,everyallocation,sim]=scatterchoice(allocation,s,scenpoints,costpoints,totalspend,d,pm,pg,maxiters,everyallocation,starttime,doplot,programnames)
LRP=1; FSW=2; MSM=3; NSP=4; MMT=5; STI=6; VCT=7; % Make it so I can refer to programs by their names, e.g. VCT = 7
stepsize=1e5; % Default step size in thousands of dollars
stepincrease=1.1; % Amount by which to increase step size if error is smaller than current
stepdecrease=0.5; % Amount by which to decrease step size if both errors are larger than current
learnrate=10; % Amount by which to increase the probability of that parameter being selected
punishrate=0.5; % Amount by which to punish parameters that don't improve with either increases or decreases
nparams=length(allocation);
stepsizes=stepsize*ones(nparams,1);
probabilities=ones(nparams,1);
logistic=@(x,p) (p(2)-p(1))./(1+exp(-(x-p(3))/p(4)))+p(1); % Define a simple logistic equation; see below for a more general formula
showprogress=1; % Show how optimization is doing



count=0; % For optimization later
infections=modelfun(allocation);
while 1
    probabilities=probabilities/sum(probabilities);
    cumprobs=cumsum(probabilities);
    thisparam=find(cumprobs>rand,1);
    priorvecl=allocation;
    priorvecu=allocation;
    priorvecl(thisparam)=priorvecl(thisparam)-logical(count)*stepsizes(thisparam); % The logical(count) thing makes the first trial unchanged for plotting
    priorvecu(thisparam)=priorvecu(thisparam)+logical(count)*stepsizes(thisparam);
    priorvecl=max(priorvecl,0); % Don't let it go negative
    priorvecu=max(priorvecu,0);
    priorvecl=priorvecl*totalspend/sum(priorvecl); % Normalize
    priorvecu=priorvecu*totalspend/sum(priorvecu); % Normalize
    infectionsl=modelfun(priorvecl);
    infectionsu=modelfun(priorvecu);
    if infectionsl<infections && infectionsu>=infections % Lowering it improved it
        probabilities(thisparam)=probabilities(thisparam)+learnrate*(infections/infectionsl-1); % Increase probability of picking this parameter again
        stepsizes(thisparam)=stepsizes(thisparam)*stepincrease; % Increase size of step for next time
        infections=infectionsl; % Reset current error
        allocation=priorvecl; % Reset current parameters
    elseif infectionsu<infections && infectionsl>=infections % Raising it improved it
        probabilities(thisparam)=probabilities(thisparam)+learnrate*(infections/infectionsu-1); % Increase probability of picking this parameter again
        stepsizes(thisparam)=stepsizes(thisparam)*stepincrease; % Increase size of step for next time
        infections=infectionsu; % Reset current error
        allocation=priorvecu; % Reset current parameters
    elseif infectionsu<=infections && infectionsl<=infections % They both did! Mountain
        if infectionsl<infectionsu
            infections=infectionsl; % Reset current error
            allocation=priorvecl; % Reset current parameters
        elseif infectionsu<infectionsl
            infections=infectionsu; % Reset current error
            allocation=priorvecu; % Reset current parameters
        end
    elseif infectionsu>=infections && infectionsl>=infections % Neither did: Valley
        stepsizes(thisparam)=stepsizes(thisparam)*stepdecrease;
        probabilities(thisparam)=probabilities(thisparam)*punishrate;
    else
        error('Something impossible happened')
    end
    
    count=count+1;
    everyallocation(count,:)=allocation;
    if ~mod(count-1,showprogress) && showprogress>0
        fprintf('%i/%i | %i s | Infections: %i\n',count,maxiters,round(now*86400-starttime),infections)
%         disp([allocation probabilities stepsizes])
        if doplot==1
            clf
            nprograms=length(allocation);
            colors=vectocolor(1:nprograms);
            for pp=1:nprograms
                plot(everyallocation(1:count,pp),'linewidth',2,'color',colors(pp,:)); hold on
            end
            legend(programnames)
            xlim([1 maxiters])
            drawnow
        end
    end
    if count>maxiters, break, end % Stop if done enough iterations
end




%% Calculate current infections based on spend
    function infections=modelfun(allocation)
        
        % 1. Low-risk population condom usage
        for p=1:2, pm.condomprobregular(p,scenpoints)=logistic(allocation(LRP),s.newiec.cond); end % General/regular acts population condom rate
        
        % 2. Female sex worker and client condom usage
        for p=[3 5], pm.condomprobother(3,scenpoints)=logistic(allocation(FSW),s.fsw.comdfsw); end % DFSW (3) and client (5) condom rate
        for p=[3 5], pm.condomprobcasual(3,scenpoints)=logistic(allocation(FSW),s.fsw.casdfsw); end % DFSW (3) and client (5) condom rate
        pm.condomprobother(4,scenpoints)=logistic(allocation(FSW),s.fsw.comifsw); % IFSW (4) condom rate
        pm.condomprobcasual(4,scenpoints)=logistic(allocation(FSW),s.fsw.casifsw); % IFSW (4) condom rate
        
        % 3. MSM condom usage
        pm.condomprobcasual(6,scenpoints)=logistic(allocation(MSM),s.msm.cas); % IFSW condom rate
        pm.condomprobother(6,scenpoints)=logistic(allocation(MSM),s.msm.com); % IFSW condom rate
        
        % 4. NSP
        pm.syringesharingprob(scenpoints)=logistic(allocation(NSP),s.nsp); % Syringe sharing
        
        % 5. MMT
        pm.methadoneprob(scenpoints)=logistic(allocation(MMT),s.mmt); % Methadone
        
        % 6. STI
        pm.stiprevalence(3,scenpoints)=logistic(allocation(STI),s.sti.dfsw); % STI prevalence
        pm.stiprevalence(4,scenpoints)=logistic(allocation(STI),s.sti.ifsw); % STI prevalence
        pm.stiprevalence(6,scenpoints)=logistic(allocation(STI),s.sti.msm); % STI prevalence
        
        % 7. VCT
        pm.testingrate(1,scenpoints)=logistic(allocation(VCT),s.vct.lrp); % LRM testing rate
        pm.testingrate(2,scenpoints)=logistic(allocation(VCT),s.vct.lrp); % LRF testing rate
        pm.testingrate(3,scenpoints)=logistic(allocation(VCT),s.vct.dfsw); % DFSW testing rate
        pm.testingrate(4,scenpoints)=logistic(allocation(VCT),s.vct.ifsw); % IFSW testing rate
        pm.testingrate(5,scenpoints)=logistic(allocation(VCT),s.vct.lrp); % CSW testing rate -- estimate
        pm.testingrate(6,scenpoints)=logistic(allocation(VCT),s.vct.msm); % MSM testing rate
        pm.testingrate(7,scenpoints)=logistic(allocation(VCT),s.vct.idu); % IDU testing rate
                
        % Run the model
        options.turnofftransmission=-2021; % Only run model until this date; the minus sign aborts
        [pg,pm]=setupmodel(d.data,d.equations,pm,1);
        pm=equilibrium(pg,pm);
        sim=model(pg,pm,1,options);
        infections=sum(sum(sim.incidence(:,costpoints)*pg.timestep,2)); % To exclude low-risk population, use 3:end instead of :
    end


end






