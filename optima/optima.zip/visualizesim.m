%% VISUALIZESIM
% This code does various visualizations of the sim structure. To use, run
% the model to generate the sim structure -- for example, via
%
% [pars,sim]=manualfit;
%
% Then call this code to plot one of the quantities saved in the sim
% structure. By far the coolest thing to plot is sim.people, which shows a
% movie of (population x health state x time). After the movie is finished,
% you can step through using the arrow keys (right/left: +/- 1 frame, down/up:
% +/- 5 frames). For other plots, you can use the third argument to control
% whether it shows the data on a log scale or not, e.g.
%
% visualizesim(sim,'incidence','log')
%
% This is useful for things like plotting prevalence of 50% and 0.1% on the
% same graph!
%
% Version: 2013may13

function visualizesim(sim,whattoplot,varargin)

% Handle input arguments
if isempty(whattoplot) % Plot everything
    whattoplot={'incidence','prevalence','allpeople','hivdeaths','causehiv','numontreat1','numontreat2','diagnoses','people'};
elseif ischar(whattoplot) % Plot just one thing
    whattoplot={whattoplot};
elseif ~iscell(whattoplot) % Not everything nor one thing and not a cell array of strings indicating multiple things
    error('Second argument must be [], or string, or cell array')
end

% Two sims were used: plot the difference
plotdifference=0;
if iscell(sim)
    sim1=sim{1};
    sim2=sim{2};
    sim=sim1; % Reset
    for f=1:length(whattoplot) % Populate the fields
        sim.(whattoplot{f})=sim2.(whattoplot{f})-sim1.(whattoplot{f}); % Calculate the difference
    end
    plotdifference=1;
end
    


% Do the plotting
for pl=1:length(whattoplot)
    thisplot=whattoplot{pl};
    plotlog=0; % Whether to plot as a log
    if nargin==3 && strcmp(varargin{1},'log'), plotlog=1; end
    
    if ~isfield(sim,thisplot), error('Field %s not recognized',thisplot'), end
    
    npops=size(sim.incidence,1); % Find out how many populations there are
    colors=vectocolor(1:npops); % Create colors for plotting
    
    
    % Plot all (population x time) quantities
    if ~strcmp(thisplot,'people')
        figure('position',[100 100 900 900]); hold on
        if ~plotlog
            for p=1:npops %#ok<*FXUP>
                stem3(sim.pts,p*ones(size(sim.pts)),sim.(thisplot)(p,:),'filled','color',colors(p,:),'linewidth',2)
            end
        else
            for p=1:npops
                plot3(sim.pts,p*ones(size(sim.pts)),sim.(thisplot)(p,:),'color',colors(p,:),'linewidth',2)
                set(gca,'zscale','log')
            end
        end
        legend(sim.popnames)
        box on
        title(thisplot)
        view([30,30])
    
        
    % Make a movie of people since (population x disease state x time)
    else
        figure('position',[100 100 900 900],'WindowKeyPressFcn',@nextstep);
        states={1,2:5,6:9,10:13,14:17,18:21};
        statenames={'Sus','UnDx','Dx','T1','F','T2'};
        statelinestyles={'-','--','-','--','-','--'};
        statemarkstyles={'o','s','d','o','s','d'};
        thisstep=0;
        nsteps=min(10,length(sim.pts));
        for thisstep=round(linspace(1,length(sim.pts),nsteps))
            nextstep([],[])
            drawnow
        end
    end
    
end



    function nextstep(~,event)
        clf;
        hold on
        if ~isempty(event)
            if strcmp(event.Key,'rightarrow'), thisstep=thisstep+1; end
            if strcmp(event.Key,'leftarrow'), thisstep=thisstep-1; end
            if strcmp(event.Key,'downarrow'), thisstep=thisstep+5; end
            if strcmp(event.Key,'uparrow'), thisstep=thisstep-5; end
        end
        thisstep=mod(thisstep-1,length(sim.pts))+1;
        
        for p=1:npops
            for s=1:length(states)
                if plotlog
                    stem3(states{s},p*ones(size(states{s})),log10(sim.people(states{s},p,thisstep)+1),'filled','color',colors(p,:),'linewidth',2,'linestyle',statelinestyles{s},'marker',statemarkstyles{s})
                else
                    stem3(states{s},p*ones(size(states{s})),sim.people(states{s},p,thisstep),'filled','color',colors(p,:),'linewidth',2,'linestyle',statelinestyles{s},'marker',statemarkstyles{s})
                end
            end
        end
        set(gca,'xtick',[1 2 6 10 14 18])
        set(gca,'xticklabel',statenames)
        set(gca,'yticklabel',sim.popnames)
        if ~plotdifference % Don't try to specify axes if plotting the difference of two sims
            if plotlog
                zlim([0 max(log10(sim.people(:)))])
            else
                zlim([0 max(max(max(sim.people(2:end,:,:))))])
            end
        end
        zlabel('log_{10}(Number of people)')
        title(sprintf('Time: %0.1f | Step %i/%i',sim.pts(thisstep),thisstep,length(sim.pts)))
        view([60,60])
        box on
    end



end