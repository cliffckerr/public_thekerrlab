%% GRAPHFIG
% This creates the figure for the view graphs/tables window. Adapted for
% use with Prevtool.
% Version: 2013mar18

function graphfig(varargin)

plotcausehiv=0; % Whether to plot how many infections a group causes rather than has: WARNING, needs to be integrated properly!

disp('Loading data...')
if ~exist('matfilename','var')
    matfilename='./vietnam/revision/vietnam-apr15.mat';
    description='National';
end
d=load(matfilename);
if nargin==1, sim=varargin{1};
else sim=d.simsets{1};
end
pg=d.data.general;
pm=sim.pm;
popnames=sim.popnames;

disp('Opening figure...')
scrsz=get(0,'screensize'); scrsz=scrsz(3:4); % Get midpoint of monitor
pancol=[200 200 240]/255;
meh=[0.9 0.9 0.9];
P.units='normalized'; P.backgroundcolor=pancol;
T.style='text'; T.units='normalized'; T.horizontalalignment='left'; T.backgroundcolor=pancol;
R=T; R.style='radio';
U=T; U.style='popup'; U.backgroundcolor=meh;
C=T; C.style='checkbox';
ci=0; % Initialize uncertainty for later use
normal=1;



% Define functions that would otherwise be in the if loop
    function yrcallback(hObject,~) % Set the end year to be the same as the start year
        whichmenu=(hObject==uiyrfinish)+1; % Figure out which menu it was
        start=get(uiyrstart,'value'); newstart=start;
        finish=get(uiyrfinish,'value'); newfinish=finish;
        maxyr=length(get(uiyrstart,'string'));
        
        % All was selected: set both to all
        if whichmenu==1 && start==1, newfinish=1; end % Start->All selected: Set finish year to "All"
        if whichmenu==2 && finish==1, newstart=1;  end % Finish->All selected: Set start year to "All"
        
        % One is all and the other isn't: convert to a year
        if whichmenu==1 && start~=1  && finish==1, newfinish=maxyr; end % Start->~All  selected, Finish=All, set Finish=maxyear
        if whichmenu==2 && finish~=1 && start==1,  newstart=2;      end % Finish->~All selected, Start=All, set Start=2
        
        % Start year is later than finish year
        if newstart>newfinish
            if whichmenu==1, newfinish=newstart; end % Start  year selected later   than finish year: set finish= start
            if whichmenu==2, newstart=newfinish; end % Finish year selected earlier than start  year: set  start=finish
        end
        set(uiyrstart,'value',newstart)
        set(uiyrfinish,'value',newfinish)
    end
    function simselect(hObject,~), set(uichk(uisim==hObject),'value',1), end % Automatically check the button when a sim is selected
    function simselect2(~,~), set(uiotherchk,'value',1); end % Tick the box automatically
    function uncerbutt(hObject,~)
        if ~isempty(hObject), for ii=1:length(uiuncerbutt), set(uiuncerbutt(ii),'value',uiuncerbutt(ii)==hObject), end, end
        for ii=1:5, ci=get(uiuncerbutt(ii),'value'); if ci==1, ci=ii-1; break, end, end
    end

fwid=810; fhei=615; Cf=[1/fwid 1/fhei 1/fwid 1/fhei];
graphfig=figure('position',[(scrsz(1)-fwid)/2 (scrsz(2)-fhei)/2 fwid fhei],'name',sprintf('View graphs/tables'),'numbertitle','off','color',meh,'toolbar','none','menubar','none');
leftmargin=25;
D{1}.sim=sim; simlist=cell(length(D),1); D{1}.description=description; 
for i=1:40, D{1}.allresults{i}=sim; end
%     simlistmp=load(fullfile(projdir,'working.mat')); D=simlistmp.D; simlist=cell(length(D),1); pg=D{1}.pg; % Assume pg doesn't change
for iii=1:length(simlist), simlist{iii}=D{iii}.description; end

% Create panels
p1wid=550; p1hei=280; Cp1=[1/p1wid 1/p1hei 1/p1wid 1/p1hei];
p2wid=550; p2hei=280; Cp2=[1/p2wid 1/p2hei 1/p2wid 1/p2hei];
p3wid=200; p3hei=190; Cp3=[1/p3wid 1/p3hei 1/p3wid 1/p3hei];
p4wid=200; p4hei=170; Cp4=[1/p4wid 1/p4hei 1/p4wid 1/p4hei];
p5wid=200; p5hei=200; Cp5=[1/p5wid 1/p5hei 1/p5wid 1/p5hei];
panel1=uipanel(graphfig,P,'position',[leftmargin 320 p1wid p1hei].*Cf);
panel2=uipanel(graphfig,P,'position',[leftmargin  20 p2wid p2hei].*Cf);
panel3=uipanel(graphfig,P,'position',[       590 410 p3wid p3hei].*Cf);
panel4=uipanel(graphfig,P,'position',[       590 230 p4wid p4hei].*Cf);
panel5=uipanel(graphfig,P,'position',[       590  20 p5wid p5hei].*Cf);

%% Create top-right panel

poplist=[{sprintf('All populations') sprintf('Low-risk males & females') sprintf('All males') sprintf('All females') sprintf('All sex workers') sprintf('All MSM') sprintf('All IDUs')} popnames{:}];
uicontrol(panel3,T,'position',       [10 160 170  20].*Cp3,'string',sprintf('General options'),'fontweight','bold');
uicontrol(panel3,T,'position',       [10 130 170  20].*Cp3,'string',sprintf('Population:'));
uipop=uicontrol(panel3,U,'position', [10 100 170  30].*Cp3,'string',poplist);

yrlist=cell(length(pg.simyears)+1,1); yrlist{1}=sprintf('All'); for iii=1:length(pg.simyears), yrlist{iii+1}=num2str(pg.simyears(iii)); end
uicontrol(panel3,T,'position',            [ 10  57 80  20].*Cp3,'string',sprintf('Start year:'));
uiyrstart=uicontrol(panel3,U,'position',  [100  60 90  20].*Cp3,'string',yrlist,'callback',@yrcallback);
uicontrol(panel3,T,'position',            [ 10  17 80  20].*Cp3,'string',sprintf('End year:'));
uiyrfinish=uicontrol(panel3,U,'position', [100  20 90  20].*Cp3,'string',yrlist,'callback',@yrcallback);


%% Create top panel
wid=230;
uisim=zeros(6,1); uichk=ones(6,1); % uisim stores which simulation it is; uichk stores whether or not to use it
uicontrol(panel1,T,'position',          [ 20  250 wid  20].*Cp1,'string',sprintf('Compare scenarios'),'fontweight','bold');
uicontrol(panel1,T,'position',          [ 30  220 wid  20].*Cp1,'string',sprintf('Baseline simulation:'));
uisim(1)=uicontrol(panel1,U,'position', [ 30  190 wid  30].*Cp1,'string',simlist);

uichk(2)=uicontrol(panel1,C,'position', [290  220 wid  30].*Cp1);
uicontrol(panel1,T,'position',          [310  222 wid  20].*Cp1,'string',sprintf('Simulation 2:'));
uisim(2)=uicontrol(panel1,U,'position', [290  190 wid  30].*Cp1,'string',simlist,'callback',@simselect);

uichk(3)=uicontrol(panel1,C,'position', [ 30  150 wid  30].*Cp1);
uicontrol(panel1,T,'position',          [ 50  152 wid  20].*Cp1,'string',sprintf('Simulation 3:'));
uisim(3)=uicontrol(panel1,U,'position', [ 30  120 wid  30].*Cp1,'string',simlist,'callback',@simselect);

uichk(4)=uicontrol(panel1,C,'position', [290  150 wid  30].*Cp1);
uicontrol(panel1,T,'position',          [310  152 wid  20].*Cp1,'string',sprintf('Simulation 4:'));
uisim(4)=uicontrol(panel1,U,'position', [290  120 wid  30].*Cp1,'string',simlist,'callback',@simselect);

uichk(5)=uicontrol(panel1,C,'position', [ 30  80 wid  30].*Cp1);
uicontrol(panel1,T,'position',          [ 50  82 wid  20].*Cp1,'string',sprintf('Simulation 5:'));
uisim(5)=uicontrol(panel1,U,'position', [ 30  50 wid  30].*Cp1,'string',simlist,'callback',@simselect);

uichk(6)=uicontrol(panel1,C,'position', [290  80 wid  30].*Cp1);
uicontrol(panel1,T,'position',          [310  82 wid  20].*Cp1,'string',sprintf('Simulation 6:'));
uisim(6)=uicontrol(panel1,U,'position', [290  50 wid  30].*Cp1,'string',simlist,'callback',@simselect);


uiplotprev=uicontrol(panel1,P,'string',sprintf('Plot prevalence'),'callback',@plotprevinci,'position', [ 20  10 150 30].*Cp1);
uicontrol(panel1,P,'string',sprintf('Plot incidence') ,'callback',@plotprevinci,'position', [200  10 150 30].*Cp1);
uicontrol(panel1,P,'string',sprintf('Infections averted') ,'callback',@plotavert,'position',[380  10 150 30].*Cp1);


%% Create bottom panel
uicontrol(panel2,T,'position',           [ 20  250 wid  20].*Cp2,'string',sprintf('Display other outcomes'),'fontweight','bold');
uicontrol(panel2,T,'position',           [ 30  210 wid  20].*Cp2,'string',sprintf('Baseline simulation:'));
uibasesim=uicontrol(panel2,U,'position', [ 30  180 wid  30].*Cp2,'string',simlist);
uiotherchk=uicontrol(panel2,C,'position',[290  210 wid  30].*Cp2);
uicontrol(panel2,T,'position',           [310  212 wid  20].*Cp2,'string',sprintf('(Optional) Compare to:'));
uiothersim=uicontrol(panel2,U,'position',[290  180 wid  30].*Cp2,'string',simlist,'callback',@simselect2);

uicontrol(panel2,P,'string',sprintf('New infections by year'),      'callback',@plotinfectyear,'position',     [ 30 120 210 30].*Cp2);
uicontrol(panel2,P,'string',sprintf('New infections by population'),'callback',@plotinfectpop,'position',      [290 120 210 30].*Cp2);
uiplotsummary=uicontrol(panel2,P,'string',sprintf('Plot summary indicators'),     'callback',@viewplotsavesummary,'position',[ 30  70 210 30].*Cp2);
uiplotall=    uicontrol(panel2,P,'string',sprintf('Plot all indicators'),         'callback',@viewplotsaveall,'position',    [ 30  20 210 30].*Cp2);
uiviewsummary=uicontrol(panel2,P,'string',sprintf('View summary indicators'),     'callback',@viewplotsavesummary,'position',[290  70 210 30].*Cp2);
uiviewall=    uicontrol(panel2,P,'string',sprintf('View all indicators'),         'callback',@viewplotsaveall,'position',    [290  20 210 30].*Cp2);



%% Create uncertainty panel
uicontrol(panel4,T,'position', [10 140 170  20].*Cp4,'string',sprintf('Uncertainty'),'fontweight','bold');
uncertext={sprintf(' No uncertainty') sprintf(' 50%% bound') sprintf(' 75%% bound') sprintf(' 90%% bound') sprintf(' 95%% bound')};
uiuncerbutt=zeros(5,1);
for q=1:5, uiuncerbutt(q)=uicontrol(panel4,R,'string',uncertext{q},'position',[10 135-q*25 p4wid-20 25].*Cp4,'callback',@uncerbutt,'value',q==1); end



%% Create buttons panel
uicontrol(panel5,T,'position', [10 170 170 20].*Cp5,'string',sprintf('Export data'),'fontweight','bold');
uisavesummary=uicontrol(panel5,P,'string',sprintf('Save summary'),       'callback',@viewplotsavesummary,'position',   [20 130 160 30].*Cp5);
uisaveall=    uicontrol(panel5,P,'string',sprintf('Save all indicators'),'callback',@viewplotsaveall,'position',       [20  90 160 30].*Cp5);
uicontrol(panel5,P,'string',sprintf('Save parameters'),    'callback',@savepars,'position',              [20  50 160 30].*Cp5);
uicontrol(panel5,P,'string',sprintf('Close'),'callback','close','position',                              [50  10 100 30].*Cp5);



    function savepars(~,~) % Save parameters
        if normal
            if get(uiotherchk,'value')+1==2 % Two sims selected: use second
                sims=get(uiothersim,'value');
            else
                sims=get(uibasesim,'value');
            end
            simall=D{sims};
        else % Whether or not to compare two simulations -- if nsims==2, then do
            simall=inputsimall;
        end
        viewsave(projdir,simall.pg,simall.pf,1)
    end



%% Handle years and populations
    function [startyr,endyr,startpt,endpt,pops,sim,sim2]=getusefulstuff
        % What year?
        if normal, startyr=get(uiyrstart,'value'); endyr=get(uiyrfinish,'value');
        else startyr=1; endyr=1; end
        if startyr==1 || endyr==1
            startpt=1; % Start and end points that will be shown
            endpt=pg.npts;
            startyr=pg.simyears(1);
            endyr=pg.simyears(end);
        else
            startyr=pg.simyears(startyr-1);
            endyr=pg.simyears(endyr-1);
            startpt=find(pg.pts==startyr);
            endpt=find(pg.pts==endyr);
        end
        
        % Which populations?
        if normal, popselect=get(uipop,'value');
        else popselect=1; end
        switch popselect
            case 1, pops=1:pg.npops; % All populations
            case 2, pops=1:2; % Low-risk males and females
            case 3, pops=[1 5 6 7 8 9]; % All males
            case 4, pops=[2 3 4 10]; % All females
            case 5, pops=3:4; % Sex workers
            case 6, pops=6:8; % All MSM
            case 7, pops=9:10; % All IDUs
            otherwise, pops=popselect-7; % Select a single population.
        end
        
        % Let's only worry about the baseline simulation for now.
        if normal, sim=D{get(uibasesim,'value')}.allresults{1}; else sim=inputsim; end % "allresults{1}" is the same as ".sim" in most cases
        if normal && get(uiotherchk,'value'), sim2=D{get(uiothersim,'value')}.allresults{1}; else sim2=[]; end
        
        % Now that the sim is loaded, let's see if we need to remove any population groups
        popswithdata=find(~isnan(sum(sim.incidence,2))); % Find which populations have data
        pops=intersect(pops,popswithdata); % Remove any populations that don't have data
    end

%% Handle sims
    function [allsims,labels,allresults]=whichsims
        allsims=cell(1);
        labels=cell(1);
        allresults=cell(1);
        count=0;
        for ii=1:6 % Six comes from the maximum number of simultaneously-selected sims
            if ii==1 || get(uichk(ii),'value')
                count=count+1;
                allsims{count}   =D{get(uisim(ii),'value')}.sim;
                labels{count}    =D{get(uisim(ii),'value')}.description;
                allresults{count}=D{get(uisim(ii),'value')}.allresults;
            end
        end
    end


%% Plot prevalence/incidence for many sims
    function plotprevinci(hObject,~)
        colors={[0 0 0], [0 0.4 0.8], [1 0.6 0], [0 0.5 0], [0.9 0.2 0], [0.5 0.5 0.5]};
        [allsims,labels,allresults]=whichsims;
        [startyr,endyr,startpt,endpt,pops]=getusefulstuff; % Feed it the right tspan
        if startyr==endyr, endyr=endyr+1; endpt=endpt+1; end % Don't try to plot only one year
        % Plot it
        fwid2=500; fhei2=300;
        nolabels=cell(length(pops),1); for i=1:length(pops), nolabels{i}=' '; end
        if hObject==uiplotprev, name1=sprintf('Prevalence in %s, ',poplist{get(uipop,'value')});
        else name1=sprintf('New infections in %s, ',poplist{get(uipop,'value')}); end
        titlename=sprintf('%s%i-%i',name1,startyr,endyr);
        figure('position',[(scrsz(1)-fwid2)/2 (scrsz(2)-fhei2)/2 fwid2 fhei2],'name',titlename,'numbertitle','off','color',[1 1 1])
        % Calculate total prevalence/incidence
        total=zeros(length(allresults{1}),length(allsims),length(startpt:endpt)); % Dimensions are: sim | scenario | time
        for ii=1:length(allsims)
            for jj=1:length(allresults{1})
                if hObject==uiplotprev, % Prevalence
                    peopleinfected=sum(sum(allresults{ii}{jj}.people(2:pg.nstates,pops,startpt:endpt),1),2); % Sum over disease states and populations
                    allpeople=     sum(sum(allresults{ii}{jj}.people(1:pg.nstates,pops,startpt:endpt),1),2); % Sum over all states and populations
                    total(jj,ii,:)=100*squeeze(peopleinfected)./squeeze(allpeople);
                else % Incidence
                    total(jj,ii,:)=sum(allresults{ii}{jj}.incidence(pops,startpt:endpt),1);
                end
            end
        end
        
        % Plot it
        transparency=0.2;
        hold on
        for jj=1:2 % Loop over median vs. uncertainty
            for ii=1:length(allsims)
                [x,y]=makelimits(1,squeeze(total(:,ii,:)),pg.pts(startpt:endpt)); % Arguments are: old-x | new-x | data
                if jj==1, patch(x.lim,y.lim,colors{ii},'linestyle','none','facealpha',transparency)
                else plot(x.med,y.med,'color',colors{ii},'linewidth',2), end
            end
        end
        xlabel('Year'),
        if hObject==uiplotprev, ylabel(sprintf('Prevalence (%%)'))
        else ylabel(sprintf('New infections')), end
        ylim('auto'); tmp=ylim;
        if tmp(1)>0 && tmp(2)>0, ylim([0 tmp(2)]); % All positive: set 0 lower limit
        elseif tmp(1)<0 && tmp(2)<0, ylim([tmp(1) 0]); end % All negative: set 0 upper limit
        % set(gca,'yticklabel',num2str(get(gca,'ytick')')) % To stop scientific notation, uncomment this line
        set(gca,'layer','top')
        title(titlename)
        legend(labels,'location','eastoutside')
    end



%% Create pie chart
    function plotinfectpop(~,~)
        [startyr,endyr,startpt,endpt,pops,sim,sim2]=getusefulstuff;
        compare=get(uiotherchk,'value');
        
        % For each population, calculate the incidence over the requested timespan
        if plotcausehiv==0
            incidtoplot=sum(sim.incidence(pops,startpt:endpt),2);
            plotname='New infections';
        elseif plotcausehiv==1
            incidtoplot=sum(sim.causehiv(pops,startpt:endpt),2);
            plotname='Caused infections';
        end
        if compare, incidtoplot2=sum(sim2.incidence(pops,startpt:endpt),2); popstoplot=find(~isnan(incidtoplot2)); end
        
        % Plot it
        fwid2=700; fhei2=500;
        if compare, fwid2=1000; fhei2=300; end % Make it wider if two graphs
        nolabels=cell(length(pops),1); for ii=1:length(pops), nolabels{ii}=' '; end
        name=cell(compare+1,1);
        for jj=1:compare+1
            if jj==1, thissim=uibasesim; else thissim=uiothersim; end % Pick which sim to get the name from
            if startyr==endyr, name{jj}=sprintf('%s, %i: %s',plotname,startyr,simlist{get(thissim,'value')});
            else name{jj}=sprintf('%s, %i-%i: %s',plotname,startyr,endyr,simlist{get(thissim,'value')}); end
        end
        if ~compare, figname=name{1}; else figname=sprintf('Comparison of "%s" and "%s"',simlist{get(uibasesim,'value')},simlist{get(uiothersim,'value')}); end
        figure('position',[(scrsz(1)-fwid2)/2 (scrsz(2)-fhei2)/2 fwid2 fhei2],'name',figname,'numbertitle','off','color',[1 1 1])
        if ~compare
            ploth(1)=axes('units','normalized','position',[0.1 0.1 0.8 0.8]);
        else
            ploth(1)=axes('units','normalized','position',[0.02 0.1 0.47 0.8]);
            ploth(2)=axes('units','normalized','position',[0.52 0.1 0.47 0.8]);
        end
        
        set(gcf,'currentaxes',ploth(1)); pie(incidtoplot,nolabels);
        if compare, set(gcf,'currentaxes',ploth(2)); pie(incidtoplot2,nolabels(pops)); end
        % Create labels
        labels={popnames(pops),popnames(pops)};
        for jj=1:compare+1
            for ii=1:length(pops)
                if jj==1, pct=100*incidtoplot(ii)/sum(incidtoplot); end
                if jj==2, pct=100*incidtoplot2(ii)/sum(incidtoplot2); end
                if pct<1, numstr='<1';
                else numstr=sprintf('%i',round(pct)); end
                labels{jj}{ii}=[labels{jj}{ii} sprintf(' (%s%%)',numstr)];
            end
            set(gcf,'currentaxes',ploth(jj))
            title(name{jj})
            legend(labels{jj},'location','eastoutside')
        end
    end


%% Create bar graph
    function plotinfectyear(~,~)
        [startyr,endyr,startpt,endpt,pops,sim,sim2]=getusefulstuff;
        compare=get(uiotherchk,'value');
        
        % For each population, calculate the incidence over the requested timespan
        if plotcausehiv==0
            incidtoplot=sim.incidence(pops,startpt:endpt)';
            plotname='New infections';
        elseif plotcausehiv==1
            incidtoplot=sim.causehiv(pops,startpt:endpt)';
            plotname='Caused infections';
        end
        if compare, incidtoplot2=sum(sim2.incidence(pops,startpt:endpt),2); end
        
        fwid2=600; fhei2=300;
        if compare, fwid2=900; fhei2=300; end % Make it wider if two graphs
        name=cell(compare+1,1);
        for jj=1:compare+1
            if jj==1, thissim=uibasesim; else thissim=uiothersim; end % Pick which sim to get the name from
            if startyr==endyr, name{jj}=sprintf('%s, %i: %s',plotname,startyr,simlist{get(thissim,'value')});
            else name{jj}=sprintf('%s, %i-%i: %s',plotname,startyr,endyr,simlist{get(thissim,'value')}); end
        end
        if ~compare, figname=name{1}; else figname=sprintf('Comparison of "%s" and "%s"',simlist{get(uibasesim,'value')},simlist{get(uiothersim,'value')}); end
        figure('position',[(scrsz(1)-fwid2)/2 (scrsz(2)-fhei2)/2 fwid2 fhei2],'name',figname,'numbertitle','off','color',[1 1 1])
        if ~compare
            ploth(1)=axes('units','normalized','position',[0.13 0.13 0.82 0.75]);
        else
            ploth(1)=axes('units','normalized','position',[0.10 0.13 0.30 0.75]);
            ploth(2)=axes('units','normalized','position',[0.47 0.13 0.30 0.75]);
        end
        for jj=1:compare+1
            set(gcf,'currentaxes',ploth(jj))
            if jj==1, bar(pg.pts(startpt:endpt),incidtoplot/1000,0.7,'stack','barwidth',1), end
            if jj==2, bar(pg.pts(startpt:endpt),incidtoplot2/1000,0.7,'stack','barwidth',1), end
            ylim('auto'); tmp=ylim; ylim([0 tmp(2)]); % set(gca,'yticklabel',num2str(get(gca,'ytick')')) % To stop scientific notation, uncomment this
            set(gca,'layer','top')
            ylabel(sprintf('%s (''000s/year)',plotname));
            xlabel('Year')
            if startyr==endyr, startyr=startyr-1; endyr=endyr+1; end; xlim([startyr endyr])
            title(name{jj})
            if jj==compare+1,
                legh=legend(popnames(pops),'location','eastoutside');
                if compare, set(legh,'location','east','units','normalized','position',[0.83 0.13 0.12 0.75]); end
            end
        end
    end


%% Create infections averted graph
    function plotavert(~,~)
        function nothingtocompare % User is trying to compare without anything selected
            fwid2=500; fhei2=100;
            nothing=figure('position',[(scrsz(1)-fwid2)/2 (scrsz(2)-fhei2)/2 fwid2 fhei2],'WindowStyle','modal','name',sprintf('Not enough simulations'),'numbertitle','off','color',[0.9 0.9 0.9]);
            uicontrol(nothing,'Style','text','String',sprintf('Please select at least two simulations; currently only one is selected.'),'units','normalized','position',[0.05 0.4 0.90 0.5],'horizontalalignment','left','backgroundcolor',meh)
            uicontrol(nothing,'Style','pushbutton','string',sprintf('OK'),'callback','close','units','normalized','position',[0.4 0.15 0.2 0.3],'backgroundcolor',pancol,'keypressfcn',@ok);
        end
        
        colors={[0 0 0], [0 0.4 0], [0.8 0.4 0], [0 0.4 0.8], [0 0.8 0.4], [1 0.6 0]};
        [allsims,labels,allresults]=whichsims;
        [startyr,endyr,startpt,endpt,pops]=getusefulstuff; % Feed it the right tspan
        labels=labels(2:end); % Cut off first label
        ntrials=length(allresults{1}); % Number of trials
        ncomps=length(allsims)-1; % Number of comparisons between simulations
        diffincid=zeros(ntrials,length(allresults)-1,1); % -1 because comparing sims
        thoseincid=diffincid; theseincid=diffincid;
        for ii=1:ncomps
            for jj=1:ntrials
                thoseincid(jj,ii)=sum(sum(allresults{1}{jj}.incidence(pops,startpt:endpt)));
                theseincid(jj,ii)=sum(sum(allresults{ii+1}{jj}.incidence(pops,startpt:endpt)));
                diffincid(jj,ii)=thoseincid(jj,ii)-theseincid(jj,ii); % "Infections averted"
            end
        end
        medthose=makelimits(2,thoseincid); % Median and limits for original number of infections
        [meddiff,lowdiff,highdiff]=makelimits(2,diffincid); % Median and limits difference in number of infections
        
        if length(allsims)<2, nothingtocompare % Issue warning
        else
            fwid2=600; fhei2=300;
            % Handle diffincids of various sign
            if all(meddiff>=0), titlename=sprintf('Infections averted');
            elseif all(meddiff<=0), titlename=sprintf('Additional infections'); meddiff=-meddiff; lowdiff=-lowdiff; highdiff=-highdiff;
            else titlename=sprintf('Change in infections'); meddiff=-meddiff; lowdiff=-lowdiff; highdiff=-highdiff;
            end
            if startyr==endyr, name=sprintf('%s in %i',titlename,startyr);
            else name=sprintf('%s, %i-%i',titlename,startyr,endyr); end
            figure('position',[(scrsz(1)-fwid2)/2 (scrsz(2)-fhei2)/2 fwid2 fhei2],'name',name,'numbertitle','off','color',[1 1 1])
            hold on
            for qq=1:2 % Loop over bars vs. uncertainties
                for ii=1:ncomps
                    for jj=1:ncomps
                        toplotm=zeros(ncomps,1); % Median
                        toplotl=toplotm; % Uncertainty lower
                        toplotu=toplotm; % Uncertainty upper
                        if ii==jj
                            toplotm(jj)= meddiff(ii);
                            toplotl(jj)= lowdiff(ii);
                            toplotu(jj)=highdiff(ii);
                            if qq==1, bar(1:ncomps,toplotm,0.5,'facecolor',colors{ii+1});
                            else errorbar(1:ncomps,toplotm,toplotl,toplotu,'color','k','linestyle','none'); end
                        end
                    end
                end
            end
            xlabel(sprintf('Intervention type')), ylabel(titlename), box on
            set(gca,'xtick',1:ncomps), set(gca,'xticklabel',[])
            ylim('auto'); tmp=ylim;
            if tmp(1)>0 && tmp(2)>0, ylim([0 tmp(2)]); % All positive: set 0 lower limit
            elseif tmp(1)<0 && tmp(2)<0, ylim([tmp(1) 0]); end % All negative: set 0 upper limit
            % set(gca,'yticklabel',num2str(get(gca,'ytick')')) % To stop scientific notation, uncomment this
            set(gca,'layer','top')
            for ii=1:length(labels)
                labels{ii}=[labels{ii} sprintf(' (%0i%%)',round(100*meddiff(ii)/medthose(ii)))]; % WARNING -- not sure why medthose is an array
            end
            title(name)
            legend(labels,'location','eastoutside')
        end
    end


% Plot all indicators
    function viewplotsaveall(hObject,~)
        [med,low,high,startpt,endpt,startyr,endyr]=indicators; % Calculate indicators
        titles={sprintf('Prevalence (%%)') sprintf('Number of people infected') sprintf('Incidence') sprintf('Cumulative incidence') sprintf('On 1st-line ART') sprintf('Cumulative 1st-line ART') sprintf('On 2nd-line ART') sprintf('Cumulative on 2nd-line ART') sprintf('HIV-related deaths') sprintf('Cumulative HIV-related deaths') ...
            sprintf('People eligible for 1st-line ART') sprintf('People eligible for 2nd-line ART') sprintf('People with undiagnosed HIV') sprintf('HIV-infected people, CD4>500') sprintf('HIV-infected people, 350<CD4<500') sprintf('HIV-infected people, 200<CD4<350') sprintf('HIV-infected people, CD4<200') ...
            sprintf('Children exposed to HIV') sprintf('Cumulative children exposed to HIV') sprintf('Children infected by HIV') sprintf('Cumulative children infected by HIV')};
        flds=fieldnames(med{1});
        if normal, popname=poplist{get(uipop,'value')}; else popname='All populations'; end
        indimed=cell(21,1); % Store all indicators: medians
        indilow=indimed; % Store all indicators: lower limit
        indihigh=indimed; % Store all indicators: upper limit
        
        for ii=1:21
            if length(med)==1 % There's only one sim: it's simple.
                titlename=sprintf('Indicators (%s), %i-%i',popname,startyr,endyr);
                indimed{ii} = med{1}.(flds{ii}); % Median
                indilow{ii} = low{1}.(flds{ii}); % Lower limit
                indihigh{ii}=high{1}.(flds{ii}); % Upper limit
            else % There are two sims: find the difference
                titlename=sprintf('Number of infections averted (%s), %i-%i',popname,startyr,endyr);
                indimed{ii} = med{2}.(flds{ii})-med{1}.(flds{ii}); % Median
                indilow{ii} = low{2}.(flds{ii})-med{1}.(flds{ii}); % Lower limit; note: could also do low-high instead of low-med for more uncertainty
                indihigh{ii}=high{2}.(flds{ii})-med{1}.(flds{ii}); % Upper limit
            end
        end
        
        
        if hObject==uiplotall
            fwid2=1000; fhei2=650; Cf2=[1/fwid2 1/fhei2 1/fwid2 1/fhei2];
            plotallfig=figure('position',[(scrsz(1)-fwid2)/2 (scrsz(2)-fhei2)/2 fwid2 fhei2],'name',titlename,'numbertitle','off','color',[1 1 1]);
            allaxes=zeros(20,1);
            for ii=1:20
                col=mod(ii-1,4);
                row=floor((ii-1)/4);
                allaxes(ii)=axes('parent',plotallfig,'units','normalized','position',[70+240*col 570-130*row 170 50].*Cf2);
                if startyr~=endyr
                    patch([pg.pts(startpt:endpt) fliplr(pg.pts(startpt:endpt))],[indilow{ii} fliplr(indihigh{ii})],[0 0 0]+0.9,'linestyle','none','parent',allaxes(ii));
                    hold on
                    plot(allaxes(ii),pg.pts(startpt:endpt),indimed{ii},'k','linewidth',2)
                else
                    bar(allaxes(ii),pg.pts(startpt),indimed{ii},'k'), xlim([startyr-1,endyr+1])
                    hold on
                    errorbar(allaxes(ii),pg.pts(startpt),indimed{ii},indimed{ii}-indilow{ii},indihigh{ii}-indimed{ii},'color','k','linestyle','none');
                end
                ylim('auto'); tmp=ylim;
                if tmp(1)>0 && tmp(2)>0, ylim([0 tmp(2)]); % All positive: set 0 lower limit
                elseif tmp(1)<0 && tmp(2)<0, ylim([tmp(1) 0]); end % All negative: set 0 upper limit
                % set(allaxes(ii),'yticklabel',num2str(get(gca,'ytick')')) % To stop scientific notation, uncomment this
                set(gca,'layer','top')
                title(titles{ii})
                xlabel('Year'), box on
            end
            
        elseif hObject==uiviewall % "View all" was clicked
            fwid2=900; fhei2=360; Cf2=[1/fwid2 1/fhei2 1/fwid2 1/fhei2];
            viewallfig=figure('position',[(scrsz(1)-fwid2)/2 (scrsz(2)-fhei2)/2 fwid2 fhei2],'name',titlename,'numbertitle','off','color',meh);
            T.style='text'; T.units='normalized'; T.horizontalalignment='right'; T.backgroundcolor=meh;
            uicontrol(viewallfig,'style','pushbutton','string',sprintf('OK'),'callback','close','units','normalized','position',[400 20 100 30].*Cf2,'backgroundcolor',pancol)
            for ii=1:20
                col=floor((ii-1)/10);
                row=mod(ii-1,10)+1;
                plotaspercent=1;
                plotasmean   =[2 3 5 7 9 11:18 20];
                plotasend    =[4 6 8 10 19];
                if     any(plotaspercent==ii), indimed{ii}=round(100*mean(indimed{ii}))/100; suffix=sprintf(' (average): ');
                elseif any(plotasmean==ii),    indimed{ii}=round(mean(indimed{ii})); suffix=sprintf(' (average): ');
                elseif any(plotasend==ii),     indimed{ii}=round(indimed{ii}(end)); suffix=sprintf(' (total): ');
                else error('This index has not been assigned to a plot method!')
                end
                uicontrol(viewallfig,T,'string',[titles{ii} suffix],'position',[ 5+450*col 350-row*30 300 30].*Cf2)
                uicontrol(viewallfig,T,'string',num2str(indimed{ii}(end)),'position',[310+450*col 350-row*30 70 30].*Cf2)
            end
            
        elseif hObject==uisaveall % "Save all" was clicked
            [file,path]=uiputfile('*.txt',sprintf('Save parameters to a plain text file'),fullfile(projdir,'indicators.txt'));
            if file~=0
                nind=21; % Number of indicators
                nyrs=endyr-startyr+1; % Number of years to plot
                rpi=4; % Number of rows per indicator: max/best/min/space
                startinds=2:rpi:nind*rpi+1; % Indices to start each parameter on
                nrows=startinds(end)+rpi-1; % Total number of rows to be printed
                everything=cell(nrows,2+nyrs); % Store every value to print; 85 = headers + 21 parameters * 4 lines/parameter
                everything{1,1}=sprintf('INDICATOR'); everything{1,2}=sprintf('YEAR:');
                for ii=1:nind % Add indicator names and min/best/max rows
                    everything{3+(ii-1)*rpi+1,1}=titles{ii};
                    everything{3+(ii-1)*rpi+0,2}=sprintf('Max');
                    everything{3+(ii-1)*rpi+1,2}=sprintf('Best');
                    everything{3+(ii-1)*rpi+2,2}=sprintf('Min');
                end
                for ii=1:nyrs, everything{1,2+ii}=num2str(startyr+ii-1); end % Add year names
                for ii=1:nind
                    thisindimed = indimed{ii}; % Get this particular output indicator
                    thisindilow = indilow{ii};
                    thisindihigh=indihigh{ii};
                    if ii~=1  % Don't round prevalence, but round everything else
                        thisindimed =round(thisindimed);
                        thisindilow =round(thisindilow);
                        thisindihigh=round(thisindihigh);
                    end
                    for jj=1:nyrs
                        everything{3+(ii-1)*rpi+1,2+jj}=num2str(thisindimed(jj));
                        if ci>0
                            everything{3+(ii-1)*rpi+0,2+jj}=num2str(thisindihigh(jj));
                            everything{3+(ii-1)*rpi+2,2+jj}=num2str(thisindilow(jj));
                        end
                        
                    end
                end
                
                allstrings=zeros(nrows,46+nyrs*11); % Initialize a huge array to store all the strings
                outformat='%35s\t%10s'; for ii=1:nyrs, outformat=strcat(outformat,'\t%10s'); end % Append to the format however many years there are values for
                for ii=1:nrows, allstrings(ii,:)=sprintf(outformat,everything{ii,:}); end
                dlmwrite(fullfile(path,file),char(allstrings),'delimiter',''); % Write to file!
                
                fwid2=500; fhei2=100;
                confirm=figure('position',[(scrsz(1)-fwid2)/2 (scrsz(2)-fhei2)/2 fwid2 fhei2],'WindowStyle','modal','name',sprintf('Parameters saved'),'numbertitle','off','color',meh,'keypressfcn','close');
                uicontrol(confirm,'Style','text','String',sprintf('Data saved to file "%s".',file),'units','normalized','position',[0.05 0.4 0.90 0.5],'horizontalalignment','left','backgroundcolor',meh)
                uicontrol(confirm,'Style','pushbutton','string',sprintf('OK'),'callback','close','units','normalized','position',[0.4 0.05 0.20 0.3],'backgroundcolor',meh);
            end
        else error('Unknown button! E-mail c.kerr@unsw.edu.au for a corrected version of this software.')
        end
        
    end



    function viewplotsavesummary(hObject,~)
        [med,low,high,startpt,endpt,startyr,endyr]=indicators; % Calculate indicators
        titles={sprintf('Adults living with HIV/AIDS') sprintf('New HIV infections') sprintf('HIV/AIDS-related deaths') sprintf('Adults eligible for first-line ART') sprintf('Adults requiring second-line ART') sprintf('Children infected with HIV')};
        flds={'infected' 'inci' 'death' 'elig1st' 'elig2nd' 'childinf'};
        indimed=cell(6,1); % Store all indicators: medians
        indilow=indimed; % Store all indicators: lower limit
        indihigh=indimed; % Store all indicators: upper limit
        if normal, popname=poplist{get(uipop,'value')}; else popname='All populations'; end
        
        for ii=1:6
            if length(med)==1 % There's only one sim: it's simple.
                titlename=sprintf('Indicators (%s), %i-%i',popname,startyr,endyr);
                indimed{ii} = med{1}.(flds{ii}); % Median
                indilow{ii} = low{1}.(flds{ii}); % Lower limit
                indihigh{ii}=high{1}.(flds{ii}); % Upper limit
            else % There are two sims: find the difference
                titlename=sprintf('Number of infections averted (%s), %i-%i',poplist{get(uipop,'value')},startyr,endyr);
                indimed{ii} = med{2}.(flds{ii})-med{1}.(flds{ii}); % Median
                indilow{ii} = low{2}.(flds{ii})-med{1}.(flds{ii}); % Lower limit; note: could also do low-high instead of low-med for more uncertainty
                indihigh{ii}=high{2}.(flds{ii})-med{1}.(flds{ii}); % Upper limit
            end
        end
        
        if hObject==uiplotsummary % "Plot summary" was clicked
            fwid2=1000; fhei2=650; Cf2=[1/fwid2 1/fhei2 1/fwid2 1/fhei2];
            plotallfig=figure('position',[(scrsz(1)-fwid2)/2 (scrsz(2)-fhei2)/2 fwid2 fhei2],'name',titlename,'numbertitle','off','color',[1 1 1]);
            allaxes=zeros(6,1);
            for ii=1:6
                col=mod(ii-1,2);
                row=floor((ii-1)/2);
                allaxes(ii)=axes('parent',plotallfig,'units','normalized','position',[70+500*col 480-210*row 410 140].*Cf2);
                if startyr~=endyr
                    patch([pg.pts(startpt:endpt) fliplr(pg.pts(startpt:endpt))],[indilow{ii} fliplr(indihigh{ii})],[0 0 0]+0.9,'linestyle','none')
                    hold on
                    plot(pg.pts(startpt:endpt),indimed{ii},'k','linewidth',2)
                else
                    bar(pg.pts(startpt),indimed{ii},'k'), xlim([startyr-1,endyr+1])
                    hold on
                    errorbar(pg.pts(startpt),indimed{ii},indimed{ii}-indilow{ii},indihigh{ii}-indimed{ii},'color','k','linestyle','none');
                end
                
                ylim('auto'); tmp=ylim;
                if tmp(1)>0 && tmp(2)>0, ylim([0 tmp(2)]); % All positive: set 0 lower limit
                elseif tmp(1)<0 && tmp(2)<0, ylim([tmp(1) 0]); end % All negative: set 0 upper limit
                % set(gca,'yticklabel',num2str(get(gca,'ytick')')) % To stop scientific notation, uncomment this
                set(gca,'layer','top')
                title(titles{ii})
                xlabel('Year'), box on
            end
            
        elseif hObject==uiviewsummary % "View summary" was clicked
            fwid2=450; fhei2=250; Cf2=[1/fwid2 1/fhei2 1/fwid2 1/fhei2];
            viewallfig=figure('position',[(scrsz(1)-fwid2)/2 (scrsz(2)-fhei2)/2 fwid2 fhei2],'name',titlename,'numbertitle','off','color',meh);
            T.style='text'; T.units='normalized'; T.horizontalalignment='right'; T.backgroundcolor=meh;
            uicontrol(viewallfig,'style','pushbutton','string',sprintf('OK'),'callback','close','units','normalized','position',[175 20 100 30].*Cf2,'backgroundcolor',pancol,'keypressfcn',@ok)
            for ii=1:6
                if ii==1 || ii==4 || ii==5, indimed{ii}=round(mean(indimed{ii})); suffix=sprintf(' (average): ');
                else indimed{ii}=round(sum(indimed{ii})); suffix=sprintf(' (total): '); end
                uicontrol(viewallfig,T,'string',[titles{ii} suffix],'position',[ 20 240-ii*30 300 30].*Cf2)
                uicontrol(viewallfig,T,'string',num2str(indimed{ii}),'position',[330 240-ii*30 80 30].*Cf2)
            end
            
        elseif hObject==uisavesummary % "Save summary" was clicked
            [file,path]=uiputfile('*.txt',sprintf('Save parameters to a plain text file'),fullfile(projdir,'summary.txt'));
            if file~=0
                nind=6; % Number of indicators
                rpi=4; % Number of rows per indicator: max/best/min/space
                nyrs=endyr-startyr+1; % Number of years to plot
                startinds=2:rpi:nind*rpi+1; % Indices to start each parameter on
                nrows=startinds(end)+rpi-1; % Total number of rows to be printed
                everything=cell(nrows,2+nyrs); % Store every value to print; 26 = 2 headers + 6 parameters * 4 lines/parameter
                everything{1,1}=sprintf('INDICATOR'); everything{1,2}=sprintf('YEAR:');
                for ii=1:nind % Add indicator names
                    everything{3+(ii-1)*rpi+1,1}=titles{ii};
                    everything{3+(ii-1)*rpi+0,2}=sprintf('Max');
                    everything{3+(ii-1)*rpi+1,2}=sprintf('Best');
                    everything{3+(ii-1)*rpi+2,2}=sprintf('Min');
                end
                for ii=1:nyrs, everything{1,2+ii}=num2str(startyr+ii-1); end % Add year names
                for ii=1:nind
                    thisindimed = indimed{ii}; % Get this particular output indicator
                    thisindilow = indilow{ii};
                    thisindihigh=indihigh{ii};
                    thisindimed =round(thisindimed); % Round
                    thisindilow =round(thisindilow);
                    thisindihigh=round(thisindihigh);
                    
                    for jj=1:nyrs
                        everything{3+(ii-1)*rpi+1,2+jj}=num2str(thisindimed(jj));
                        if ci>0
                            everything{3+(ii-1)*rpi+0,2+jj}=num2str(thisindihigh(jj));
                            everything{3+(ii-1)*rpi+2,2+jj}=num2str(thisindilow(jj));
                        end
                        
                    end
                end
                
                allstrings=zeros(nrows,46+nyrs*11); % Initialize a huge array to store all the strings
                outformat='%35s\t%10s'; for ii=1:nyrs, outformat=strcat(outformat,'\t%10s'); end % Append to the format however many years there are values for
                for ii=1:nrows, allstrings(ii,:)=sprintf(outformat,everything{ii,:}); end
                dlmwrite(fullfile(path,file),char(allstrings),'delimiter',''); % Write to file!
                
                fwid2=500; fhei2=100;
                confirm=figure('position',[(scrsz(1)-fwid2)/2 (scrsz(2)-fhei2)/2 fwid2 fhei2],'WindowStyle','modal','name',sprintf('Parameters saved'),'numbertitle','off','color',meh,'keypressfcn','close');
                uicontrol(confirm,'Style','text','String',sprintf('Data saved to file "%s".',file),'units','normalized','position',[0.05 0.4 0.90 0.5],'horizontalalignment','left','backgroundcolor',meh)
                uicontrol(confirm,'Style','pushbutton','string',sprintf('OK'),'callback','close','units','normalized','position',[0.4 0.05 0.20 0.3],'backgroundcolor',meh);
            end
        else error('Unknown button, sorry! Please contact c.kerr@unsw.edu.au for an update.')
        end
        
    end







%% INDICATORS
% This function calculates all the key indicators.
% med = median; lim = limits
    function [med,low,high,startpt,endpt,startyr,endyr]=indicators
        [startyr,endyr,startpt,endpt,pops]=getusefulstuff;
        
        
        if normal
            if get(uiotherchk,'value')+1==2 % Two sims selected: use second
                sims=get(uiothersim,'value');
            else
                sims=get(uibasesim,'value');
            end
            simall=D{sims};
        else % Whether or not to compare two simulations -- if nsims==2, then do
            simall=inputsimall;
        end
        
        if normal % Figure out which sims to load
            nsims=get(uiotherchk,'value')+1;
            sims=get(uibasesim,'value');
            if nsims==2 % Whether or not to compare two simulations -- if nsims==2, then do
                sims=[sims get(uiothersim,'value')];
            end
        else
            nsims=1;
        end
        
        fullresults=cell(nsims,1); % Dimension is: number of simulations being compared
        for ii=1:nsims
            if normal % Normal case: load from disk
                fullresults{ii}=D{sims(ii)}.allresults;
            else % From chem and from graphfig: Calculate
                fullresults{ii}=uncertainty(1,projdir,simall.pg,simall.pm); % Rerun simulation to make sure all output quantities have been calculated
            end
        end
        ntrials=min([length(fullresults{1}) length(fullresults{nsims})]); % Calculate the total number of uncertainty trials
        
        % Calculate each of the 21 interesting quantities
        out=cell(nsims,1); % Dimensions are: number of randomized trials | number of simulations being compared
        for jj=1:ntrials
            for ii=1:nsims
                % Prevalence
                pm=simall.pm; % Used a lot so shorten it
                peopleinfected=squeeze(sum(sum(fullresults{ii}{jj}.people(2:pg.nstates,pops,startpt:endpt),1),2)); % Sum over disease states and populations
                allpeople=     squeeze(sum(sum(fullresults{ii}{jj}.people(1:pg.nstates,pops,startpt:endpt),1),2)); % Sum over all states and populations
                eligible=find(sum(pm.sig(1:4,:),2)>0); % Figure out which CD4 states have non-zero treatment rates
                out{ii}.prev{jj}        = round(10000*peopleinfected./allpeople)/100; % Save two significant figures of the prevalence data, and convert to percent
                out{ii}.infected{jj}    = peopleinfected; % Number infected
                out{ii}.inci{jj}        = sum(fullresults{ii}{jj}.incidence(pops,startpt:endpt),1)'; % Incidence
                out{ii}.cuminci{jj}     = cumsum(out{ii}.inci{jj}); % Cumulative incidence
                out{ii}.treat1st{jj}    = sum(fullresults{ii}{jj}.treat1st(pops,startpt:endpt),1)'; % Number of people on first-line treatment
                out{ii}.cumtreat1st{jj} = cumsum(out{ii}.treat1st{jj}); % Cumulative number of people who start first-line treatment
                out{ii}.treat2nd{jj}    = sum(fullresults{ii}{jj}.treat2nd(pops,startpt:endpt),1)'; % Number of people on second-line treatment
                out{ii}.cumtreat2nd{jj} = cumsum(out{ii}.treat2nd{jj}); % Cumulative number of people who start second-line treatment
                out{ii}.death{jj}       = sum(fullresults{ii}{jj}.death(pops,startpt:endpt),1)'; % Number of people who die of HIV
                out{ii}.cumdeath{jj}    = cumsum(out{ii}.death{jj}); % Cumulative number of people who die ov HIV
                out{ii}.elig1st{jj}     = squeeze(sum(sum(fullresults{ii}{jj}.people([eligible+1 eligible+5],pops,startpt:endpt),1),2)); % Number of people eligible for first-line treatment
                out{ii}.elig2nd{jj}     = squeeze(sum(fullresults{ii}{jj}.people(11,       pops,startpt:endpt),2)); % Number of people eligible for second-line treatment
                out{ii}.undiag{jj}      = squeeze(sum(sum(fullresults{ii}{jj}.people(2:5,  pops,startpt:endpt),1),2)); % Number of people undiagnosed
                out{ii}.cd500{jj}       = squeeze(sum(sum(fullresults{ii}{jj}.people([2 6],pops,startpt:endpt),1),2)); % Number of people CD4>500
                out{ii}.cd350{jj}       = squeeze(sum(sum(fullresults{ii}{jj}.people([3 7],pops,startpt:endpt),1),2)); % Number of people 350<CD4<500
                out{ii}.cd200{jj}       = squeeze(sum(sum(fullresults{ii}{jj}.people([4 8],pops,startpt:endpt),1),2)); % Number of people 200<CD4<350
                out{ii}.cd0{jj}         = squeeze(sum(sum(fullresults{ii}{jj}.people([5 9],pops,startpt:endpt),1),2)); % Number of people CD4<200
                
                % Deal with children
                womenpops=intersect(pops,[2:4 10]); % Find out which of the populations selected are female
                if ~isempty(womenpops) % Don't do the child calculation if no women were selected
                    infectedwomen=squeeze(sum(sum(fullresults{ii}{jj}.people(2:12,womenpops,startpt:endpt),1),2)); % Number of infected women
                    out{ii}.childexp{jj}= infectedwomen.*pm.pmt.birth(startpt:endpt)';
                else
                    out{ii}.childexp{jj}= zeros(length(startpt:endpt),1);
                end
                out{ii}.cumchildexp{jj} = cumsum(out{ii}.childexp{jj});
                out{ii}.childinf{jj}    = out{ii}.childexp{jj}.*(1-pm.pmt.prob(startpt:endpt))'*pm.pmt.beta; % Assume zero risk of infection if mother is on PMTCT
                out{ii}.cumchildinf{jj} = cumsum(out{ii}.childinf{jj});
            end
        end
        
        % Turn "out" into a median and limit
        flds=fieldnames(out{1}); % Get field names for out
        nflds=length(flds); % Find out how many quantities there are -- should be 21
        med=cell(nsims,1); % Define the output: median
        low=med; high=med; % Define upper and lower limits
        for ii=1:nsims
            for jj=1:nflds
                [med{ii}.(flds{jj}),low{ii}.(flds{jj}),high{ii}.(flds{jj})]=makelimits(3,cell2mat(out{ii}.(flds{jj}))');
            end
        end
        
        
    end


% Take an input variable and turn it into either a patch or a min-max
% tuple. Mostly copied from uncertainty.m (warning, kludgy!)
    function [x,y,z]=makelimits(plottype,data,origx)
        npts=101; % Number of time points to interpolate over
        if ci==0, ntrials=1; % Pick out first entry
        else ntrials=size(data,1); end
        
        switch ci % Decide what to do with the confidence interval
            case {0   }, mmm=[1                     1                1]; % Ceil is to reject more trials; "mmm" is for "min middle max"
            case {1,50}, mmm=[1+10*ceil(ntrials/40) round(ntrials/2) ntrials-10*ceil(ntrials/40)]; % Ceil is to reject more trials; "mmm" is for "min middle max"
            case {2,75}, mmm=[1+ 5*ceil(ntrials/40) round(ntrials/2) ntrials- 5*ceil(ntrials/40)];
            case {3,90}, mmm=[1+ 2*ceil(ntrials/40) round(ntrials/2) ntrials- 2*ceil(ntrials/40)];
            case {4,95}, mmm=[1+ 1*ceil(ntrials/40) round(ntrials/2) ntrials- 1*ceil(ntrials/40)];
        end
        if ci>0, data=sort(data,1); end % Sort each time point if uncertainty is asked for
        data=data(mmm,:); % Pick out lower-med-upper
        
        switch plottype
            case 1 % Prevalence/incidence
                newx=linspace(origx(1),origx(end),npts); % Use 100 time points
                low =smoothfit(origx,data(1,:),newx,1); % Smooth lower limit
                med =smoothfit(origx,data(2,:),newx,1); % Smooth median
                high=smoothfit(origx,data(3,:),newx,1); % Smooth upper limit
                x.med=newx; % Time points for median
                y.med=med; % Data for median
                x.lim=[newx fliplr(newx)]; % Time points for uncertainty
                y.lim=[low fliplr(high)]; % Data for uncertainty
            case 2 % Infections averted
                x=data(2,:); % Median
                y=x-data(1,:);
                z=data(3,:)-x; % Lower and upper limits
            case 3 % Indicators
                x=data(2,:); % Median
                y=data(1,:); % Lower limit
                z=data(3,:); % Upper limit
        end
        
        
    end

end

function ok(~,e), if strcmp(e.Key,'return'), close, end, end % Close windows