%% ERRORSHADE
% This function creates a plot with a shaded area representing the
% uncertainty; it can be thought of as a much more beautiful version of
% errorbar.
% 
% Usage:
%   [handle1,handle2]=errorshade(x,y,errlower,[errupper,color,alpha])
%
% where
%   handle1 is the patch object handle
%   handle2 is the line object handle
%   x is the x-axis data
%   y is the y-axis data (or empty array, [])
%   errlower is the lower or only error (relative to y unless y is empty)
%   errupper is the upper error (or empty array, [])
%   color is the line and patch color, an RGB triplet (default black)
%   alpha is the opacity of the patch (default 10%)
%
% If y, errlower, and errupper are all provided, then errlower and errupper
% are relative to y. If y is empty, then errlower and errupper are
% absolute. If y and errlower are provided but errupper is empty, then
% errupper is assumed to be the opposite of errlower (i.e., symmetric
% confidence intervals). Note that errors can have any sign, so long as
% they all have the same sign.
%
% Example:
%   x=0:0.1:10;
%   h=errorshade(x,x.^2,-x,sqrt(x)*10,[0 0.5 1],0.3)
%
% Version: 2012sep30

function [handle1,handle2]=errorshade(varargin)

%% Read in input arguments
x=reshape(varargin{1},[],1); % X axis data
origy=reshape(varargin{2},[],1); % Baseline Y axis data
errlower=reshape(varargin{3},[],1); % Lower error bound
if nargin>=4, errupper=reshape(varargin{4},[],1); else errupper=[]; end % Upper error bound
if nargin>=5, patchcolor=varargin{5}; else patchcolor=[0 0 0]; end % Face color; default black
if nargin>=6, opacity=varargin{6}; else opacity=0.1; end % Patch opacity; default 10%


%% Handle input argument
% Check that the user has entered enough data
if isempty(errlower) || (isempty(origy)+isempty(errupper))>1 % errlower must be defined, along with one of the other two
    error('Either Y and a lower error bound, or lower and upper error bounds, must be defined.')
% Handle different cases: here, y is not supplied but error bounds are
elseif isempty(origy)
    if length(errlower)~=length(errupper), error('All vectors must be the same length!'), end
    y=(errlower+errupper)/2;
    errlower=errlower-y; % Reset errlower
    errupper=errupper-y; % Reset errupper
% Handle different cases: here, errupper is not supplied but y and the lower bound are
elseif isempty(errupper)
    y=origy;
    if length(y)~=length(errlower), error('All vectors must be the same length!'), end
    errupper=-errlower; % Upper error is lower error flipped (maybe, we'll check later)
else
    y=origy;
end


%% Check for errors
% Check if lower errors are positive or negative
if     all(errlower<=0) % All negative: do nothing
elseif all(errlower>=0), errlower=-errlower; % All positive: flip sign
else error('Error bounds must be all positive or negative!')
end
% Check if upper errors are positive or negative
if     all(errupper>=0) % All positive: do nothing
elseif all(errupper<=0), errupper=-errupper; % All negative: flip sign
else error('Error bounds must be all positive or negative!')
end


%% Create patch objects
upper=y+errupper; % Define upper bound of patch
lower=y+errlower; % Define lower bound of patch
xpatch=[x; flipud(x)]; % Create x data by copying and flipping the input x axis
ypatch=[upper; flipud(lower)]; % Create y data by combining upper with flipped-lower data


%% Do plotting
orighold=ishold; % Get the current state of whether the figure is being held
handle1=patch(xpatch,ypatch,patchcolor,'facealpha',opacity,'linestyle','none');
if ~isempty(origy)
    if ~orighold, hold on; end
    handle2=plot(x,y,'color',patchcolor,'linewidth',2);
    if ~orighold, hold off; end
end


end