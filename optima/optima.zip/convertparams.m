%% CONVERTPARAMS
% For converting between vectors and structures of parameters.
% WARNING: it looks like I'm making the table each time. I only need to
% make it once. And perhaps I should make it earlier, so I can avoid
% "valuesvector" altogether.
% Version 2012oct04

function varargout=convertparams(conversiontype,varargin)

switch conversiontype
    
    case 'struct2vec'
        maxparams=1e5; % Maximum number of parameters -- just make it big
        parstruct=varargin{1};
        equations=varargin{2};
        maketable=varargin{3};
        count=0;
        parvec.vec=zeros(maxparams,1); % Create the vector part of parvec (which itself is "parameter vector")
        if maketable, vec2structtable=cell(maxparams,3); end
        for phylum=1:length(equations.phyla);
            families=fieldnames(parstruct.(equations.phyla{phylum}));
            for family=1:length(families)
                thesevalues=parstruct.(equations.phyla{phylum}).(families{family});
                nvalues=size((thesevalues),2); % Bug: had length, but this was collecting quantiles!
                for val=1:nvalues
                    count=count+1;
                    parvec.vec(count)=thesevalues(val);
                    if maketable % Make everything needed for storing vector as structure: phylum, family, and value
                        vec2structtable{count,1}=equations.phyla{phylum};
                        vec2structtable{count,2}=families{family};
                        vec2structtable{count,3}=val;
                    end
                end
            end
        end
        parvec.vec=parvec.vec(1:count); % Trim extra
        parvec.partnerships=parstruct.partnerships; % Keep partnerships and transitions unchnaged -- i.e. not a vector
        parvec.transitions=parstruct.transitions;
        varargout{1}=parvec; % Copy parvec to output
        if maketable, varargout{2}=vec2structtable(1:count,:); end % Optionally create a table allowing conversion from the vector back to the structure
        
    case 'vec2struct'
        vec2structtable=varargin{1};
        parvec=varargin{2};
        nvalues=length(vec2structtable);
        assert(nvalues==length(parvec.vec),'Vectors are of different lengths!')
        for val=1:nvalues
            parstruct.(vec2structtable{val,1}).(vec2structtable{val,2})(vec2structtable{val,3})=parvec.vec(val); % Population structure from values in vector
        end
        parstruct.partnerships=parvec.partnerships; % Keep partnerships and transitions unchnaged -- i.e. not a vector
        parstruct.transitions=parvec.transitions;
        varargout{1}=parstruct;
        
    otherwise
        error('Conversion command %s not recognized',conversiontype)
        
end


end