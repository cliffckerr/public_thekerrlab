%% FINDERROR
% This function calculates an error based on a prediction and quantiles.
% Usage:
%   err=finderror(prediction,qx,qy,whicherror)
%
% where
%   err is the mismatch between the prediction and the data
%   prediction is the estimated value (e.g. 0.4)
%   qx is the x-values of the quantiles (e.g. [0 0.025 0.5 0.975 1])
%   qy is the y-values if the quantiles (e.g. [0 0.2 0.3 0.5 1])
%   whicherror chooses which error metric to use
%
% Version: 2013jan21

function err=finderror(prediction,qx,qy)
qx=qx(:); qy=qy(:)'; % Turn into column vectors
nquantiles=length(qy);
showwarnings=0;
whicherror=3; % This seems to be best
monocorrection=0.1; % Fraction by which to break ties (1st method)
tiebreak=1e-2; % Fraction by which to break ties (2nd method)

if prediction>0 && qy(2)==0 % Make it small but nonzero by an arbitrary amount
    if showwarnings==1, warning('finderror:lower','Lower bound corrected'), end
    qy(2)=min(1e-3,prediction/100);
end

for i=3:nquantiles
    if qy(i)<qy(i-1)
        if showwarnings==1, warning('finderror:nonmono','Quantiles not monotonic: %f vs. %f',qy(i),qy(i-1)), end
        qy(i)=qy(i-1)*(1+monocorrection); 
    end
end

if length(unique(qy))<length(qy) % Check to make sure that different quantiles actually have different values: no, just say it's 0.5
    if showwarnings==1, warning('finderror:nonunique',['Quantiles not all unique!\n' num2str(qy)]), end
    straightline=qy(1)+(qy(end)-qy(1))*(0:length(qy)-1)/(length(qy)-1);
    difference=straightline-qy;
    qy=qy+difference*tiebreak; % Stretch y along a straight line to break ties
end


% Just use upper and lower quantiles as some kind of fixed confidence interval
if whicherror==1 || whicherror==3 || whicherror==4
    if prediction>qy(3) % Prediction is too big, use upper bound
        err1=(prediction-qy(3))/(qy(4)-qy(3));
    elseif prediction<qy(3) % Prediction is too small, use lower bound
        err1=(qy(3)-prediction)/(qy(3)-qy(2));
    else % Woo, exactly right size!
        err1=0;
    end
end
    
% Calculate actual probability from the quantiles
if whicherror==2 || whicherror==3 || whicherror==4
    q = flexiquantile(prediction,qx,qy);
    if q<0.5
        err2=log(1/(2*q)); % To log or not to log...
    elseif q>0.5
        err2=log(1/(2*(1-q)));
    else
        err2=0;
    end
end

if     whicherror==1, err=err1;
elseif whicherror==2, err=err2;
elseif whicherror==3, err=(err1+err2)^2;
elseif whicherror==4, err=err1*err2;
end

% Check that nothing weird happened
if isnan(err), warning('finderror:nanerror','Error is a nan! This isn''t good!'), keyboard, end
if err>1e12,   warning('finderror:hugeerror','Error is huge! This isn''t good!'), keyboard, end

end