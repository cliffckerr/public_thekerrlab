%% STATISTICS
% This code calculates and plots statistics of a run.
% Version: 2012sep30

disp('Statistics:')
tic

if ~exist('matfilename','var')
    matfilename='./vietnam/wb.mat';
end
d=load(matfilename);
pts=d.data.general.pts; % Time points


nsimstouse=200; % How many simulations to select
simstouse=1:nsimstouse; % For plotting, duplicates don't matter
nsimstouse=length(simstouse);
fprintf('  Unique simulations: %i\n',nsimstouse)
npops=size(d.data.hivprevalence,2);
nsims=length(d.simsets);
plotorder=1:length(d.finaltotalerrors);
cols=vectocolor(nsimstouse:-1:1);
cols=(cols+1)/2;
simstouse=simstouse(plotorder)';


%% Kludgy stff copied out of counterfactual.m
% Calculate costs
disp('Calculating costing...')
costs=zeros(nsimstouse,3);
qalys=zeros(nsimstouse,3);
for s=1:nsimstouse
    origcost = healthEcon(d.simsets{simstouse(s)},d.data);
    nspcost = healthEcon(d.scenarios(1).simsets{simstouse(s)},d.data);
    mmtcost = healthEcon(d.scenarios(2).simsets{simstouse(s)},d.data);
    nyears=size(origcost.HIVHealthCareCost,2);
%     nsamples=size(origcost.HIVHealthCareCost,3);
%     keyboard
    totalorigcost=sum(origcost.HIVHealthCareCost_disc)/nyears;
    totalmmtcost=sum(mmtcost.HIVHealthCareCost_disc)/nyears;
    totalnspcost=sum(nspcost.HIVHealthCareCost_disc)/nyears;
    
    totalorigqaly=sum(origcost.HIVQALY_disc)/nyears;
    totalmmtqaly=sum(mmtcost.HIVQALY_disc)/nyears;
    totalnspqaly=sum(nspcost.HIVQALY_disc)/nyears;
    
%     disp(totalorigqaly/80000)
    costs(s,1)=totalorigcost;
    costs(s,2)=totalnspcost-totalorigcost;
    costs(s,3)=totalmmtcost-totalorigcost;
    
    qalys(s,1)=totalorigqaly;
    qalys(s,2)=totalorigqaly-totalnspqaly;
    qalys(s,3)=totalorigqaly-totalmmtqaly;
    %% Checking point for QALYs per person years
    y = squeeze(d.simsets{simstouse(s)}.people(:,1,1:1/d.data.general.timestep:end));
    y=y';
    popsize = sum(y,2);
    disp('qalys per person years')
    disp(qalys(s,1)/median(popsize));
%     keyboard
end
disp('Costs:')
disp(['  Original cost: $' dispnum(costs(:,1))])
disp(['  NSP savings:   $' dispnum(costs(:,2))])
disp(['  MMT savings:   $' dispnum(costs(:,3))])
disp('QALYs:')
disp(['  Original QALYs: ' dispnum(qalys(:,1))])
disp(['  NSP savings:    ' dispnum(qalys(:,2))])
disp(['  MMT savings:    ' dispnum(qalys(:,3))])





%% Plotting
doplot=1;
if doplot==1
    disp('Plotting...')
    prevdata=squeeze(d.data.hivprevalence(:,1,2:end));
    timedata=d.data.general.datayears(2:end);
    
    figure('position',[500 500 500 600])
    plotdata{1}=d.simsets;
    plotdata{2}=d.scenarios(1).simsets;
    plotdata{3}=d.scenarios(2).simsets;
    titles={'Actual','No NSP','No MMT'};
    for i=1:3
        subplot(3,1,i); hold on
        
        ordered=zeros(nsimstouse,length(pts));
        
        for s=1:nsimstouse
            sim=plotdata{i}{simstouse(s)};
            ordered(s,:)=100*sum(sim.prevalence.*sim.pm.populationsize,1)./sum(sim.pm.populationsize,1);
        end
        y=quantile(ordered,0.5);
        lower=quantile(ordered,0.0);
        upper=quantile(ordered,1);
        
        errorshade(pts,y,lower-y,upper-y);
        scatter(timedata,prevdata(3,:)*100,'r','filled')
        
        xlabel('Year')
        ylabel('Prevalence (%)')
        title(titles{i},'fontweight','bold')
        axis tight
        ylim([0 100])
        box on
    end
end

