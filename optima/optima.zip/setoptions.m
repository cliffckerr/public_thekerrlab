%% SETOPTIONS
% This file sets global options for Prevtool -- the file name, what to run,
% etc. While this file is the one that needs to be modified, do not run it:
% run Prevtool instead, which calls it.
% 
% Note: do not confuse the options contained in "opt" with the options
% contained in the variable usually called "options" that's fed to model().
% The options in opt control in general terms how Prevtool works, whereas
% the options for model() are optional extensions of the model. 
%
% Version: 2013aug01 by cliffk

function opt=setoptions % opt = options

%% General options
opt.spreadsheetname='../swaziland-may30.xlsx'; % Name of spreadsheet to load
opt.matfilename='../swaziland-aug01b.mat'; % Name of data file to load/save to
opt.outputname='../swaziland'; % The base name of the files to be saved
opt.pseudorandom=2; % Whether to make results exactly reproducible (+ve integer) or not (-1)
opt.nlabs=4; % To turn off parallel, set this to 1
opt.equilibrate=1; % Whether or not to have model start at steady-state

%% Prevtool options: what to run
opt.do.runeverything=0; % Override other settings and just do everything
opt.do.loaddata=0; % Whether to road data from Excel spreadsheet
opt.do.createpars=0; % Whether to create parameters based on behavioral data
opt.do.makeposteriors=0; % Whether to calculate posteriors
opt.do.runscenarios=0; % Whether to run scenarios
opt.do.results=1; % Whether to output/plot results

%% Create parameters options
opt.create.interactive=0; % Use to check the fit of each parameter
opt.create.showprogress=10; % How many steps to show full progress on
opt.create.verbose=0; % Whether to show nuts and bolts of fitting
opt.create.maxiters=2000; % How many iterations of the fitting algorithm to use
opt.create.errorlookback=50; % How many steps to look back for error
opt.create.minimprovement=1e-4; % What the minimum fractional improvement over errorlookback steps is
opt.create.minerror=1e-3; % Error level small enough to terminate fitting
opt.create.timetrends=0; % Whether or not to fit time trends -- if not, all time parameters will be initialized to the same value

%% Manual fitting options
opt.manfit.yearrange=[2000 2020]; % Year range to display for manual fitting (must be subset of data.general.simyears)

%% Posteriors options
opt.post.burnperiod=0; % Number of samples to discard
opt.post.samplestoskip=1; % Save one out of every fit.samplestoskip samples
opt.post.nsavedsamples=40; % Number of samples to construct the final distribution from
opt.post.weights=[1e5 1e-50 1e-52 5e-50 5e-50]; % Relative weights of behavioral data, prevalence, diagnoses, number on 1st-line treatment, number on 2nd-line treatment
opt.post.stepsize=0.05; % How big the randomization is

%% Scenario options
opt.scenarios.whichscenarios=[]; % Which scenarios to run

%% Results options
opt.results.dosave=1; % Whether to save results automatically in high-resolution
opt.results.calibration=0; % Whether or not to plot the calibration
opt.results.analysis=0; % Whether or not to output analysis results
opt.results.previnci=0; % Whether or not to output analysis results
opt.results.allocations=1; % Whether to plot optimal allocation things
opt.results.years={[2000 2013],[2013 2018]}; % Which sets of years to consider results over

%% Housekeeping
opt.post.nsavedsamples=round(opt.post.nsavedsamples/opt.nlabs); % Generate nsavedsamples fits, not nsavedsamples*nlabs
opt.outputname=[opt.outputname '-' lower(datestr(now,'mmmdd')) '-']; % Append current date to user-selected name

end