function b = cksqueeze(a)
%CKSQUEEZE Remove singleton dimensions without transpose.
%
%   B = CKSQUEEZE(A) returns an array B with the same elements as
%   A but with all the singleton dimensions removed.  A singleton
%   is a dimension such that size(A,dim)==1.  2-D arrays are
%   unaffected by squeeze so that row vectors remain rows.
%
%   For example,
%
%       squeeze(ones(1,1,5))=ones(5,1)
%
%   while
%
%       squeeze(ones(1,1,5))=ones(1,5)
%
%   See also SHIFTDIM.

%   Copyright 212 by Cliff Kerr
%   $Revision: 1.14.4.3 $  $Date: 2010/08/23 23:08:14 $

if nargin==0 
  error(message('MATLAB:squeeze:NotEnoughInputs')); 
end

if ndims(a)>2
  siz = size(a);
  numdims=length(siz);
  keepdim=ones(numdims,1);
  for dim=1:numdims
      if siz(dim)==1 && sum(keepdim)>2 % Remove dimensions, making sure matrix is always at least 2D.
          keepdim(dim)=0;
      end
  end
      
  siz(~keepdim) = []; % Remove singleton dimensions.
  b = reshape(a,siz);
else
  b = a;
end
