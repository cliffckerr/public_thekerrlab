%% NOTIFY
% This program plays a short beep sound to indicate when a simulation has
% finished.
% Version: 2013jan19

function notify
% Set note definitions
A=440; c=1; cs=2; db=2; d=3; ds=4; eb=4; e=5; f=6; fs=7; gb=7; g=8; gs=9; ab=9; a=10; as=11; bb=11; b=12; %#ok<*NASGU>

chord=[a -1 cs 0 e 1 ds 2]; % Define the sound from the notes above
duration=1; % Duration in s
rate=16e3; % Sampling rate in Hz

freqs=note2freq(chord); % Convert chord into frequencies
waveform=freqs2wave(freqs,rate,duration); % Convert frequencies into waveform

sound(waveform,rate) % Play the sound

    % Convert notes into frequencies
    function freqs=note2freq(notesoctaves)
        notes=notesoctaves(1:2:end-1);
        octaves=notesoctaves(2:2:end);
        freqs=zeros(size(notes));
        for i=1:length(notes)
            freqs(i)=A*2^((notes(i)-10+octaves(i)*12)/12);
        end
    end

    % Convert frequencies into a waveform
    function waveform=freqs2wave(freqs,rate,duration)
        npts=rate*duration;
        waveform=zeros(npts,2);
        for note=1:length(freqs)
            wave=sin((1:npts)*2*pi/rate*freqs(note));
            waveform=waveform+[wave' wave'];
        end
        volume=linspace(1,0,npts); % Fade out
        waveform=waveform.*[volume' volume'];
        waveform=waveform/max(abs(waveform(:)))/1.2; % Normalize
    end
end