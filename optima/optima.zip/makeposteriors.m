%% MAKEPOSTERIORS
% This actually reads in the data and melds to it.
% Version: 2012sep30

function [parametersets,simsets,finaltotalerrors,vec2structtable]=makeposteriors(data,parstruct,equations,fitoptions,worker,runscenario)

disp('Makeposteriors:')
tic
pg=data.general; % Make this easier to access
options=[]; % options.turnofftransmission=data.general.datayears(end); % End simulation when the data ends -- makes it run faster but makes for strange plots



% Include deaths as well?
alldata=struct([]);
alldata(1).name='Prevalence';           alldata(1).data=data.hivprevalence;
alldata(2).name='Diagnoses';            alldata(2).data=data.numdiagnoses;
alldata(3).name='1st-line treatment';   alldata(3).data=data.numtreatment(:,1,:);
alldata(4).name='2nd-line treatment';   alldata(4).data=data.numtreatment(:,2,:);


for dat=1:length(alldata)
    [rows,datacols]=find(~isnan(cksqueeze(alldata(dat).data(3,:,:)))); % Rows are the same between model and data but columns aren't
    alldata(dat).rows=rows;
    alldata(dat).datacols=datacols;
    alldata(dat).ndatapts=length(rows);
    alldata(dat).modelcols=zeros(alldata(dat).ndatapts,1);
    if alldata(dat).ndatapts>0
        for pt=1:alldata(dat).ndatapts
            try 
                alldata(dat).modelcols(pt)=find(pg.pts==pg.datayears(alldata(dat).datacols(pt)));
            catch err
                error('Could not find data point in model time points; need to run simulation for longer?')
            end
        end
    end
end
allpoints=sum([alldata(:).ndatapts]);

% Need to start iterating here. First, take parstruct and generate N
% samples from them, where N is big. Then, calculate the mismatch with both
% epidemiological and behavioral data. Then, resample based on the fitoptions.weights
% (cumsum of probabilities perhaps?). If necessary, generate new
% distributions based on five quantiles for each parameter, and repeat the
% procedure (this would be Metropolis-Hastings I think).

% No, this would be Metropolis-Hastings: throw one sample, accept it with
% probability P(new)/P(old). Then rethrow. Repeat ad infinitum.

% Convert parstruct (structure) to fittedvalues (vector), and make a conversion table
[parvec,vec2structtable]=convertparams('struct2vec',parstruct,equations,1);
nvalues=length(parvec.vec); % Don't worry about the non-vector fields of parvec

finalepierrors=  zeros(fitoptions.nsavedsamples,1);
finalbehaverrors=zeros(fitoptions.nsavedsamples,1);
finaltotalerrors=zeros(fitoptions.nsavedsamples,1);
parametersets=    cell(fitoptions.nsavedsamples,1);
simsets=          cell(fitoptions.nsavedsamples,1);
previouserror=Inf;
trialcount=0;
goodtrialcount=0;
savedtrialcount=0;


% Extra stuff to get behverrorfunc working


disp(' Iterating...')
while 1
    trialcount=trialcount+1;
    testparameterset=parvec; % Copy default
    testparameterset.vec=parvec.vec+(trialcount>1)*fitoptions.stepsize*randn(nvalues,1); % Randomize values in vec field; trialcount is to remove randomness for first trial
    parstruct=convertparams('vec2struct',vec2structtable,testparameterset); % Convert vector to structure: yes, identical to parstruct; my bad
    
    % Run model and assign output to alldata
    [pg,pm]=setupmodel(data,equations,parstruct,runscenario);
    pm=equilibrium(pg,pm);
    sim=model(pg,pm,1,options);
    
    % Process the errors
    epierrors=epierrorfunc(alldata,pg,sim,allpoints,fitoptions);
    behaverrors=fitoptions.weights(1)*behaverrorfunc(data,pg,equations,testparameterset);
    newerror=epierrors+behaverrors;
    keepthistrial=0; thisrand=rand;
    if newerror<previouserror
        keepthistrial=1;
    else
        if exp(1-newerror/previouserror)/2>thisrand % This institutes the Metropolis-Hastings algorithm, more or less.
            keepthistrial=1;
        end
    end
    
    if keepthistrial
        previouserror=newerror;
        parvec=testparameterset;
        goodtrialcount=goodtrialcount+1;
        if goodtrialcount>fitoptions.burnperiod && ~mod(goodtrialcount,fitoptions.samplestoskip)
            savedtrialcount=savedtrialcount+1;
            finalepierrors(savedtrialcount)=  epierrors;
            finalbehaverrors(savedtrialcount)=behaverrors;
            finaltotalerrors(savedtrialcount)=epierrors+behaverrors;
            parametersets{savedtrialcount}=testparameterset;
            simsets{savedtrialcount}=sim;
        end
    end
    if savedtrialcount>=fitoptions.nsavedsamples; break; end
    fprintf('  Kept: %i/%i Good: %i/%i (%i%%) Err: %0.2f   Worker: %i EpiErr: %0.2f BeErr: %0.2f\n',savedtrialcount,fitoptions.nsavedsamples,goodtrialcount,trialcount,round(100*(goodtrialcount/trialcount)),newerror,worker,epierrors,behaverrors)
end


fprintf('Makeposteriors: '), toc
end






%% Error from epidemiological indicators
function err=epierrorfunc(alldata,pg,sim,allpoints,fitoptions) % Count is purely for troubleshooting


alldata(1).model=sim.prevalence;
alldata(2).model=sum(sim.diagnoses,1); % Don't have diagnoses data by population
alldata(3).model=sum(sim.numontreat1,1); % Don't have treatment data by population
alldata(4).model=sum(sim.numontreat2,1);

eachepierror=zeros(allpoints,1);
count=0;
for dat=1:length(alldata)
    for pt=1:alldata(dat).ndatapts
        if numel(alldata(dat).data)>2 % Time series?
            count=count+1;
            dataquantiles=alldata(dat).data(:,alldata(dat).rows(pt),alldata(dat).datacols(pt));
            prediction=   alldata(dat).model(alldata(dat).rows(pt),alldata(dat).modelcols(pt));
        else % No
            count=count+1;
            dataquantiles=alldata(dat).data(:,alldata(dat).datacols(pt));
            prediction=   alldata(dat).model(alldata(dat).modelcols(pt));
        end
        if ~isempty(dataquantiles)
            eachepierror(count)=fitoptions.weights(dat+1)*finderror(prediction,pg.quantiles,dataquantiles); % +1 since first is behavioral vs. epi
        end
        
    end
end
err=sum(eachepierror);
% if isnan(err), disp('Epierror returned a nan! This isn''t good!'), keyboard, end


end



%% Error from behavioral parameters
% WARNING, kludgy!
function totalerror=behaverrorfunc(data,pg,equations,parvec) 

whethertopause=0;
totalerror=0;
startcount=1;
for phylum=1:length(equations.phyla)
    thisphylum=equations.phyla{phylum};
    phylumdata=data.(thisphylum);
    mediandata=cksqueeze(phylumdata(3,:,:));
    % Do weighting
    [datarows,datacols]=find(~isnan(mediandata));
    ndatapts=length(datarows);
    assert(length(datarows)==length(datacols),'Number of data points don''t make sense!')

    families=unique([equations.bayespars.(thisphylum){:}]); % Find out what parameters are used to model this data
    nfamilies=length(families);
    if nfamilies>0 % Don't loop over parameter if it doesn't exist
        nrows=size(equations.indices.(thisphylum),2); % Don't try modeling things that don't have an equation
        ncols=size(phylumdata,3);
        predictions.(thisphylum)=nan(nrows,ncols);
        
        valuestofamilies=cell(nfamilies,1);
        for family=1:nfamilies
            thisfamily=families{family};
            if strfind(thisfamily,'time')
                endcount=startcount+pg.ncontrolyears-1;
            else
                endcount=startcount;
            end
            valuestofamilies{family}=startcount:endcount;
            startcount=endcount+1;
        end
        
        assert(any(~isnan(mediandata(:))),'Not a single datum entered for %s! What do you expect me to do? I''m not psychic!',thisphylum)
        
        % Calculate values
        for family=1:nfamilies
            if strfind(families{family},'time')
                eval([families{family} '=controlval(pg.controlyears,parvec.vec(valuestofamilies{family}),pg.datayears);']);
            else % Not time -- normal parameter
                eval([families{family} '=' num2str(parvec.vec(valuestofamilies{family})) ';'])
            end
        end
        
        % Make predictions
        for row=1:nrows
            try
                eval(['predictions.' equations.indices.(thisphylum){row} '=' equations.bayeseqns.(thisphylum){row} ';'])
            catch exception
                fprintf('\n\nProblem with %s\n\n',thisphylum)
                rethrow(exception)
            end
        end
        limits=data.(thisphylum)([1 pg.nquantiles],1,1);
        predictions.(thisphylum)=compactify(predictions.(thisphylum),limits,0); % Force it to lie within the range

        
        % Compare to data
        err=zeros(ndatapts,1);
        for pt=1:ndatapts
            if ndims(phylumdata)>2
                dataquantiles=cksqueeze(phylumdata(:,datarows(pt),datacols(pt)));
                prediction=predictions.(thisphylum)(datarows(pt),datacols(pt));
            else
                dataquantiles=phylumdata(:,datacols(pt)); % Shouldn't this be datarows? You'd think so, but Matlab is weird about matrices.
                prediction=predictions.(thisphylum)(datacols(pt));
            end
            if ~all(dataquantiles==sort(dataquantiles)), warning('flexidist:meldparameters','Vector input arguments must be monotonic increasing.'), end
            assert(dataquantiles(end)==max(dataquantiles),sprintf(['Hard upper limit too low: timestep too large? \n' num2str(dataquantiles')]))
            
            err(pt)=finderror(prediction,pg.quantiles,dataquantiles);
        end
        
        
        
        if whethertopause
            disp(' ')
            tmpdata=zeros(ndatapts,1);
            tmppred=zeros(ndatapts,1);
            if ndims(phylumdata)>2
                for pt=1:ndatapts
                    tmpdata(pt)=phylumdata(3,datarows(pt),datacols(pt));
                    tmppred(pt)=predictions.(thisphylum)(datarows(pt),datacols(pt));
                end
            else
                for pt=1:ndatapts
                    tmpdata(pt)=phylumdata(3,datacols(pt));
                    tmppred(pt)=predictions.(thisphylum)(datacols(pt));
                end
            end
            
            disp([tmpdata tmppred err])
            h=figure;
            semilogy(tmpdata,'ko-','linewidth',2); hold on
            semilogy(tmppred,'bs-','linewidth',2);
            semilogy(err,    'rs:','linewidth',2);
            title(equations.phyla{phylum})
            legend('Data','Prediction','Error')
            keyboard
            if ishandle(h), close(h), end
        end
        
        totalerror=totalerror+sum(err);
    end
end

end
