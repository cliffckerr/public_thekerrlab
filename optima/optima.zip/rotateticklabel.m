function th=rotateticklabel(h,rot,fontsize)
%ROTATETICKLABEL rotates tick labels
%   TH=ROTATETICKLABEL(H,ROT) is the calling form where H is a handle to
%   the axis that contains the XTickLabels that are to be rotated. ROT is
%   an optional parameter that specifies the angle of rotation. The default
%   angle is 90. TH is a handle to the text objects created. For long
%   strings such as those produced by datetick, you may have to adjust the
%   position of the axes so the labels don't get cut off.
%
%   Of course, GCA can be substituted for H if desired.
%
%   TH=ROTATETICKLABEL([],[],'demo') shows a demo figure.
%
%   Known deficiencies: if tick labels are raised to a power, the power
%   will be lost after rotation.
%
%   See also datetick.

%   Written Oct 14, 2005 by Andy Bliss
%   Copyright 2005 by Andy Bliss
%   Modified 2012oct28 by cliffk

if nargin==1 || isempty(rot), rot=90; end % set the default rotation if user doesn't specify
while rot>360, rot=rot-360; end % make sure the rotation is in the range 0:360 (brute force method)
while rot<0, rot=rot+360; end

if nargin<3, fontsize=10; end

a=get(h,'XTickLabel'); %get current tick labels
set(h,'XTickLabel',[]); %erase current tick labels from figure
b=get(h,'XTick'); %get tick label positions
c=get(h,'YTick');

if rot<180 %m ake new tick labels
    th=text(b,repmat(c(1)-.1*(c(2)-c(1)),length(b),1),a,'HorizontalAlignment','right','rotation',rot,'fontsize',fontsize);
else
    th=text(b,repmat(c(1)-.1*(c(2)-c(1)),length(b),1),a,'HorizontalAlignment','left','rotation',rot,'fontsize',fontsize);
end


end
