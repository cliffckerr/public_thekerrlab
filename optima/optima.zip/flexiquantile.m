%% FLEXIQUANTILE
% This program calculates the quantile for an arbitrary point on an
% arbitrary distribution. It uses the same method as flexidist.
% Decompactifies an input on the domain [0,1] to the domain (-inf,inf),
% performs an interpolation, and then recompactifies, giving the
% distribution the desired properties.
% Usage:
%   q = flexiquantile(pt,qx,qy,[epsilon])
% where
%   q is the quantile
%   pt is the point in question
%   qx is an ordered vector of quantile locations (e.g. qx=0.5 => median)
%   qy is an ordered vector of quantile values (e.g. [qx=0.5,qy=0] => median is 0)
%   epsilon corrects for rounding errors (default 1e-12)
%
% The first and last elements of qx should be 0 and 1, respectively, while
% the first and last elements of qy define the domain of the distribution.
%
% Example:
%   qx=[0 0.1 0.5 0.9 1]; qy=[0 0.6 0.7 0.75 1]; q=flexiquantile(0.9,qx,qy)
%
% Version: 2012jun12

function q=flexiquantile(varargin)
pt=varargin{1}; % Store original size
x=varargin{2}(:); % Reshape to always be a column vector
y=varargin{3}(:); % Handle input arguments
tiebreak=1e-2; % Upper limit of amount by which to break exact ties in quantiles
if nargin>=4, epsilon=varargin{4}; else epsilon=1e-4; end % Set epsilon
if any(x>1), error('Check input: probabilities cannot be above 1!'), end
if any(pt<y(1)), error('Requested point is below lower bound of distribution, quantile <0!'), end
if any(pt>y(end)), error('Requested point is above upper bound of distribution, quantile >100!'), end
if length(unique(y))==1
    q=0.5*ones(size(pt)); % If only one value in y, pt must be equal to it or else there would've been an error
else % Else, calculate the actual quantile
    if length(unique(y))<length(y) % Check to make sure that different quantiles actually have different values: no, just say it's 0.5
        warning('flexiquantile:nonunique',['Quantiles not all unique!\n' num2str(y')])
        straightline=y(1)+(y(end)-y(1))*(0:length(y)-1)'/(length(y)-1);
        difference=straightline-y;
        y=y+difference*tiebreak; % Stretch y along a straight line to break ties
    end
    mapping=@(x) erfinv((2*x-1)*(1-epsilon)); % Define the mapping
    invmapping=@(pt) (erf(pt)+1)/2; % Define inverse mapping
    q=invmapping(pchip(y,mapping(x),pt)); % Do a standard interpolation
end
end
