%% CURRENTYLIM
% This silly script makes it easy to get the current y limits.
% Version: 2012jul27

function lims=setylim(lower,upper)

lims=ylim; % Get current y limits
if ~isempty(lower), lims(1)=lower; end
if ~isempty(upper), lims(2)=upper; end
ylim(lims)

end