%% RESULTS
% Generate all the results for a typical situation:
% Figure 1: Calibration
% Version: 2013jun02

tic
opt=setoptions(); % Get global options

%% Fig. 1: Calibration
if opt.results.calibration==1
    
    figname=[opt.outputname 'calibration.png'];
    randomize=0;
    plotstyle=3;
    plotstyles={'data','best','iqr','trials'};
    ci=1;
    quantiles=[0.25 0.5 0.75]; % For IQR
    xlims=[2000 2020];
    if ci==1
        quantiles=[0.025 0.5 0.975]; % For 95% CI
        plotstyles{3}='95ci';
    end
    
    d=load(opt.matfilename);
    figure('position',[200 200 1400 600])
    
    nsimstoplot=length(d.simsets); % How many simulations to select
    if randomize==1
        errorcdf=cumsum(exp(-(d.finaltotalerrors/min(d.finaltotalerrors)).^2));
        errorcdf=errorcdf/errorcdf(end);
        simstoplot=zeros(nsimstoplot,1);
        for s=1:nsimstoplot
            simstoplot(s)=s; find(errorcdf>rand(),1,'first');
        end
        simstoplot=unique(simstoplot); % For plotting, duplicates don't matter
        nsimstoplot=length(simstoplot);
        
    else
        simstoplot=nsimstoplot:-1:1;
    end
    fprintf('  Unique simulations: %i\n',nsimstoplot)
    
    npops=size(d.data.hivprevalence,2);
    nsims=length(d.simsets);
    if randomize==1
        [~,plotorder]=sort(d.finaltotalerrors(simstoplot));
        plotorder=flipud(plotorder)';
        simstoplot=simstoplot(plotorder)';
    end
    cols=vectocolor(nsimstoplot:-1:1);
    cols=(cols+1)/2;
    
    
    % Prevalence
    years=d.data.general.datayears;
    for p=1:npops
        goodprevyears=(find(~isnan(squeeze(d.realdata.hivprevalence(3,p,:)))))';
        cksubplot([npops 2],[p 1],[60 30],[3 0],[3 -1],[1 1])
        if plotstyle>1
            if plotstyle<4, start=nsimstoplot; else start=1; end
            if plotstyle==3
                dim1=length(d.simsets);
                dim2=length(d.simsets{1}.prevalence(1,:));
                alldata=zeros(dim1,dim2);
                for d1=1:dim1
                    alldata(d1,:)=100*d.simsets{d1}.prevalence(p,:);
                end
                errlower=quantile(alldata,quantiles(1),1);
                errmiddle=quantile(alldata,quantiles(2),1);
                errupper=quantile(alldata,quantiles(3),1);
                zz=errorshade(d.data.general.pts,[],errlower,errupper,[0 0.3 1]); hold on
            end
            for i=start:nsimstoplot
                s=simstoplot(i);
                best=(s==simstoplot(end)); % Plot best plot differently
                plot(d.data.general.pts,100*d.simsets{s}.prevalence(p,:),'color',[0 0.3 1],'linewidth',0.5+2*best); hold on
            end
        end
        for yr=goodprevyears
            plot(years(yr)*[1 1], 100*d.realdata.hivprevalence([2 4],p,yr),'color',0.5*[1 1 1],'linewidth',1.5); hold on
        end
        scatter(years,100*squeeze(d.realdata.hivprevalence(3,p,:)),50,'k','filled'), hold on
        xlabel('Year')
        ylabel('Prevalence (%)')
        fullnames=d.data.general.fullpopnames(logical(d.data.general.popinuse));
        fullnames{9}='Female sex workers'
        title(fullnames{p})
        xlim(xlims)
        setylim(0,[]);
    end
    
    
    % Other epidemiological data
    datafields={'numdiagnoses','numtreatment','numtreatment'};
    row=[1 1 2];
    simfields={'diagnoses','numontreat1','numontreat2'};
    titles={'Diagnoses','1st-line treatment','2nd-line treatment'};
    ylabels={'Number of diagnoses (''000s)','People on 1st-line (''000s)','People on 2nd-line'};
    correction=[1000 1000 1]; % Factor to correct results by
    
    for f=1:length(datafields)
        datafld=datafields{f};
        simfld=simfields{f};
        goodyears=find(~isnan(squeeze(d.realdata.(datafld)(3,row(f),:))));
        cksubplot([3 2],[f 2],[80 60],[3 5],[7 -5],[1 1]); hold on
        if plotstyle>1
            if plotstyle<4, start=nsimstoplot; else start=1; end
            if plotstyle==3
                dim1=length(d.simsets);
                dim2=length(d.simsets{1}.(simfld)(1,:));
                alldata=zeros(dim1,dim2);
                for d1=1:dim1, alldata(d1,:)=sum(d.simsets{d1}.(simfld)(:,:)/correction(f),1); end
                errlower=quantile(alldata,quantiles(1),1); % Change this for IQR vs. 95% CI
                errmiddle=quantile(alldata,quantiles(2),1);
                errupper=quantile(alldata,quantiles(3),1);
                zz=errorshade(d.data.general.pts,[],errlower,errupper,[0 0.3 1]); hold on
            end
            for i=start:length(simstoplot)
                s=simstoplot(i);
                best=(s==simstoplot(end)); % Plot best plot differently
                thisdata=d.simsets{s}.(simfld);
                thisdata=sum(thisdata,1);
                plot(d.data.general.pts,thisdata/correction(f),'color',[0 0.3 1],'linewidth',0.5+2*best)
            end
        end
        
        expupper= squeeze(d.realdata.(datafld)(4,row(f),goodyears));
        expmiddle=squeeze(d.realdata.(datafld)(3,row(f),goodyears));
        explower =squeeze(d.realdata.(datafld)(2,row(f),goodyears));
        for yr=1:length(goodyears)
            plot(years(goodyears(yr))*[1 1], [explower(yr) expupper(yr)]/correction(f),'color',0.5*[1 1 1],'linewidth',1.2);
        end
        pause(0.5)
        scatter(years(goodyears),expmiddle/correction(f),50,'k','filled'), hold on
        xlabel('Year')
        ylabel(ylabels{f})
        title(titles{f},'fontweight','bold')
        xlim(xlims)
        setylim(0,[]);
    end
    
    if opt.results.dosave==1, savefig(figname), end
end





















%% Analysis (based on malaysiaanalysis.m)
if opt.results.analysis==1
    
    disp('Loading data...')
    d=load(opt.matfilename);
    
    allpts=d.data.general.pts;
    dt=d.data.general.timestep;
    allresults=struct;
    
    nperiods=length(opt.results.years);
    years=cell(nperiods,1);
    for pair=1:nperiods % Loop over year pairs
        years{pair}=find(allpts>=opt.results.years{pair}(1) & allpts<=opt.results.years{pair}(1));
    end
    quantiles=[0.25 0.5 0.75];
    
    disp('Analyzing...')
    nsims=length(d.scenarios(1).simsets);
    nscenarios=1;
    tmp=zeros(nperiods,nscenarios,nsims);
    allresults.cuminfections=tmp; % 2
    allresults.mtct=tmp;
    allresults.prevalence=tmp; % 4
    allresults.cumdeaths=tmp; % 5
    allresults.cum1stline=tmp; % 6
    allresults.cum2ndline=tmp; % 7
    logistic=@(x,A,B,C,D) (B-A)./(1+exp(-(x-C)/D))+A;
    for si=1:nsims
        for p=1:nperiods
            for sc=1:nscenarios
                % Initialize
                sim=d.scenarios(sc).simsets{si};
                pts=years{p};
                
                %% Basic measures
                
                % Cumulative new infections
                allresults.cuminfections(p,sc,si)=dt*sum(sum(sim.incidence(:,pts)))+dt*sum(sim.mtct(pts));
                
                % Mother-to-child transmission
                allresults.cuminfections(p,sc,si)=dt*sum(sim.mtct(pts));
                
                % Prevalence
                allresults.prevalence(p,sc,si)=squeeze(sum(sum(sim.people(2:end,:,pts(end)),1),2))/squeeze(sum(sum(sim.people(1:end,:,pts(end)),1),2))*100;
                
                % Cumulative deaths
                allresults.cumdeaths(p,sc,si)=dt*sum(sum(sim.hivdeaths(:,pts)));
                
                % Cumulative started first line
                allresults.cum1stline(p,sc,si)=dt*sum(sum(sim.newtreat1(:,pts)));
                
                % Cumulative started second line
                allresults.cum2ndline(p,sc,si)=dt*sum(sum(sim.newtreat2(:,pts)));
            end
        end
    end
    
    %% Calculate summary statistics
    flds=fieldnames(allresults);
    nflds=length(flds);
    for f=1:nflds
        output.(flds{f})=zeros(nperiods,nscenarios,3); % 3 for low-med-high
        for p=1:nperiods
            for sc=1:nscenarios
                output.(flds{f})(p,sc,:)=quantile(allresults.(flds{f})(p,sc,:),quantiles);
            end
        end
    end
    
    %% Output
    categories={'Cumulative new infections', 'Cumulative mother-to-child infections', 'Prevalence (%)', 'Cumulative deaths', ...
        'Cumulative started 1st-line', 'Cumulative started 2nd-line'};
    table=cell(nperiods*length(categories),nscenarios);
    
    row=0;
    periods={'2000-2013\n','2013-2018\n'};
    fprintf('\t %s \t %s \t %s \t %s\n',d.scenarios.name)
    for p=1:nperiods
        fprintf(periods{p})
        for f=1:nflds
            row=row+1;
            fprintf('%35s:\t',categories{f})
            for sc=1:nscenarios
                tmp=output.(flds{f})(p,sc,:); % Three quantiles
                str='###,###,###'; % For everything else
                tmpout=cell(3,1);
                for i=1:3
                    if tmp(i)>=0
                        tmpout{i}=formatnum(tmp(i),str);
                    else
                        tmpout{i}='Cost-saving';
                    end
                end
                table{row,sc}=sprintf('%s (%s – %s)\t',tmpout{2},tmpout{1},tmpout{3});
                if all(tmp<0)
                    table{row,sc}=sprintf('Cost-saving\t');
                end
                fprintf('%s',table{row,sc})
            end
            fprintf('\n')
        end
    end
    
%     %% Figures
%     onoffcolors={[],[1 0.5 0],[0 0.8 0],[]};
%     
%     % Set up
%     colors=vectocolor(1:(nscenarios+1));
%     window=(allpts<=2023);
%     plotpos={[85 65],[0 0],[7 -7],[1 1]};
%     h=zeros(nscenarios,1);
%     datayears=d.data.general.datayears;
%     datayears(datayears>2012)=NaN; % Remove invalid values
%     dt=d.data.general.timestep;
%     
%     
%     %% Incidence
%     figure('position',[200 200 400 300]); hold on
%     xlims=[2000 2023];
%     xyears=xlims(1):xlims(2);
%     for sc=[1 4]
%         sim=d.scenarios(sc).simsets{1};
%         h(sc)=plot(allpts(window),cumsum(squeeze(sum(sim.incidence(:,window),1)))/1000*dt,'linewidth',2,'color',colors(sc,:));
%     end
%     ylim([0 30])
%     xlim(xlims)
%     ylabel('Cumulative infections (''000)')
%     xlabel('Year')
%     legend('No interventions','NSEP & MMT','location','northwest');
%     title('Cumulative number of new HIV infections','fontweight','bold')
%     uistack(h(1),'top')
%     box on
%     if dosave==1, savefig([figname '-incidence']), end
%     
%     %% Prevalence
%     figure('position',[200 200 400 300]); hold on
%     for sc=[1 4]
%         sim=d.scenarios(sc).simsets{1};
%         h(sc)=plot(allpts(window),squeeze(sum(sum(sim.people(2:end,:,window),1),2))./squeeze(sum(sum(sim.people(1:end,:,window),1),2))*100,'linewidth',2,'color',colors(sc,:));
%     end
%     ylim([0 40])
%     xlim([2000 2023])
%     ylabel('Prevalence (%)')
%     xlabel('Year')
%     title('Prevalence','fontweight','bold')
%     legend('No interventions','NSEP & MMT','location','northeast');
%     uistack(h(1),'top')
%     npts=length(datayears);
%     for pt=2:npts
%         plot(datayears(pt)*[1 1],100*squeeze(d.data.hivprevalence([2 4],1,pt)),'color',0.5*[1 1 1],'linewidth',1.5)
%     end
%     
%     scatter(datayears(2:end),100*squeeze(d.data.hivprevalence(3,1,2:end)),50,'k','filled')
%     box on
%     
%     if dosave==1, savefig([figname '-prevalence']), end
%     
%     disp('Done.')
    
end




%% Plot graphs of prevalence and incidence for each population group
if opt.results.previnci==1
    
    d=load(opt.matfilename);
    pg=d.data.general;
    popcolors=vectocolor(1:pg.npops);
    yearlims=[2000 2030];
    sim=d.simsets{1};
    pts=(sim.pts>=yearlims(1) & sim.pts<=yearlims(2));
    
    % Prevalence
    figure('position',[200 200 800 300]); hold on
    for p=1:pg.npops
        plot(sim.pts(pts),sim.prevalence(p,pts)*100,'color',popcolors(p,:),'linewidth',2)
        
    end
    plot(sim.pts(pts),sim.overallprev(pts)*100,'k','linewidth',4)
    legend([pg.fullpopnames(logical(pg.popinuse)), 'Overall'],'location','eastoutside')
    for p=1:pg.npops
        scatter(pg.datayears,d.data.hivprevalence(3,p,:)*100,50,popcolors(p,:),'filled')
    end
    box on
    xlabel('Year')
    ylabel('Prevalence (%)')
    
    if opt.results.dosave==1, savefig([opt.outputname 'prevalence.png']), end
    
    % Incidence
    figure('position',[200 200 800 300]); hold on
    for p=1:pg.npops
        plot(sim.pts(pts),sim.incidence(p,pts)/1e3,'color',popcolors(p,:),'linewidth',2)
    end
    plot(sim.pts(pts),sum(sim.incidence(:,pts),1)/1e3,'k','linewidth',4)
    legend([pg.fullpopnames(logical(pg.popinuse)), 'Total'],'location','eastoutside')
    box on
    xlabel('Year')
    ylabel('Incidence (000s)')
    
    if opt.results.dosave==1, savefig([opt.outputname 'incidence.png']), end

end
    
    



%% Plot things to do with optimal allocations
% From plotallocations.m
if opt.results.allocations==1
    %% Load simulation data
    d=load(opt.matfilename);
    
    %% Load allocations data
    dosave=1;
    plotfig1=1;
    plotfig2=1;
    plotfig3=1;
    tmp=load([opt.matfilename(1:end-4) '-allocationdaly.mat']); % Append 'allocation'
    allocations=tmp.allocations;
    allocation=[1.11 1.07 1.79 3.15 0.05 0.01 26.98 4.34]*1e6;
    nallocations=size(allocations,1)+2; % +1 for 0 spend, +1 for current spend
    allocations=[0*allocation; allocations(1:10,:); allocation; allocations(11:end,:)]+1; % +1 so all groups show up when plotting
    optimal=11; % Index of optimal allocation
    current=12; % Index of current allocation
    
    
    %% Set parameters
    startyear=2013; % Year to start scenarios/start counting infections
    endyear=2030; % Year to stop counting invections
    
    
    %% Run preliminary model
    disp('Running...')
    [pg,pm]=setupmodel(d.data,d.equations,d.parstruct,1);
    pm=equilibrium(pg,pm);
    
    %% Specify programs
    % Programs -- see Lei's email 2012nov20
    disp('Specifying programs....')
    scenpoints=find(pg.pts>=startyear);
    costpoints=find(pg.pts>=startyear & pg.pts<=endyear);
    bcc=1; cnd=2; pmt=3; vmc=4; fsw=5; msm=6; art=7; hct=8; % Make it so I can refer to programs by their names, e.g. VCT = 7
    INF=1;	CHLD=2;	FYTH=3;	MYTH=4;	FAD=5;	MAD=6;	FELD=7;	MELD=8;	FSW=9;	FSWC=10;	MSM=11; % Define populations
    logistic=@(x,p) (p(2)-p(1))./(1+exp(-(x-p(3))/p(4)))+p(1); % Define a simple logistic equation; see below for a more general formula
    
    
    %% Calculate current infections based on spend
    disp('Calculating...')
    infections=zeros(nallocations,pg.npops); % -2 is if LRPs are missing
    allocresults=struct;
    origpm=pm;
    options.turnofftransmission=-endyear-1; % Only run model until this date; the minus sign aborts
    parfor a=1:nallocations
        fprintf('  %i/%i\n',a,nallocations)
        allocation=allocations(a,:);
        pm=origpm;
        
        % 1. BCC
        pm.numactsregular(FAD,scenpoints)=logistic(allocation(bcc),[65 30 1e6 5e5]);
        pm.numactsregular(MAD,scenpoints)=logistic(allocation(bcc),[75 40 1e6 5e5]);

        % 2. Condom
        for pp=[FYTH MYTH], pm.condomprobcasual(pp,scenpoints)=logistic(allocation(cnd),[0 0.77 2e5 5e5]); end % Male and female youth condom rate
        for pp=[FAD MAD],   pm.condomprobcasual(pp,scenpoints)=logistic(allocation(cnd),[0 0.70 2e5 5e5]); end % Male and female adult condom rate
        for pp=[FELD MELD], pm.condomprobcasual(pp,scenpoints)=logistic(allocation(cnd),[0 0.50 2e5 1e6]); end % Male and female elderly condom rate
        
        % 3. PMTCT
        pm.pmtctrate(scenpoints)=logistic(allocation(pmt),[-0.95 0.95 0 5e5]); % PMTCT rate
        
        % 4. VMMC
        for pp=[MYTH MAD MELD FSWC], pm.circumcisionprob(pp,scenpoints)=logistic(allocation(vmc),[-0.60 0.70 0 8e6]); end % Male circumcision
        
        % 5. FSW
        for pp=[FSW FSWC], pm.condomprobother(pp,scenpoints)=logistic(allocation(fsw),[0.30 0.95 0 3e4]); end % FSW condom use
        
        % 6. MSM
        pm.condomprobcasual(pp,scenpoints)=logistic(allocation(msm),[-0.30 0.81 0 8e3]); % MSM condom use
        
        % 7. ART
        pm.numonart1(scenpoints)=logistic(allocation(art),[-210e3 210e3 0 4e7]); % ART
        
        % 8. HCT
        for pp=[FYTH FAD FELD], pm.testingrate(pp,scenpoints)=logistic(allocation(hct),[-0.75 0.80 0 3.5e6]); end % Female testing
        for pp=[MAD MELD FSWC], pm.testingrate(pp,scenpoints)=logistic(allocation(hct),[-0.57 0.60 0 4e6]); end % Male testing
                
        % Run the model
        [~,pm]=setupmodel(d.data,d.equations,pm,1);
        pm=equilibrium(pg,pm);
        sim=model(pg,pm,1,options);
        allocresults(a).sim=sim;
        mtctfactor=2; % WARNING KLUDGY -- factor for how many additional infections children count for
        sim.incidence(1,costpoints)=sim.incidence(1,costpoints)+mtctfactor*sim.mtct(costpoints)*pg.timestep; % Add MTCT to infant population
        infections(a,:)=sum(sim.incidence(:,costpoints)*pg.timestep,2); % Exclude LRP with 3:end instead of :
    end
    
    
    %% Calculate statistics
    
    matching=find(ismember(pg.pts,startyear:endyear)); % Find year end points
    for a=1:nallocations
        allocresults(a).cuminfections=sum(sum(allocresults(a).sim.incidence(:,matching))); % “Cumulative number of new infections”
        allocresults(a).cumnewtreat1=sum(sum(allocresults(a).sim.newtreat1(:,matching))); % “Cumulative number of people starting 1st line ART”
        allocresults(a).cumnewtreat2=sum(sum(allocresults(a).sim.newtreat2(:,matching))); % “Cumulative number of people starting 2nd ART”
        allocresults(a).cumdeaths=sum(sum(allocresults(a).sim.hivdeaths(:,matching))); % “Cumulative number of deaths”
    end
    
    totalinfections=sum(infections,2);
    currenttotal=totalinfections(current);
    find(totalinfections<0.5*currenttotal)
    
    
    
    %% Plotting
    disp('Plotting...')
    programnames={'Behavior change (# acts/year)','Condom (% usage)','PMTCT (% coverage)','Circumcision (% circumcized)','FSW (% condom usage)','MSM (% condom usage)','ART (# covered)','HCT (% tested/year)'};
    xlabels={'No spending','10% budget','20% budget','30% budget','40% budget','50% budget','60% budget','70% budget','80% budget','90% budget','100% budget','Current','120% budget','150% budget','200% budget'};
    
    %% Plot "Fig. 7"
    if plotfig1==1
        figure('position',[100 100 800 350])
        
        cksubplot([2 1],[1 1],[80 80],[0 0],[0 -5])
        pie(allocations(current,:))
        title('Current','fontweight','bold')
        
        cksubplot([2 1],[2 1],[80 80],[0 0],[15 -5])
        pie(allocations(optimal,:))
        title('Optimal','fontweight','bold')
        
        legend(programnames,'location',[0.42 0.2 0.2 0.6])
        
        if opt.results.dosave==1, savefig([opt.outputname 'allocationdaly-pies.png']), end
    end
    
    
    %% Plot "Fig. 8"
    if plotfig2==1
        figure('position',[100 100 600 700])
        cksubplot([1 2],[1 1],[58 60],[0 0],[10 -14])
        bar(allocations/1e6,0.7,'stack','barwidth',1)
        legend(programnames,'position',[0.71 0.7 0.2 0.2])
        ylabel('Spend (million $)')
        set(gca,'xticklabel',xlabels);
        rotateticklabel(gca);
        xlim([0.5 15.5])
        
        cksubplot([1 2],[1 2],[58 60],[0 0],[10 -12])
        bar(infections/1e3,0.7,'stack','barwidth',1)
        legend(pg.fullpopnames(logical(pg.popinuse)),'position',[0.71 0.2 0.2 0.2])
        ylabel('Cumulative new infections (''000s)')
        set(gca,'xticklabel',xlabels);
        rotateticklabel(gca);
        xlim([0.5 15.5])
        
        if opt.results.dosave==1, savefig([opt.outputname 'allocationdaly-bar.png']), end
    end
    
    
    %% Plot "Fig. 10"
    prevorinci=[1 2];
    if any(prevorinci==1) % Prevalence
        if plotfig3==1
            figure('position',[100 100 600 600])
            
            styles={'k--','r','b'};
            names={'No prevention','Optimized budget','Current conditions'};
            for p=1:pg.npops
                subplot(4,3,p); hold on % WARNING KLUDGY
                scens=[1 optimal current];
                for s=1:length(scens);
                    plot(pg.pts,allocresults(scens(s)).sim.prevalence(p,:)*100,styles{s},'linewidth',2)
                end
                xlabel('Year')
                ylabel('Prevalence (%)')
                title(allocresults(1).sim.popfullnames{p},'fontweight','bold')
                xlim([2000 endyear])
                box on
            end
            subplot(4,3,12); hold on
            set(gca,'visible','off')
            for s=1:length(scens);
                plot(0,0,styles{s},'linewidth',2)
            end
            set(gca,'xtick',[])
            set(gca,'ytick',[])
            legend(names)
            if opt.results.dosave==1, savefig([opt.outputname 'allocationdaly-prevalence.png']), end
        end
    end
    if any(prevorinci==2)
        if plotfig3==1
            figure('position',[100 100 600 600])
            
            styles={'k--','r','b'};
            names={'No prevention','Optimized budget','Current conditions'};
            for p=1:pg.npops
                subplot(4,3,p); hold on
                scens=[1 optimal current];
                for s=1:length(scens);
                    plot(pg.pts,allocresults(scens(s)).sim.incidence(p,:),styles{s},'linewidth',2)
                end
                xlabel('Year')
                ylabel('Annual infections')
                title(allocresults(1).sim.popnames{p},'fontweight','bold')
                xlim([2000 endyear])
                box on
            end
            subplot(4,3,12); hold on
            set(gca,'visible','off')
            for s=1:length(scens);
                plot(0,0,styles{s},'linewidth',2)
            end
            set(gca,'xtick',[])
            set(gca,'ytick',[])
            legend(names)
            if opt.results.dosave==1, savefig([opt.outputname 'allocationdaly-incidence.png']), end
        end
    end
    
    disp('Done.')

    
    
end
    
    
    





fprintf('results.m done: '), toc