%% PERCENTCOMPLETE
% This code displays the percent You give it the current step and the total
% number of steps. The third argument is optional for how much indenting to
% have.
% Version: 2012nov23

function percentcomplete(step,maxsteps,varargin)

if nargin==3, indent=varargin{1}; else indent=1; end % Handle input arguments

onepercent=max(1,round(maxsteps/100)); % Calculate how big a single step is -- not smaller than 1
if ~mod(step,onepercent) % Does this value lie on a percent
    thispercent=round(step/maxsteps*100); % Calculate what percent it is
    fprintf('%s%i%%\n',blanks(indent*2),thispercent) % Display the output
end
end