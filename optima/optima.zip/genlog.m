%% Generalized logistic function -- genlog.m
%
% This function calculates the value of generalized logistic function 
% at for a specific x-value. Based on function description on Wikipedia:
% http://en.wikipedia.org/wiki/Generalised_logistic_function
%
% *Inputs*
% 
% * t - time
% * a - lower asymptote
% * k - the upper asymptote
% * b - the growth rate
% * v - affects near which asymptote maximum growth occurs
% * q - depends on the value at t = 0
% * m - the time of maximum growth if Q = v
%

%% 

function y = genlog(a,x)

    % Seperate inputs
    a1=a(1);
    b=a(2);
    k=a(3);
    m=a(4);
    q=a(5);
    v=a(6);

    % calculate y
    y = a1 + (k-a1)./((1+q*exp(-b*(x-m))).^(1/v));

end
