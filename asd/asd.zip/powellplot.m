%% POWELLPLOT
% This plots the parameters for the runs.
% Version: 2014jun06

function powellplot()
tic

%% Set things
disp('Starting...')
seed = 0;
dosave = 1;
maxevals = 2e3;
npars = 20;
simannealtemp = 10;
methods = {'BALLSD', 'Simplex', 'Levenberg-Marquardt', 'Simulated annealing', 'Genetic algorithm'};

%% Create data structures
nmethods = length(methods);
pardata = zeros(nmethods,maxevals,npars);
errdata = zeros(nmethods,maxevals);
m = 0; s = 0;

%% Create Powell
initialguess = repmat([3, -1, 0, 1],[1 npars/4]);
    function E = powell(x) 
        s = s+1;
        inds = 0:4:npars-1;
        E = sum((x(inds+1) + 10*x(inds+2)).^2 + 5*(x(inds+3) - x(inds+4)).^2 + (x(inds+2) - 2*x(inds+3)).^4 + 10*(x(inds+1) - x(inds+4)).^4);
        if m>0 && s>0
            pardata(m,s,:) = x;
            errdata(m,s) = E;
            minerror = min(errdata(m,1:s));
            if minerror < E
                index = find(errdata(m,1:s)==minerror,1);
                errdata(m,s) = errdata(m,index);
                pardata(m,s,:) = pardata(m,index,:);
            end
        end
    end

initial = powell(initialguess);

%% Set options
% For BALLSD
options.stepsize = 0.2;
options.sinc = 2;
options.sdec = 2;
options.pinc = 2;
options.pdec = 2;

% For other algorithms
options.Display = 'off';
options.Algorithm = 'levenberg-marquardt'; % To avoid lsqnonlin error messages
options.StallIterLimit = 1e6; % To stop simulated annealing from dying early
options.StallGenLimit = 1e6; % To stop genetic algorithm from dying early
options.PopulationSize = 40;
options.PopInitRange = [-1;3];
options.MaxIter = 1e9;
options.TolFun = 0;
options.TolX = 0;
options.MaxFunEvals = maxevals;
options.Generations = ceil(maxevals/options.PopulationSize);
options.InitialTemperature = simannealtemp*mean(abs(initialguess));

%% Calculate everything
for m = 1:nmethods
    s = 0;
    fprintf('  %i/%i\n',m,nmethods)
    rng(seed)
    if m==1,     ballsd(@powell, initialguess, options);
    elseif m==2, fminsearch(@powell, initialguess, options);
    elseif m==3, lsqnonlin(@powell, initialguess, [], [], options);
    elseif m==4, simulannealbnd(@powell, initialguess, [], [], options);
    elseif m==5, ga(@powell, length(initialguess), [], [], [], [], [], [], [], options);
    end
end
if size(pardata,2)>maxevals,
    fprintf('   Trimming pardata from %i to %i\n',size(pardata,2),maxevals)
    pardata = pardata(:,1:maxevals,:); % Trim extra entries if they exist
    errdata = errdata(:,1:maxevals,:); % Trim extra entries if they exist
end


%% Plot
disp('Plotting...')
pcolors = vectocolor(1:npars);
figure('position',[1000 100 800 800]);
colormap jet
xdata = 1:maxevals;
for m = 1:nmethods
    cksubplot([2 3], [mod(m-1,2)+1 round(m/2)], [85 65], [0 0], [6 -7]); hold on
    for p = 1:npars
        plot(xdata,squeeze(pardata(m,:,p)),'color',pcolors(p,:))
    end
    title(methods{m},'fontweight','bold')
    xlabel('Function evaluations')
    ylabel('Parameter value')
    xlim([0 maxevals])
    ylim([-2 4])
end

cksubplot([2 3], [2 3], [85 65], [0 0], [6 -7]); hold on
mcolors = {[0.5 0 1], [0.7 0.7 0.7], [0.9 0.6 0], [0 0.8 0], [0 0.6 1]};
for m = 1:nmethods
    plot(xdata,errdata(m,:)/initial,'color',mcolors{m},'linewidth',2)
end
set(gca,'yscale','log')
title('Objective function','fontweight','bold')
xlabel('Function evaluations')
ylabel('Relative error');
xlim([0 maxevals])
ylim([1e-8 1e0])
lh = legend(methods,'location','southwest');
set(lh, 'Box', 'off')
set(lh, 'Color', 'none')

if dosave, savefig('powell.pdf'), end

disp('Done.')

toc
end