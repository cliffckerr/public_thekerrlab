%% ERRORSHADE
% This function creates a plot with a shaded area representing the
% uncertainty; it can be thought of as a much more beautiful version of
% errorbar.
% 
% Usage:
%   [handle1,handle2]=errorshade(x,best,lower,upper,color,alpha)
%
% where
%   handle1 is the patch object handle
%   handle2 is the line object handle
%   x is the x-axis data
%   best is the y-axis data
%   lower is the lower error
%   upper is the upper error
%   color is the line and patch color, an RGB triplet (default black)
%   alpha is the opacity of the patch (default 10%)
%
% Example:
%   x=0:0.1:10;
%   h=errorshade(x,x.^2,-x,sqrt(x)*10,[0 0.5 1],0.3)
%
% Version: 2014mar21

function [handle1,handle2]=errorshade(x,best,lower,upper,patchcolor,opacity)

%% Read in input arguments
x=reshape(x,[],1); % X axis data
best=reshape(best,[],1); % Baseline Y axis data
lower=reshape(lower,[],1); % Lower error bound
upper=reshape(upper,[],1); % Upper error bound

%% Create patch objects
xpatch=[x; flipud(x)]; % Create x data by copying and flipping the input x axis
ypatch=[upper; flipud(lower)]; % Create y data by combining upper with flipped-lower data


%% Do plotting
handle1=patch(xpatch,ypatch,patchcolor,'facealpha',opacity,'linestyle','none');
handle2=plot(x,best,'color',patchcolor,'linewidth',2);


end