%% COLORBARLABEL
% This code adds a label to the colorbar.
% Usage:
% 	colorbarlabel(handle,label,[position],[rotation])
% Example:
%	pcolor(rand(50))
% 	cb=colorbar;
% 	colorbarlabel(cb,'Goodness-of-fit',0.5)
%
% Version: 2012aug07

function colorbarlabel(handle,label,varargin)

if nargin>=3, position=varargin{1}; else position=0; end
if nargin>=4, rotation=varargin{2}; else rotation=270; end

labelhandle=ylabel(handle,label,'rotation',rotation);
yrange=get(handle,'ylim');
set(labelhandle,'position',[position+7 (yrange(2)+yrange(1))/2 1]) % This should work in most cases

end
