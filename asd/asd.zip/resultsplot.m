%% RESULTSPLOT
% This plots the parameters for the runs.
% Version: 2014aug08

function resultsplot()
tic

%% Set things
disp('Starting...')
dosavedata = 0;
dosave = 1;
doload = 1;
maxevals = 1e4;
randomness = 0;
simannealtemp = 10;
repeats = 40;
npars = [2 4 12 20 100];
functions = {'Rosenbrock''s valley (2D)', 'Powell''s quartic (4D)', 'Powell''s quartic (12D)', 'Powell''s quartic (20D)', 'Powell''s quartic (100D)'};
methods = {'BALLSD', 'Simplex', 'Levenberg-Marquardt', 'Simulated annealing', 'Genetic algorithm'};

%% Create data structures
nfunctions = length(functions);
nmethods = length(methods);
pardata = zeros(nfunctions,nmethods,maxevals,max(npars),repeats);
errdata = zeros(nfunctions,nmethods,maxevals,repeats);
f = 0; m = 0; s = 0; r = 0;
storeparams = false;


%% Create functions
initialguesses = cell(nfunctions,1);
for f=1:nfunctions
    if f==1
        initialguesses{f} = [-1.2, 1];
    elseif f==2
        initialguesses{f} = [3, -1, 0, 1,  zeros(1,npars(f)-4)];
    else
        initialguesses{f} = repmat([3, -1, 0, 1],[1 npars(f)/4])+randomness*randn(1,npars(f));
    end
end

    function E = testfunction(x) 
        
        s = s+1; % Increment counter
        
        if s>maxevals % Don't compute function if it's gone over the limit
            error('Exceeded maximum evaluations')
        else
            if f==1 % Rosenbrock's valley
                E = 100*(x(2) - x(1)^2)^2 + (1 - x(1))^2;
            else % Powell's
                if f==2
                    inds = 0;
                else
                    inds = 0:4:npars(f)-1;
                end
                E = sum((x(inds+1) + 10*x(inds+2)).^2 + 5*(x(inds+3) - x(inds+4)).^2 + (x(inds+2) - 2*x(inds+3)).^4 + 10*(x(inds+1) - x(inds+4)).^4);
            end
            
            if storeparams && f>0 && m>0 && s>0 && r>0
                pardata(f,m,s,1:npars(f),r) = x;
            end
        end
    end

initialerr = zeros(nfunctions,1);
for f = 1:nfunctions, initialerr(f) = testfunction(initialguesses{f}); end

%% Set options
% For BALLSD
options.stepsize = 0.2;
options.sinc = 2;
options.sdec = 2;
options.pinc = 2;
options.pdec = 2;

% For other algorithms
options.Display = 'off';
options.Algorithm = 'levenberg-marquardt'; % To avoid lsqnonlin error messages
options.StallIterLimit = 1e6; % To stop simulated annealing from dying early
options.StallGenLimit = 1e6; % To stop genetic algorithm from dying early
options.PopulationSize = 40;
options.MaxIter = 1e6;
options.TolFun = 0;
options.TolX = 0;
options.MaxFunEvals = maxevals;
options.Generations = ceil(maxevals/options.PopulationSize);

%% Calculate everything
if doload==0
    disp('Calculating...')
    count = 0;
    storeparams = true;
    for r = 1:repeats
        for f = 1:nfunctions
            fprintf('  %s\n',functions{f})
            options.InitialTemperature = simannealtemp*mean(abs(initialguesses{f}));
            for m = 1:nmethods
                s = 0; % Reset step counter
                count = count+1;
                fprintf(' %25s %i %i %i (%i/%i)\n',methods{m},  r,f,m, count,nfunctions*nmethods*repeats) %#ok<*PFBNS>
                rng(r)
                options.PopInitRange = transpose(quantile(initialguesses{f},[0 1]));
                try
                    if m==1,     ballsd(@testfunction, initialguesses{f}, options);
                    elseif m==2, fminsearch(@testfunction, initialguesses{f}, options);
                    elseif m==3, lsqnonlin(@testfunction, initialguesses{f}, [], [], options);
                    elseif m==4, simulannealbnd(@testfunction, initialguesses{f}, [], [], options);
                    elseif m==5, ga(@testfunction, length(initialguesses{f}), [], [], [], [], [], [], [], options);
                    end
                catch %#ok<CTCH>
                    disp('                        Skipping...')
                end
            end
        end
    end
    if size(pardata,3)>maxevals,
        fprintf('   Trimming pardata from %i to %i\n',size(pardata,3),maxevals)
        pardata = pardata(:,:,1:maxevals,:,:); % Trim extra entries if they exist
    end
    
    %% Recalculate errors
	disp('Recalculating errors...')
	storeparams = false;
	count = 0;
    for r = 1:repeats
        for f = 1:nfunctions
            for m = 1:nmethods
                count = count+1;
                for ev = 1:maxevals
                    s = 0;
                    errdata(f,m,ev,r) = testfunction(squeeze(pardata(f,m,ev,1:npars(f),r))) / initialerr(f);
                    if errdata(f,m,ev,r) > min(errdata(f,m,1:ev,r)), errdata(f,m,ev,r) = min(errdata(f,m,1:ev,r)); end % If current error is larger than smallest error yet found, replace with smallest
                end
                percentcomplete(count,nfunctions*nmethods*repeats)
            end
        end
    end
    if dosavedata==1
        disp('Saving results...')
        save('resultsbatch.mat','errdata')
    end
else % Load data instead of recalculating
    disp('Loading results...')
    tmp = load('resultsbatch.mat');
    errdata = tmp.errdata;
end


%% Plot
disp('Plotting...')
figure('position',[100 100 800 700])
colors = {[0.5 0 1], [0.7 0.7 0.7], [0.9 0.6 0], [0 0.8 0], [0 0.6 1]};
xdata = 1:maxevals;
handles = zeros(nmethods,2);
quantiles = [0.5 0.25 0.75];

for f = 1:nfunctions
    h = cksubplot([2 3], [mod(f-1,2)+1 round(f/2)], [80 63], [0 0], [10 -7]); hold on
    
    for m = 1:nmethods, plot([0 0],[0 0], 'color',colors{m}, 'linewidth',2), end
    
    for m = 1:nmethods
        thesedata = squeeze(errdata(f,m,:,:));
        results = log10(quantile(thesedata,quantiles,2));
        [h1, h2] = errorshade(xdata, results(:,1)', results(:,2)', results(:,3)', colors{m}, 0.3);
        handles(m,:) = [h1, h2];
    end
    title(functions{f},'fontweight','bold')
    xlabel({'','Function evaluations'})
    ylabel('Relative error','units','normalized','position',[-0.15 0.5],'verticalalignment','middle')
    axis tight
    xlim([0 maxevals])
    setylim(-8,0);
    yticks = -8:2:0;
    nticks = length(yticks);
    yticklabels = cell(nticks,1);
    for t = 1:nticks, yticklabels{t} = sprintf('10^{%i}',yticks(t)); end
    format_ticks(h,[],yticklabels,[],yticks,[],[],[]);
end
legend(handles(:,1), methods,'location',[0.6 0.07 0.35 0.22])

if dosave, savefig('resultsbatch.svg'), end

disp('Done.')

toc
end