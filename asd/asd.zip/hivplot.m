%% HIVPLOT
% This plots the HIV example; it's a combination of powellplot.m and
% optimalspend.m.
% Version: 2014jun10

function hivplot(filename, seed)
tic

%% Set things
disp('Starting...')
dosave = 1;
doload = 0; % If selected, will load data rather than compute
doplot = 0;
verbose = 1; % Display warning messages
methodstouse = [1 4 5]; % 1:5 for all
maxevals = 2000;
simannealtemp = 10;
methods = {'BALLSD', 'Simplex', 'Levenberg-Marquardt', 'Simulated annealing', 'Genetic algorithm'};
initialguess=[1.78 0.22 5.57 0.08 0.1 0.04 44.77 3.41 34.68]'*1e6;
[~, ordering] = sort(initialguess);
programnames={'Behavior change','Condom','PMTCT','Circumcision','FSW','MSM','ART','Testing','OVC'};

%% Create data structures
nprograms = length(initialguess);
nmethods = length(methods);
pardata = zeros(nmethods,maxevals,nprograms);
infectiondata = zeros(nmethods,maxevals);
rawdata = {pardata, infectiondata};
m = 0; s = 0; count = 0;

%% Create HIV simulation
addpath('./optima')

opt=setoptions(); % Get options, such as file name

% Set parameters
interventionstart=2013; % Year to start scenarios
interventionstop=Inf; % Year to stop scenarios
outcomestart=2013; % Year to start counting outcomes
outcomestop=2030; % Year to stop counting outcomes
datayeartouse=10; % Year that data are entered for economics code
optimizewhat='incidence';

% Load data to do optimal allocation on, plus logistic curve data
disp('Loading data...')
d=load(opt.matfilename); % Load Prevtool output

% Run preliminary model
disp('Initializing...')
[pg,pm]=setupmodel(d.data,d.equations,d.parstruct,1);
pm=equilibrium(pg,pm);

% Specify programs
disp('Specifying programs....')

scenpoints=find(pg.pts>=interventionstart & pg.pts<=interventionstop); % Which year to start the scenario
costpoints=find(pg.pts>=outcomestart & pg.pts<=outcomestop); % What years to calculate intervention over

%% Calculate current infections based on spend
    function E = hivsim(allocation)
        
        % Normalize
        if any(allocation<0)
            if verbose, fprintf('         Allocation <0 (%0.0f)\n',min(allocation)), end
            allocation = abs(allocation); % For the genetic algorithm, which is going to fail anyway...
        end
        allocation = allocation ./ sum(allocation) * sum(initialguess); % Normalize
        
        % Loop
        s = s+1; count = count+1;
        if s<=maxevals && any(m==methodstouse) % Don't loop if it's gone over the limit
            [pm, dalyschange] = costoutcomecurves(pm,pg,allocation,scenpoints);
            options.turnofftransmission=-2032; % Only run model until this date; the minus sign aborts
            [pg,pm]=setupmodel(d.data,d.equations,pm,1);
            pm=equilibrium(pg,pm);
            sim=model(pg,pm,1,options);
            if strcmp(optimizewhat,'incidence')
                mtctfactor=1; % WARNING KLUDGY -- factor for how many additional infections children count for
                incidence=sum(sum(sim.incidence(:,costpoints),2))/length(costpoints) + mtctfactor*sum(sim.mtct(costpoints))/length(costpoints); % To exclude low-risk population, use 3:end instead of :
                E=incidence;
            elseif strcmp(optimizewhat,'dalys')
                cost = economics(sim,d.data,costpoints,2013,datayeartouse,discountrate); % 2018 is the "current" year for the sake of inflation
                deathfactor=20; % Equivalent DALYs for death
                mtctfactor=20; % WARNING KLUDGY -- factor for how many additional DALYs children count for
                deaththing = deathfactor*sum(sum(sim.hivdeaths(:,costpoints)))/length(costpoints);
                mtctthing = mtctfactor*sum(sim.mtct(costpoints))/length(costpoints);
                dalys = sum(cost.daly_disc)/length(costpoints) + deaththing + mtctthing;
                E=dalys-dalyschange;
            end
            if m>0, fprintf('    %i/%i (%0.2f)\n', count, maxevals*nmethods, E), end
        else
            E = -1;
        end
        
        if m>0 && s>0
            pardata(m,s,:) = allocation;
            infectiondata(m,s) = E;
            rawdata{1}(m,s,:) = allocation; %#ok<SETNU>
            rawdata{2}(m,s) = E;
            minerror = min(infectiondata(m,1:s));
            if minerror < E
                index = find(infectiondata(m,1:s)==minerror,1);
                infectiondata(m,s) = infectiondata(m,index);
                pardata(m,s,:) = pardata(m,index,:);
            end
        end
    end



%% Set options
% For BALLSD
options.stepsize = 0.2;
options.sinc = 2;
options.sdec = 2;
options.pinc = 2;
options.pdec = 2;

% For other algorithms
options.Display = 'off';
options.Algorithm = 'levenberg-marquardt'; % To avoid lsqnonlin error messages
options.StallIterLimit = 1e6; % To stop simulated annealing from dying early
options.StallGenLimit = 1e6; % To stop genetic algorithm from dying early
options.PopulationSize = 40;
options.PopInitRange = [0;1];
options.MaxIter = 1e9;
options.TolFun = 0;
options.TolX = 0;
options.MaxFunEvals = maxevals;
options.Generations = ceil(maxevals/options.PopulationSize);
options.InitialTemperature = simannealtemp*mean(abs(initialguess));

%% Calculate everything
if doload==1 && exist([filename '.mat'],'file')
    load(filename)
else
    for m = 1:nmethods
        s = 0;
        fprintf('  %s\n',methods{m})
        rng(seed)
        if m==1,     ballsd(@hivsim, initialguess, options);
        elseif m==2, fminsearch(@hivsim, initialguess, options);
        elseif m==3, lsqnonlin(@hivsim, initialguess, [], [], options);
        elseif m==4, simulannealbnd(@hivsim, initialguess, [], [], options);
        elseif m==5, ga(@hivsim, length(initialguess), [], [], [], [], [], [], [], options);
        end
    end
    if size(pardata,2)>maxevals,
        fprintf('   Trimming pardata from %i to %i\n',size(pardata,2),maxevals)
        pardata = pardata(:,1:maxevals,:); % Trim extra entries if they exist
        infectiondata = infectiondata(:,1:maxevals,:); % Trim extra entries if they exist
    end
    save(filename,'pardata','infectiondata','rawdata')
end


%% Plot
if doplot==1
    disp('Plotting...')
    figure('position',[1000 100 800 700]);
    xdata = 1:maxevals;
    
    % Plot labels
    ax=axes('position',[0 0 1 1],'units','normalized'); hold on
    text(0.02,0.97,'A','fontsize',16,'fontweight','bold')
    text(0.02,0.50,'B','fontsize',16,'fontweight','bold')
    xlim([0 1])
    ylim([0 1])
    set(ax,'visible','off')
    
    % Pie charts
    explodepie = 0; % Whether or not to explode the pie
    piedata = {initialguess(ordering), squeeze(pardata(1,end,ordering))}; % Data is initial guess and then optimal from BALLSD
    pielabels = cell(nprograms,1);
    for p = 1:nprograms, pielabels{p} = ''; end
    axes('position',[0.03 0.55 0.4 0.4])
    pie(piedata{1}+eps, explodepie+zeros(nprograms,1), pielabels)
    title('Current allocation','fontweight','bold')
    legend(programnames(ordering),'location',[0.41 0.6 0.2 0.3])
    axes('position',[0.6 0.55 0.4 0.4])
    pie(piedata{2}+eps, explodepie+zeros(nprograms,1), pielabels)
    title('Optimal allocation','fontweight','bold')
    
    % New infections
    nyears = 5;
    cksubplot([1 2], [1 2], [95 75], [0 0], [8 -7]); hold on
    mcolors = {[0.5 0 1], [0.7 0.7 0.7], [0.9 0.6 0], [0 0.8 0], [0 0.6 1]};
    for m = 1:nmethods
        plot(xdata,infectiondata(m,:)/nyears,'color',mcolors{m},'linewidth',2)
    end
    xlabel('Function evaluations')
    ylabel('New infections per year');
    xlim([0 maxevals])
    ylim([1000 2500])
    lh = legend(methods,'location','northeast');
    set(lh, 'Box', 'off')
    set(lh, 'Color', 'none')
    
    if dosave, savefig([filename '.pdf']), end
end

disp('Done.')

toc
end