%% COMPACTIFY
% This little function converts a value from a compact value
% [lowerlimit, upperlimit] to a decompact value [-Inf,Inf] and vice versa,
% based on a sigmoid curve or its inverse. Limits is a 2-element vector
% consisting of the lower and upper limits, respectively.
% Version: 2012oct11

function output=compactify(input,limits,direction)

lowerlimit=limits(1);
upperlimit=limits(2);
if direction==0 % Compactify
    output=(upperlimit-lowerlimit)./(1+exp(-input))+lowerlimit;
elseif direction==1 % Decompactify
    output=-log((upperlimit-lowerlimit)./(input-lowerlimit)-1);
end

end