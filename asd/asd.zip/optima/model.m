%% MODEL
%
% This function is the core of the model, and includes everything except
% the parameters.
%
% Usage:
%     sim=model(pg,pm,extraoutput,[options])
% 
% where
%     sim is a structure containing all output from the model, e.g. people, which holds the number of people in each state at each time point
%     pg is a structure containing general parameters (things like timestep size)
%     pm is a structure containing all model parameters (things like condom usage, initial population size, etc.)
%     extraoutput is a flag determining whether extra outputs should be saved to the sim structure.
%     options is an optional structure with the following fields:
%       turnofftransmission is year at which to turn off transmission, or,if negative, break the loop
%       movepeople moves people, by fiat, to a different population group
%
% Todo:
% * To incorporate former IDUs and sex workers, you could introduce an
% exchange rate between them and the corresponding general populations. In
% general, the number of incoming and outgoing people should match. This
% operation should be performed just after all the ODEs are calculated.
%
% Version: 2013may13 by Cliff Kerr

function sim=model(pg,pm,extraoutput,varargin) % extraoutput is to calculate death rates etc.

% Read in options, or set it to nothing, then set defaults
if nargin==4, options=varargin{1};
else options=[];
end
if ~isfield(options,'turnofftransmission'), options.turnofftransmission=Inf; end

%% Setup

% Initialize basic quantities and arrays
people=zeros(pg.nstates,pg.npops,pg.npts); % Initialize matrix to hold everything
people(:,:,1)=pm.initialpop; % Set initial population sizes
effectivehivprevalence=zeros(pg.npops,1); % HIV effective prevalence (prevalence times infectiousness)
dt=pg.timestep;

% Initialize additional output information
sim.pts=pg.pts; % Save time data along with simulation to ease plotting
sim.popnames=pg.popnames(logical(pg.popinuse)); % Save population names
sim.pm=pm; % Save parameter information
poptime=zeros(pg.npops,pg.npts); % Initialize arrays
cd4poptime=zeros(pg.ncd4,pg.npops,pg.npts); % Divide things by CD4 count, sex, and time
sim.incidence=poptime;   % Incidence
sim.prevalence=poptime;  % Prevalence
sim.allpeople=poptime;   % Total size of each population group
sim.hivdeaths=poptime;   % HIV-caused deaths
if extraoutput
    sim.causehiv=poptime;          % Which population causes which infections
    sim.newtreat1=poptime;         % Number of new people on 1st-line treatment
    sim.newtreat2=poptime;         % Number of new people on 2nd-line treatment
    sim.numontreat1=poptime;       % Number of people on 1st-line treatment
    sim.numontreat2=poptime;       % Number of people on 2nd-line treatment
    sim.diagnoses=poptime;         % How many diagnoses occurred in a given population
    sim.dxbycd4=cd4poptime;        % How many diagnoses occurred at a given CD4 count
    sim.tx1bycd4=cd4poptime;        % How many 1st-line treatments occurred at a given CD4 count
    sim.tx2bycd4=cd4poptime;        % How many 2nd-line treatments occurred at a given CD4 count
    sim.deathsbycd4=cd4poptime;    % How many deaths occurred at a given CD4 count
end
dU=cell(pg.ncd4,1); dD=dU; dT1=dU; dF=dU; dT2=dU; % Initialize disease state cell arrays


%% Run the model -- numerically integrate over time
for t=1:pg.npts % Loop over time; we'll skip the last timestep for people since we don't need to know what happens after that
    
    
    %% Calculate HIV prevalence
    for pop=1:pg.npops % Loop over each population group
        sim.allpeople(pop,t)=sum(people(:,pop,t)); % All people in this population group at this time point
        effectiveundiag = sum(pm.transbycd4.*people(pg.undiag,pop,t),1); % Effective number of infecious undiagnosed people
        effectivediag   = sum((1-pm.diagnosisefficacy)*pm.transbycd4.*(people(pg.diag,pop,t)+people(pg.fail,pop,t)),1); % ...and diagnosed/failed
        effectivetreat  = sum(pm.transontreatment*pm.treatriskcompensation*(1-pm.diagnosisefficacy)*(people(pg.treat1,pop,t)+people(pg.treat2,pop,t)),1); % ...and treated
        effectivehivprevalence(pop)=(effectiveundiag+effectivediag+effectivetreat)/sim.allpeople(pop,t); % Calculate HIV "prevalence", scaled for infectiousness based on CD4 count; assume that treatment failure infectiousness is same as corresponding CD4 count
        if ~(effectivehivprevalence(pop)>=0), error('HIV prevalence invalid in %s!',sim.popnames{pop}), end
    end
    
    %% Calculate force-of-infection (forceinf)
    forceinfvec=zeros(pg.npops,1); % Initialize force-of-infection vector for each population group
    if extraoutput, forceinfmatrix=zeros(pg.npops,pg.npops); end % Store the inverse of forceinfvec -- infections caused by a certain group rather than received
        
    % Sexual partnerships
    for psh=1:pg.nsexpartnerships % Loop over all sexual partnerships
        
        % Amazingly, the code runs faster if these are pulled out of the equations for forceinf!
        popM=pm.sexpartnershippop(psh,1); % "Male" population (e.g. 5 = CSW)
        popF=pm.sexpartnershippop(psh,2); % "Female" population (e.g. 10 = FIDU), but includes MSM and waria
        numacts=dt*pm.numacts(psh,:,t); % Number of acts per person per year; 2nd dimension is insertive vs. receptive
        condomeffect=1-pm.condomprob(psh,t)*pm.condomefficacy; % Condom use
        circumcisioneffectM=1-pm.circumcisionefficacy*pm.circumcisionprob(popM,t); % Effect of circumcisionumcision
        circumcisioneffectF=1; % circumcision has no effect on the receptive population
        otherinterventioneffectM=1;% Turn off for now 1-pm.otherinterventionefficacy*pm.otherinterventionprob(popM,t); % An "other" intervention, e.g. PEP
        otherinterventioneffectF=1;% Turn off for now 1-pm.otherinterventionefficacy*pm.otherinterventionprob(popF,t); % An "other" intervention, e.g. PEP
        stieffectM=1+pm.stitransincrease*pm.stiprevalence(popM,t); % STI prevalence effect
        stieffectF=1+pm.stitransincrease*pm.stiprevalence(popF,t);
        transmissibilityM=pm.sexpartnershiptrans(psh,1); % Insertive transmissibility
        transmissibilityF=pm.sexpartnershiptrans(psh,2); % Receptive transmissibility
        
        forceinfM = 1 - (1-transmissibilityM*circumcisioneffectM*stieffectM*otherinterventioneffectM) ^ (numacts(1)*condomeffect*effectivehivprevalence(popF)); %/populationsizeM); % The chance of person B infecting person A; pm.cst{psh}(3)=trans; only males are protected by circumcisionumcision
        forceinfF = 1 - (1-transmissibilityF*circumcisioneffectF*stieffectF*otherinterventioneffectF) ^ (numacts(2)*condomeffect*effectivehivprevalence(popM)); %/populationsizeF); % The chance of person A infecting person B
        if any([forceinfM forceinfF]~=median([[forceinfM forceinfF];[0 0];[1 1]])), badforceinf('sex'), end % Error checking: make sure both values lie between 0 and 1
        
        forceinfvec(popM)=1-(1-forceinfvec(popM))*(1-forceinfM); % Calculate the new "male" forceinf, ensuring that it never gets above 1
        forceinfvec(popF)=1-(1-forceinfvec(popF))*(1-forceinfF); % Calculate the new "female" forceinf
        
        if extraoutput % Store information for calculating how many infections are caused by each population
            forceinfmatrix(popM,popF)=1-(1-forceinfmatrix(popM,popF))*(1-forceinfF); % Calculate how many people the male population infected
            forceinfmatrix(popF,popM)=1-(1-forceinfmatrix(popF,popM))*(1-forceinfM); % Calculate how many people the female population infected
        end
    end
    
    
    % Injecting partnerships
    for psh=1:pg.ninjpartnerships % Loop over all sexual partnerships
        
        % Amazingly, the code runs faster if these are pulled out of the equations for forceinf!
        popM=pm.injpartnershippop(psh,1); % "Male" population (e.g. 5 = CSW)
        popF=pm.injpartnershippop(psh,2); % "Female" population (e.g. 10 = FIDU), but includes MSM and waria
        baseforceinfM=pm.transinjecting;
        baseforceinfF=pm.transinjecting;
        cleaningeffect=1-pm.syringecleaningefficacy*pm.syringecleaningprob(t);
        methadoneeffect=1-pm.methadoneefficacy*pm.methadoneprob(t);
        numsharedinjections=dt*pm.numinjectionpairs(psh,:,t)*pm.syringesharingprob(t);
       
        % WARNING, be careful about population size here too
        forceinfM=1 - (1-baseforceinfM*cleaningeffect) ^ (numsharedinjections(1)*methadoneeffect * effectivehivprevalence(popF)); %/populationsizeM); % Force of infection
        forceinfF=1 - (1-baseforceinfF*cleaningeffect) ^ (numsharedinjections(2)*methadoneeffect * effectivehivprevalence(popM)); %/populationsizeF); % Force of infection
        if any([forceinfM forceinfF]~=median([[forceinfM forceinfF];[0 0];[1 1]])), badforceinf('inj'), end % Error checking: make sure both values lie between 0 and 1
        
        forceinfvec(popM)=1-(1-forceinfvec(popM))*(1-forceinfM); % Calculate the new "male" forceinf, ensuring that it never gets above 1
        forceinfvec(popF)=1-(1-forceinfvec(popF))*(1-forceinfF); % Calculate the new "female" forceinf
        
        if extraoutput % Store information for calculating how many infections are caused by each population
            forceinfmatrix(popM,popF)=1-(1-forceinfmatrix(popM,popF))*(1-forceinfF); % Calculate how many people the male population infected
            forceinfmatrix(popF,popM)=1-(1-forceinfmatrix(popF,popM))*(1-forceinfM); % Calculate how many people the female population infected
        end
        
    end
    
    
    % Define treatment rate based on number of people on ART
    % WARNING, not implemented for ART2 yet
    fractionofpeopletotakeoffart = 0; % Don't need to worry about moving anyone off ART
    if isfield(pm,'numonart1') && ~isnan(pm.numonart1(t)) % Make sure it's defined -- WARNING, used to be >0 rather than ~NaN
        currentlyonart=sum(sum(people(pg.treat1,:,t)),2); % Number of people currently receiving ART
        shouldgoonart=pm.numonart1(t)-currentlyonart; % Number of people who should be put on ART in this timestep
        dogoonart=sum(sum(people(pg.diag,:,t),2).*pm.treatment1rate(:,t)); % Number of people who will be put on ART, all else being equal
        mismatch=shouldgoonart/dogoonart; % The mismatch between the two numbers (WARNING, can be negative!)
        if mismatch>=0
            for z=1:length(pm.treatment1rate(:,t)) % Adjust each CD4 treatment rate separately (so if no treatment >350, still won't be)
                pm.treatment1rate(z,t)=min([pg.maxrate,pm.treatment1rate(z,t)*mismatch]); % Set treatment rate
            end
        else
            pm.treatment1rate(:,t)=0; % Nobody new goes on ART
            fractionofpeopletotakeoffart = (currentlyonart-pm.numonart1(t))/currentlyonart; % Fraction of people to take off ART
        end
    end
    
    % Define treatment rate based on percent of people on ART
    if isfield(pm,'percentonart1') && ~isnan(pm.percentonart1(t)) % Make sure it's defined
        error('Code is buggy, don''t use')
%         currentlyonart=sum(sum(people(pg.treat1,:,t)),2); % Number of people currently receiving ART
%         shouldbeonart=pm.percentonart1(t)*sum(sum(people([pg.diag pg.treat1],:,t)),2); % Number of people who should be on ART
%         shouldgoonart=shouldbeonart-currentlyonart; % Number of people who should be put on ART in this timestep
%         dogoonart=sum(sum(people(pg.diag,:,t),2).*pm.treatment1rate(:,t)); % Number of people who will be put on ART, all else being equal
%         mismatch=shouldgoonart/dogoonart; % The mismatch between the two numbers (WARNING, can be negative!)
%         for z=1:length(pm.treatment1rate(:,t)) % Adjust each CD4 treatment rate separately (so if no treatment >350, still won't be)
%             pm.treatment1rate(z,t)=median([0,pg.maxrate,pm.treatment1rate(z,t)*mismatch]); % Set treatment rate
%         end
    end
    
    %% Optional tweaks
    % Turn off transmission after a certain time
    if isfield(options,'turnofftransmission')
        if pg.pts(t)>abs(options.turnofftransmission)
            if options.turnofftransmission>0, forceinfvec(:)=0; end % Just turn off transmission but keep simulation running
            if options.turnofftransmission<0, break, end % Don't bother running past that point
        end
    end
    % Population tweaks
    if isfield(options,'movepeople')
        if pg.pts(t)==abs(options.movepeople.year)
            if ~all(size(options.movepeople.array)==size(people(:,:,t))), error('Movepeople array must be same size as people array'), end
            people(:,:,t)=people(:,:,t)+options.movepeople.array; % Shift people around
        end
    end
    
    %% Population transitions
    % Loop over each entered asymmetric population transition -- people move from one population to the other
    for tr=1:length(pm.transitions.asym.rate)
        peoplemoving=people(:,pm.transitions.asym.pop1(tr),t)*abs(pm.transitions.asym.rate(tr))*dt; % Calculate the number of people who are leaving
        if pm.transitions.asym.rate(tr)>=0 % Normal situation, e.g. aging: people move from one to another
            people(:,pm.transitions.asym.pop1(tr),t)=people(:,pm.transitions.asym.pop1(tr),t)-peoplemoving; % Subtract them from the first population
            people(:,pm.transitions.asym.pop2(tr),t)=people(:,pm.transitions.asym.pop2(tr),t)+peoplemoving; % Add them to the second population
        else % Otherwise: it's births, people stay in the original population and start off at CD4>500 in the second population
            mtctprob = pm.transmtct*(1-pm.pmtctefficacy*pm.pmtctrate(t)); % Calculate probability of mother-to-child transmission per birth
            people([pg.sus pg.undiag(1)],pm.transitions.asym.pop2(tr),t)=people([pg.sus pg.undiag(1)],pm.transitions.asym.pop2(tr),t)+sum(peoplemoving)*[1-mtctprob; mtctprob]; % Add them to the second population
        end
    end
    % Loop over each entered symmetric population transition -- people swap between two populations
    for tr=1:length(pm.transitions.sym.rate) 
        pop1=people(:,pm.transitions.sym.pop1(tr),t); % Shorten the first population
        pop2=people(:,pm.transitions.sym.pop2(tr),t); % ...and the second
        peoplemoving1=pop1*pm.transitions.sym.rate(tr)*dt; % Calculate the number of people who moving pop1 -> pop2
        peoplemoving2=pop2*pm.transitions.sym.rate(tr)*dt*sum(pop1)/sum(pop2); % Calculate the number of people who moving pop2 -> pop1, correcting for population size
        people(:,pm.transitions.sym.pop1(tr),t)=people(:,pm.transitions.sym.pop1(tr),t)-peoplemoving1+peoplemoving2; % Correct size of first population
        people(:,pm.transitions.sym.pop2(tr),t)=people(:,pm.transitions.sym.pop2(tr),t)+peoplemoving1-peoplemoving2; % Correct size of first population
    end
    
    
    %% The ODEs

    % Susceptibles
    dS = -forceinfvec'.*people(1,:,t); % Change in number of susceptibles -- note, death rate already taken into account in pm.totalpop and dt
    
    % Undiagnosed
    for cd4=1:pg.ncd4
        if cd4>1,        progin=dt*pm.progressionrate(cd4-1)*people(pg.undiag(cd4-1),:,t); else  progin=0; end
        if cd4<pg.ncd4, progout=dt*pm.progressionrate(cd4)  *people(pg.undiag(cd4),:,t);   else progout=0; end
        if cd4<pg.cd4aids, testingrate=dt*pm.testingrate(:,t)'; else testingrate=dt*pm.testingrateaids(t); end
        hivdeaths=dt*pm.deathhiv(cd4)*people(pg.undiag(cd4),:,t); sim.hivdeaths(:,t)=sim.hivdeaths(:,t)+hivdeaths'/dt;
        dU{cd4} = progin-progout - hivdeaths - (dt*pm.deathbackground+testingrate).*people(pg.undiag(cd4),:,t);
        if extraoutput
            sim.deathsbycd4(cd4,:,t)=sim.deathsbycd4(cd4,:,t)+hivdeaths/dt;
        end
    end
    dU{1} = dU{1} + forceinfvec'.*people(1,:,t); % Add newly infected people

    % Diagnosed
    for cd4=1:pg.ncd4
        if cd4>1,        progin=dt*pm.progressionrate(cd4-1)*people(pg.diag(cd4-1),:,t); else  progin=0; end
        if cd4<pg.ncd4, progout=dt*pm.progressionrate(cd4)  *people(pg.diag(cd4),:,t);   else progout=0; end
        if cd4<pg.cd4aids, testingrate=dt*pm.testingrate(:,t)'; else testingrate=dt*pm.testingrateaids(t); end
        newdiagnoses=testingrate.*people(pg.undiag(cd4),:,t);
        hivdeaths=dt*pm.deathhiv(cd4)*people(pg.diag(cd4),:,t); sim.hivdeaths(:,t)=sim.hivdeaths(:,t)+hivdeaths'/dt;
        dD{cd4}= progin-progout + newdiagnoses - hivdeaths - (dt*pm.deathbackground+dt*pm.treatment1rate(cd4,t)).*people(pg.diag(cd4),:,t);
        if extraoutput
            sim.diagnoses(:,t)=sim.diagnoses(:,t)+squeeze(newdiagnoses)'/dt;
            sim.dxbycd4(cd4,:,t)=sim.dxbycd4(cd4,:,t)+newdiagnoses/dt;
            sim.deathsbycd4(cd4,:,t)=sim.deathsbycd4(cd4,:,t)+hivdeaths/dt;
        end
    end

    % 1st-line treatment
    for cd4=1:pg.ncd4
        if cd4<pg.ncd4, recovin=dt*pm.recoveryrate(cd4)   *people(pg.treat1(cd4+1),:,t); else  recovin=0; end
        if cd4>1,       recovout=dt*pm.recoveryrate(cd4-1)*people(pg.treat1(cd4),:,t);   else recovout=0; end
        peopletotakeoffart = fractionofpeopletotakeoffart*people(pg.treat1(cd4),:,t);
        newtreat=dt*pm.treatment1rate(cd4,t)*people(pg.diag(cd4),:,t) - peopletotakeoffart*pg.maxrate*dt; % WARNING, KLUDGY way to avoid errors by reducing maximum rate
        hivdeaths=dt*pm.deathtreatment*people(pg.treat1(cd4),:,t); sim.hivdeaths(:,t)=sim.hivdeaths(:,t)+hivdeaths'/dt;
        dT1{cd4}=recovin - recovout + newtreat - hivdeaths - (dt*pm.deathbackground+dt*pm.treatment1failurerate).*people(pg.treat1(cd4),:,t);
        if extraoutput
            sim.newtreat1(:,t)=sim.newtreat1(:,t)+squeeze(newtreat)'/dt; 
            sim.tx1bycd4(cd4,:,t)=sim.tx1bycd4(cd4,:,t)+newtreat/dt;
            sim.deathsbycd4(cd4,:,t)=sim.deathsbycd4(cd4,:,t)+hivdeaths/dt;
        end
    end

    % Treatment failure
    for cd4=1:pg.ncd4
        if cd4>1,        progin=dt*pm.progressionrate(cd4-1)*people(pg.fail(cd4-1),:,t); else  progin=0; end
        if cd4<pg.ncd4, progout=dt*pm.progressionrate(cd4)  *people(pg.fail(cd4),:,t);   else progout=0; end
        peopletotakeoffart = fractionofpeopletotakeoffart*people(pg.treat1(cd4),:,t)*pg.maxrate*dt;
        hivdeaths=dt*pm.deathhiv(cd4)*people(pg.fail(cd4),:,t); sim.hivdeaths(:,t)=sim.hivdeaths(:,t)+hivdeaths'/dt;
        dF{cd4}=progin-progout + peopletotakeoffart - hivdeaths + dt*pm.treatment1failurerate*people(pg.treat1(cd4),:,t) + dt*pm.treatment2failurerate*people(pg.treat2(cd4),:,t) - (dt*pm.deathbackground+dt*pm.treatment2rate(t)).*people(pg.fail(cd4),:,t);
        if extraoutput
            sim.deathsbycd4(cd4,:,t)=sim.deathsbycd4(cd4,:,t)+hivdeaths/dt;
        end
    end

    % 2nd-line treatment
    for cd4=1:pg.ncd4
        if cd4<pg.ncd4, recovin=dt*pm.recoveryrate(cd4)   *people(pg.treat2(cd4+1),:,t); else  recovin=0; end
        if cd4>1,       recovout=dt*pm.recoveryrate(cd4-1)*people(pg.treat2(cd4),:,t);   else recovout=0; end
        newtreat=dt*pm.treatment2rate(t).*people(pg.fail(cd4),:,t);
        hivdeaths=dt*pm.deathtreatment*people(pg.treat2(cd4),:,t); sim.hivdeaths(:,t)=sim.hivdeaths(:,t)+hivdeaths'/dt;
        dT2{cd4}=recovin-recovout + newtreat - hivdeaths - (dt*pm.deathbackground+dt*pm.treatment2failurerate).*people(pg.treat2(cd4),:,t);
        if extraoutput
            sim.newtreat2(:,t)=sim.newtreat2(:,t)+squeeze(newtreat)'/dt;
            sim.tx2bycd4(cd4,:,t)=sim.tx2bycd4(cd4,:,t)+newtreat/dt;
            sim.deathsbycd4(cd4,:,t)=sim.deathsbycd4(cd4,:,t)+hivdeaths/dt;
        end
    end    
    
    %% Output quantities
    sim.incidence(:,t)=-dS/dt;  % Save annual incidence
    if extraoutput
        for j=1:pg.npops % Calculate how many HIV infections were caused by each population
            infectionsvector=forceinfmatrix(j,:).*people(pg.sus,:,t)/dt; % Calculate annual infections vector
            infectionsvector=infectionsvector(~isnan(infectionsvector)); % Remove NaNs (caused by zero population size)
            sim.causehiv(j,t)=sim.causehiv(j,t)+sum(infectionsvector)/dt; % How many people were infected by a particular population annually
        end
    end
    
    %% Update next time point and check for errors
    if t<pg.npts
        change=[dS;vertcat(dU{:});vertcat(dD{:});vertcat(dT1{:});vertcat(dF{:});vertcat(dT2{:})]; % Combine all changes into a single array
        people(:,:,t+1)=people(:,:,t)+change; % Update people array unless it's the last timestep
        % Calculate correct population size
        newpeople=pm.populationsize(:,t+1)'-squeeze(sum(people(:,:,t+1),1)); % Was just the difference in pm.populationsize -- which could be totally different from the actual number of people!
        for j=1:pg.npops % Loop over each population, since some might grow and others might shrink
            if newpeople(j)>=0 % People are entering: they enter the susceptible population
                people(1,j,t+1)=people(1,j,t+1)+newpeople(j); % Number of people entering is the difference between the current model population size and the next time step's defined population size
            else % People are leaving: they leave from each health state equally
                people(:,j,t+1)=people(:,j,t+1)*pm.populationsize(j,t)/sum(people(:,j,t));
            end
        end
        if ~all(all(people(:,:,t+1)>=0)), badpeople(), end % If not every element is a real number >0, throw an error
    end

end

% Housekeeping/extra outputs
sim.people=people; % Save people array
if any(isnan(sim.people)), error('NaN detected in people array'), end
sim.overallprev=(squeeze(sum(sum(people(2:end,:,:),1),2))./squeeze(sum(sum(people(:,:,:),1),2)))'; % Calculate overall prevalence
for j=1:pg.npops
    sim.prevalence(j,:) =squeeze(sum(people(2:pg.nstates,j,:),1))'./sim.allpeople(j,:);  % Save prevalence by summing over infected states
    sim.numontreat1(j,:)=squeeze(sum(people(pg.treat1,j,:),1))'; % Sum over all treatment 1 CD4 counts
    sim.numontreat2(j,:)=squeeze(sum(people(pg.treat2,j,:),1))'; % Sum over all treatment 2 CD4 counts
end 

% Calculate mother-to-child transmission
femalepops=logical(pg.popismale(logical(pg.popinuse))==0);
untreatedbirths=squeeze(sum(sum(people(2:end,femalepops,:),1),2))'.*pm.transmtct.*pm.birthrate(1:pg.npts); % Total number of infected births over time assuming no PMTCT -- WARNING, should it be 2:end or [pg.undiag pg.diag pg.fail]? NB: need 1:pg.npts to handle equilibrium code
sim.mtct=untreatedbirths.*(1-pm.pmtctefficacy*pm.pmtctrate(1:pg.npts)); % And adjust for PMTCT





%% Troubleshooting

% Start troubleshooting if negative people were found
    function badpeople() 
        fprintf('The model calculated bad people at time %0.1f; troubleshooting...\n',pg.pts(t+1))
        for st=1:pg.nstates
            for po=1:pg.npops % po = population, don't want to use pop since used elsewhere
                numpeople=people(st,po,t+1);
                if numpeople<0 || ~isreal(numpeople)
                    fprintf('  Population "%s" in disease state %i at time %0.1f is invalid (=%f)!\n',pg.fullpopnames{po},st,pg.pts(t),numpeople)
                    if     any(pg.sus==st),    disp('    Rates for susceptible population ODEs are too high.');
                    elseif any(pg.undiag==st), disp('    Rates for undiagnosed population ODEs are too high.');
                    elseif any(pg.diag==st),   disp('    Rates for diagnosed population ODEs are too high.');
                    elseif any(pg.treat1==st), disp('    Rates for treatment 1 population ODEs are too high.');
                    elseif any(pg.fail==st),   disp('    Rates for treatment failure population ODEs are too high.');
                    elseif any(pg.treat2==st), disp('    Rates for treatment 2 population ODEs are too high.');
                    else                       disp('    Hmm, that''s weird...problem does not seem to belong to any ODE!');
                    end
                end
            end
        end
        error('Negative or imaginary people are generally inadvisable.')
    end

% Error checking for force-of-infection
    function badforceinf(partnershiptype)
        fprintf('Problem with force-of-infection, troubleshooting...\n')
        problemfound=false;
        switch partnershiptype
            case 'sex'
                paramnames={'transmissibilityM','transmissibilityF','circumcisioneffectM','circumcisioneffectF','stieffectM','stieffectF','otherinterventioneffectM','otherinterventioneffectF','dt','numacts','condomeffect','effectivehivprevalence(popF)','effectivehivprevalence(popM)'};
            case 'inj'
                paramnames={'baseforceinfM','baseforceinfF','cleaningeffect','dt','numsharedinjections','methadoneeffect','effectivehivprevalence(popF)','effectivehivprevalence(popM)'};
        end
        nparams=length(paramnames);
        for par=1:nparams
            thisparam=eval(paramnames{par});
            if ~(thisparam>=0 && thisparam<Inf)
                fprintf('  Parameter "%s" appears to have an invalid value: %f',paramnames{par},thisparam)
                problemfound=true;
            end
        end
        if problemfound==false
            fprintf('  There is something wrong with one or more of these parameters:\n')
            for par=1:nparams
                fprintf('    %s: %f',paramnames{par},thisparam)
            end
        end
        error('Parameters produced an invalid force-of-infection (M=%f, F=%f).',forceinfM,forceinfF)
    end

end


