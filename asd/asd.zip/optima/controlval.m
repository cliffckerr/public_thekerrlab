%% CONTROLVAL
% The companion function to controlfit -- whereas controlfit reads in
% unevely spaced (x,y) data and returns a number of control point "meta"
% parameters, this function reads in the control point parameters and
% returns the value of the function at the time points given by "yrs".
%
% Version: 2012dec01

function ydata=controlval(cyrs,cpars,yrs)

if length(cyrs)<=4, method=1; % Choose interpolation method: if normal control points, use cosine interpolation
else method=2; % If lots of control points, use slower (but perhaps more accurate) pchip method
end

% My cosine method: much faster, but a little dodgy at the control points (zero slope)
if method==1
    % Figure out which parts need to be extrapolated (outsideyrs) and which don't (insideyrs)
    insideyrs=(yrs>=cyrs(1) & yrs<=cyrs(end));
    loweryrs=yrs<cyrs(1);
    upperyrs=yrs>cyrs(end);
    ydata=zeros(size(yrs))-17;
    
    npts=length(cyrs); % Number of control points
    if npts~=length(cpars), error('Control years and control points don''t match!'), end
    if npts==0
        error('No control points were entered!')
    elseif npts==1
        ydata=cpars*ones(npts,1);
    elseif npts==2
        ydata(loweryrs)=cpars(1);
        ydata(upperyrs)=cpars(end);
        inyrs=yrs(insideyrs);
        if length(yrs)==1, ydata(insideyrs)=(cpars(end)-cpars(1))/2*(1-cos(pi*(yrs-cyrs(1))/(cyrs(end)-cyrs(1))))+cpars(1);
        else ydata(insideyrs)=(cpars(end)-cpars(1))/2*(1-cos(pi*(inyrs-inyrs(1))/(inyrs(end)-inyrs(1))))+cpars(1);
        end
    elseif npts>2 % WARNING, not complete! Currently has zero slope at each control point -- not desirable.
        ydata(loweryrs)=cpars(1);
        ydata(upperyrs)=cpars(end);
        for i=1:npts-1 % Loop over control points
            theseind=(yrs>=cyrs(i) & yrs<=cyrs(i+1));
            theseyrs=yrs(theseind);
            if length(yrs)==1, ydata(theseind)=(cpars(i+1)-cpars(i))/2*(1-cos(pi*(yrs-cyrs(i))/(cyrs(i+1)-cyrs(i))))+cpars(i);
            else               ydata(theseind)=(cpars(i+1)-cpars(i))/2*(1-cos(pi*(theseyrs-theseyrs(1))/(theseyrs(end)-theseyrs(1))))+cpars(i);
            end
        end
    else
        error('Weird number of points!')
    end
end

% Simple spline interpolation -- potentially more accurate, but much much slower
if method==2
    yyearss=[cyrs(1)-1 cyrs(:)' cyrs(end)+1];
    pparss=[cpars(1) cpars(:)' cpars(end)];
    if length(yyearss)~=length(pparss), disp('Lengths don''t match!'), keyboard, end
    ydata=pchip(yyearss,pparss,yrs); % Interpolate smoothly and monotonically over selected points
end

if any(isnan(ydata))
    ydata(isnan(ydata))=mean(cpars); % NaNs arise when cpars is Inf or -Inf, so try replacing with the mean
    if any(isnan(ydata)), error('controlval: unfixable NaN'), end % If it doesn't work, it's because mean() isn't defined
end

end