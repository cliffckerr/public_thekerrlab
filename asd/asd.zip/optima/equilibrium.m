%% EQUILIBRIUM
% This program runs the model until a steady-state is reached. It's not an
% ideal code, either in terms of speed or outcome, but finding the
% (nonexistent) equilibrium point is difficult!
%
% Inputs: general parameters (pg) and model parameters (pm)
% Outputs: model parameters with updated initial population.
%
% Version: 2012nov02

function pm=equilibrium(pg,pm)

opt=setoptions();

interactive=0; % Display debugging information
threshold=0.01; % This is really pretty arbitrary.
maxcount=1000*sign(opt.equilibrate); % Allow turning off whole program in one fell swoop

% Check that prevalence isn't too high
maxprevalence=0.95; % Don't allow initial prevalence to be higher than this
invalidprevalence=(pm.initialhivprevalence>maxprevalence);
if any(invalidprevalence)
    warning('equilibrium:prev1','HIV prevalence too high; resetting')
    pm.initialhivprevalence(invalidprevalence)=maxprevalence;
end

%% Initialize guess using rates
% Normalize rates to each other: assume that the following ratios are
% equivalent:
% undiagnosed :  diagnosed   :   treatment 1   :   failure    : treatment 2
%                                   =
% prevalence  : testing rate : treatment1 rate : failure rate : treatment2 rate

% Start off all undiagnosed, equally distributed among CD4 count
pm.initialpop=zeros(pg.nstates,pg.npops);
pm.initialpop(1,:)=(1-pm.initialhivprevalence).*pm.populationsize(:,1);
for state=pg.undiag
    pm.initialpop(state,:)=pm.initialhivprevalence.*pm.populationsize(:,1)/(pg.ncd4);
end

if opt.equilibrate==1
    % Intialize rates to be used
    prevalence=pm.initialhivprevalence;
    testingrate=pm.testingrate(:,1);
    testingrateaids=pm.testingrateaids(1);
    treatment1rate=pm.treatment1rate(:,1);
    failurerate=pm.treatment1failurerate(:,1);
    treatment2rate=pm.treatment2rate(1);
    
    % Move people from undiagnosed to diagnosed
    for s=1:pg.ncd4
        peopletomove=pm.initialpop(pg.undiag(s),:)'.*testingrate./(eps+prevalence+testingrate); % Added epsilon to avoid divide-by-zero
        pm.initialpop(pg.undiag(s),:)=pm.initialpop(pg.undiag(s),:)-peopletomove';
        pm.initialpop(pg.diag(s),:)=peopletomove';
    end
    
    % Handle people being diagnosed because of AIDS
    aidspeopletomove=pm.initialpop(pg.undiag(pg.cd4aids),:)'.*testingrateaids./(eps+prevalence+testingrateaids);
    pm.initialpop(pg.undiag(pg.cd4aids),:)=pm.initialpop(pg.undiag(pg.cd4aids),:)-aidspeopletomove';
    pm.initialpop(pg.diag(pg.cd4aids),:)=pm.initialpop(pg.diag(pg.cd4aids),:)+aidspeopletomove';
    
    % Move people from diagnosed to treatment 1
    for s=1:pg.ncd4
        for p=1:pg.npops
            peopletomove=pm.initialpop(pg.diag(s),p)*treatment1rate(s)/(eps+treatment1rate(s)+testingrate(p));
            pm.initialpop(pg.diag(s),p)=pm.initialpop(pg.diag(s),p)-peopletomove;
            pm.initialpop(pg.treat1(s),p)=peopletomove;
        end
    end
    
    % Move people from treatment 1 to treatment failure
    for s=1:pg.ncd4
        for p=1:pg.npops
            peopletomove=pm.initialpop(pg.treat1(s),p)*failurerate/(eps+failurerate+treatment1rate(s));
            pm.initialpop(pg.treat1(s),p)=pm.initialpop(pg.treat1(s),p)-peopletomove;
            pm.initialpop(pg.fail(s),p)=peopletomove;
        end
    end
    
    % Move people from treatment failure to treatment 2
    for s=1:pg.ncd4
        for p=1:pg.npops
            peopletomove=pm.initialpop(pg.fail(s),p)*treatment2rate/(eps+treatment2rate+failurerate);
            pm.initialpop(pg.fail(s),p)=pm.initialpop(pg.fail(s),p)-peopletomove;
            pm.initialpop(pg.treat2(s),p)=peopletomove;
        end
    end
end


%% Calculate equilibrium
originaldistribution=sum(pm.initialpop,2);

eqpg=pg;
eqpg.npts=2; % Don't need to run for a long time: just a single timestep
count=0;
oldchange=nan;
if interactive==1, allresults=zeros(pg.nstates,maxcount); end
while count<maxcount % If it hasn't gotten there after 500 iterations, give up
    count=count+1;
    oldpop=pm.initialpop;
    sim=model(eqpg,pm,0);
    newpop=sim.people(:,:,2); % Save second timepoint as new guess (first time point was old guess)
    for pop=1:pg.npops
        newpop(1,    pop)=newpop(1,    pop) / sum(newpop(1,    pop)) * (1-pm.initialhivprevalence(pop)) .* pm.populationsize(pop,1); % Make sure the number of susceptibles is correct
        newpop(2:end,pop)=newpop(2:end,pop) / sum(newpop(2:end,pop)) *    pm.initialhivprevalence(pop)  .* pm.populationsize(pop,1); % Make sure the number of infecteds is correct
    end
    if any(isnan(newpop(:))), error('Equilibrium generated a NaN'), end
    pm.initialpop=newpop;
    new=sum(newpop,2);
    old=sum(oldpop,2);
    if interactive==1, allresults(:,count)=old; end
    newchange=max(abs((new-old)./(old+1)))*pg.timestep; % Take into account timestep too. Add 1 to avoid divide-by-zero problems.
    if interactive==1, fprintf('%i %f %f %f %f\n',count,newchange,oldchange,newchange-oldchange,threshold), end
    if newchange<threshold, break, end
    oldchange=newchange;
end

newdistribution=sum(pm.initialpop,2);

if interactive==1
    disp([originaldistribution newdistribution])
    figure; stem3(log10(allresults(:,1:count)+1),'linestyle','none')
    keyboard
end

end