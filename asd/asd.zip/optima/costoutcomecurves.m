%% COSTOUTCOMECURVES
% This code defines the cost-outcome curves that are used for optimal
% allocations.
% Version: 2013sep17

function [pm, dalychange, programnames] = costoutcomecurves(pm,pg,allocation,scenpoints)

%% Preliminaries
programnames={'Behavior change','Condom','PMTCT','Circumcision','FSW','MSM','ART','Testing', 'Incentives', 'OVC', 'PLHIV'};
FYTH=3;	MYTH=4;	FTEEN=5; MTEEN=6; FYAD=7; MYAD=8; FAD=9; MAD=10; FOLD=11; MOLD=12; FSW=13; MSM=14; % Define populations
bcc=1; cnd=2; pmt=3; vmc=4; fsw=5; msm=6; art=7; hct=8; ovc=9; % Make it so I can refer to programs by their names, e.g. VCT = 7
logistic=@(x,p) (p(2)-p(1))./(1+exp(-(x-p(3))/p(4)))+p(1); % Define a simple logistic equation; see below for a more general formula

%% Programs

% From comparing Spectrum estimates to previous results
bccfac = 1.603603604;
confac = 0.205607477;
pmtfac = 3.111731844;
vmcfac = 1;
fswfac = 2;
msmfac = 4;
artfac = 1.659377317;
vctfac = 0.785714286;

% 1. BCC
for p=[FYAD FAD]; pm.numactsregular(p,scenpoints)=logistic(allocation(bcc),[40 35 0 5e5*bccfac]); end
for p=[MYAD MAD]; pm.numactsregular(p,scenpoints)=logistic(allocation(bcc),[50 45 0 5e5*bccfac]); end

% 2. Condom
for p=[FYTH MYTH FTEEN MTEEN], pm.condomprobcasual(p,scenpoints)=logistic(allocation(cnd),[0 0.77 2e5*confac 5e5*confac]); end % Male and female youth condom rate
for p=[FYAD MYAD FAD MAD],   pm.condomprobcasual(p,scenpoints)=logistic(allocation(cnd),[0 0.70 2e5*confac 5e5*confac]); end % Male and female adult condom rate
for p=[FOLD MOLD], pm.condomprobcasual(p,scenpoints)=logistic(allocation(cnd),[0 0.50 2e5*confac 1e6*confac]); end % Male and female elderly condom rate

% 3. PMTCT
pm.pmtctrate(scenpoints)=logistic(allocation(pmt),[-0.95 0.95 0 5e5*pmtfac]); % PMTCT rate

% 4. VMC
for p=[MYTH MTEEN MYAD MAD MOLD], pm.circumcisionprob(p,scenpoints)=logistic(allocation(vmc),[-0.60 0.70 0 8e5*vmcfac]); end % Male circumcision

% 5. FSW
for p=[FSW MYAD MAD MOLD], pm.condomprobother(p,scenpoints)=logistic(allocation(fsw),[0.30 0.95 0 3e4*fswfac]); end % FSW condom use

% 6. MSM
pm.condomprobcasual(MSM,scenpoints)=logistic(allocation(msm),[-0.30 0.81 0 8e3*msmfac]); % MSM condom use

% 7. ART
pm.numonart1=nan(pg.npts,1);
pm.numonart1(scenpoints)=logistic(allocation(art),[-210e3 210e3 0 2.7e7*artfac]); % ART

% 8. HCT
for p=[FYTH FTEEN FYAD FAD FOLD], pm.testingrate(p,scenpoints)=logistic(allocation(hct),[-0.75 0.80 0 3.5e6*vctfac]); end % Female testing
for p=[MYTH MTEEN MYAD MAD MOLD], pm.testingrate(p,scenpoints)=logistic(allocation(hct),[-0.57 0.60 0 4e6*vctfac]); end % Male testing

% 9. OVC
ovcperperson=201/3; % 3 is a fudge factor since Richard assumed 30% coverage; I'm assuming 100% coverage
ovcdalyspp=0.36; % Richard used 0.055
ovcmaxspend=119e6/3;
maxovcamount=ovcdalyspp*ovcmaxspend/ovcperperson;
dalychange=min(maxovcamount,ovcdalyspp*allocation(ovc)/ovcperperson);
% dalychange=0;

end