%% MAKESCENARIOS
% This code makes the scenarios; runscenarios runs them. What it does is
% replace certain fields of pm with new versions.
% Version 2013may05

function pm=makescenarios(pm,data,whichscenario)

pm.name='Default'; % Initialize

% Set population size to have a constant annual rate of increase
poptime=zeros(data.general.npops,data.general.npts); % Initialize a blank array with dimensions population and time

pm.populationsize=poptime; % Initialize a blank array with dimensions population and time
annualincrease=0.015; % Annual rate of population increase
pm.populationsize(:,1)=data.populationsize(3,:,1); % Get Swazi population sizes
for t=2:data.general.npts, pm.populationsize(:,t)=pm.populationsize(:,t-1)*(1+annualincrease*data.general.timestep); end % Assume 1.5% annual rate of increase


end