%% OPTIMALSPEND
% This program finds the optimal spending allocation for a set of programs.
% How it works:
% - Prevtool data are loaded.
% - The current total spend and allocation is specified.
% - The model is run with those values from 2010-2020.
% - Each program is allowed to take on a value from [$0,$Inf]. The sum of all program spends is then divided to give the desired total.
% - The parameter values corresponding to the current spend level will be calculated.
% - The output quantity will be the number of infections in the time period.
% - This quantity will be optimized via a scatterchoice algorithm.
% - All output quantities from the optimal allocation will be saved.
% - This process will be repeated for different total spending levels.
% Version: 2014jun04

function [allocations,sims]=optimalspend




opt=setoptions(); % Get options, such as file name

%% Set parameters
tic
doplot=1;
dosave=1;
donotify=1;
dorandomize=0;
interventionstart=2013; % Year to start scenarios
interventionstop=Inf; % Year to stop scenarios
outcomestart=2013; % Year to start counting outcomes
outcomestop=2030; % Year to stop counting outcomes
datayeartouse=10; % Year that data are entered for economics code
discountrate=0.03; % Discounting rate to apply in the past and future
maxiters=120;
repeatsperbudget=1; % Number of times to fit each budget
optimizewhat='incidence';
savename=[opt.outputname 'tmp.mat'];
if doplot==1, figure('position',[200 200 800 600]), end


%% Load data to do optimal allocation on, plus logistic curve data
disp('Loading data...')
d=load(opt.matfilename); % Load Prevtool output

%% Run preliminary model
disp('Initializing...')
% if ~matlabpool('size'), matlabpool, end
[pg,pm]=setupmodel(d.data,d.equations,d.parstruct,1);
pm=equilibrium(pg,pm);

%% Specify programs
disp('Specifying programs....')
programnames={'Behavior change','Condom','PMTCT','Circumcision','FSW','MSM','ART','Testing','OVC'};
allocation=[1.78 0.22 5.57 0.08 0.1 0.04 44.77 3.41 34.68]'*1e6;
nprograms=length(allocation);
original=allocation; % Save original allocation
origtotal=sum(original);

scenpoints=find(pg.pts>=interventionstart & pg.pts<=interventionstop); % Which year to start the scenario
costpoints=find(pg.pts>=outcomestart & pg.pts<=outcomestop); % What years to calculate intervention over


%% Calculate the optimal allocation
disp('Running...')
starttime=now*86400;
budget=1;
allocations=zeros(nprograms,repeatsperbudget);
outcomes=zeros(repeatsperbudget,1);
sims = cell(repeatsperbudget,1);
for r=1:repeatsperbudget
    fprintf('%i/%i\n',r,repeatsperbudget)
    distribution=original; % Set the original distribution...sloppy I know
    if dorandomize==1
        randomize=rand(nprograms,1);
        distribution=randomize.*distribution; % Randomize
        distribution=distribution*origtotal/sum(distribution); % Correct mean
    end
    allocation=distribution*budget;
    totalspend=sum(allocation);
    [allocations(:,r),sims{r},outcomes(r)]=scatterchoice(allocation,scenpoints,costpoints,totalspend,d,pm,pg,maxiters,starttime,doplot,programnames,datayeartouse,discountrate,optimizewhat); 
end
if dosave==1
    save(savename,'allocations','sims','budget','original','outcomes','programnames')
    fprintf('Results saved to %s.\n',savename)
end
     
toc

end





%% SCATTERCHOICE
% This function chooses a random parameter to optimize, then computes
% the error function of an increase or decrease in that parameter. If
% either the increase or decrease improves the fit, it keeps that value
% and increases its step size in that direction as well as the
% probability it will step with that parameter, the latter proportional
% to the amount the fit improved. If neither the increase nor decrease
% improve the fit, then it reduces the step size.
function [allocation,sim,output]=scatterchoice(allocation,scenpoints,costpoints,totalspend,d,pm,pg,maxiters,starttime,doplot,programnames,datayeartouse,discountrate,optimizewhat)
stepsize=1e5; % Default step size in thousands of dollars
stepincrease=1.5; % Amount by which to increase step size if error is smaller than current
stepdecrease=0.5; % Amount by which to decrease step size if both errors are larger than current
learnrate=10; % Amount by which to increase the probability of that parameter being selected
punishrate=0.5; % Amount by which to punish parameters that don't improve with either increases or decreases
nparams=length(allocation);
stepsizes=stepsize*ones(nparams,1);
probabilities=ones(nparams,1);
showprogress=1; % Show how optimization is doing

count=0; % For optimization later
[output,origsim]=modelfun(allocation);
while 1
    probabilities=probabilities/sum(probabilities);
    cumprobs=cumsum(probabilities);
    thisparam=find(cumprobs>rand,1);
    priorvecl=allocation;
    priorvecu=allocation;
    priorvecl(thisparam)=priorvecl(thisparam)-logical(count)*stepsizes(thisparam); % The logical(count) thing makes the first trial unchanged for plotting
    priorvecu(thisparam)=priorvecu(thisparam)+logical(count)*stepsizes(thisparam);
    priorvecl=max(priorvecl,0); % Don't let it go negative
    priorvecu=max(priorvecu,0);
    priorvecl=priorvecl*totalspend/sum(priorvecl); % Normalize
    priorvecu=priorvecu*totalspend/sum(priorvecu); % Normalize
    outputl=modelfun(priorvecl);
    outputu=modelfun(priorvecu);
    origoutput=output;
    quadrants={'Lower','Upper','Mountain','Valley'};
    if outputl<output && outputu>=output % Lowering it improved it
        probabilities(thisparam)=probabilities(thisparam)+learnrate*(output/outputl-1); % Increase probability of picking this parameter again
        stepsizes(thisparam)=stepsizes(thisparam)*stepincrease; % Increase size of step for next time
        output=outputl; % Reset current error
        allocation=priorvecl; % Reset current parameters
        quadrant=1;
    elseif outputu<output && outputl>=output % Raising it improved it
        probabilities(thisparam)=probabilities(thisparam)+learnrate*(output/outputu-1); % Increase probability of picking this parameter again
        stepsizes(thisparam)=stepsizes(thisparam)*stepincrease; % Increase size of step for next time
        output=outputu; % Reset current error
        allocation=priorvecu; % Reset current parameters
        quadrant=2;
    elseif outputu<=output && outputl<=output % They both did! Mountain
        if outputl<outputu
            output=outputl; % Reset current error
            allocation=priorvecl; % Reset current parameters
        elseif outputu<outputl
            output=outputu; % Reset current error
            allocation=priorvecu; % Reset current parameters
        end
        quadrant=3;
    elseif outputu>=output && outputl>=output % Neither did: Valley
        stepsizes(thisparam)=stepsizes(thisparam)*stepdecrease;
        probabilities(thisparam)=probabilities(thisparam)*punishrate;
        quadrant=4;
    else
        error('Something impossible happened')
    end
    
    count=count+1;
    everyallocation(count,:)=allocation; %#ok<AGROW> WARNING SUPER KLUDGY
    if ~mod(count-1,showprogress) && showprogress>0
        fprintf('  %i/%i | %i s | Indicator: %i\n',count,maxiters,round(now*86400-starttime),output)
        if doplot==1
            clf
            nprograms=length(allocation);
            colors=vectocolor(1:nprograms);
            for pp=1:nprograms
                plot(everyallocation(1:count,pp),'linewidth',2,'color',colors(pp,:)); hold on
            end
            legend(programnames(1:nprograms))
            xlim([1 maxiters])
            drawnow
            fprintf('    Par: %s Type: %s L: %f U: %f\n',programnames{thisparam}, quadrants{quadrant}, outputl-origoutput, outputu-origoutput)
            disp([allocation probabilities stepsizes])
        end
    end
    if count>=maxiters, break, end % Stop if done enough iterations
end
[output,sim]=modelfun(allocation); % Calculate final results





%% Calculate current infections based on spend
    function [output,sim]=modelfun(allocation)
        
        [pm, dalyschange] = costoutcomecurves(pm,pg,allocation,scenpoints);
        
        % Run the model
        options.turnofftransmission=-2032; % Only run model until this date; the minus sign aborts
        [pg,pm]=setupmodel(d.data,d.equations,pm,1);
        pm=equilibrium(pg,pm);
        sim=model(pg,pm,1,options);
        if strcmp(optimizewhat,'incidence')
            mtctfactor=1; % WARNING KLUDGY -- factor for how many additional infections children count for
            incidence=sum(sum(sim.incidence(:,costpoints),2))/length(costpoints) + mtctfactor*sum(sim.mtct(costpoints))/length(costpoints); % To exclude low-risk population, use 3:end instead of :
            output=incidence;
        elseif strcmp(optimizewhat,'dalys')
            cost = economics(sim,d.data,costpoints,2013,datayeartouse,discountrate); % 2018 is the "current" year for the sake of inflation
            deathfactor=20; % Equivalent DALYs for death
            mtctfactor=20; % WARNING KLUDGY -- factor for how many additional DALYs children count for
            deaththing = deathfactor*sum(sum(sim.hivdeaths(:,costpoints)))/length(costpoints);
            mtctthing = mtctfactor*sum(sim.mtct(costpoints))/length(costpoints);
            dalys = sum(cost.daly_disc)/length(costpoints) + deaththing + mtctthing;
            output=dalys-dalyschange;
%             [output deaththing mtctthing dalyschange]
        elseif strcmp(optimizewhat,'deaths')
            deathfactor = 100; % How many DALYs are used up for every person who dies
            output=sum(sum(sim.hivdeaths(:,costpoints)))/length(costpoints) - dalyschange/deathfactor; % Convert from DALYs to deaths
            disp([dalyschange/deathfactor output])
        elseif strcmp(optimizewhat,'fiscal')
            excelfilename='F:\swaziland\fiscal\swz-hiv-fisc-framework-prevtool.xls'; % Define filename
            
            disp('    1/7 Writing data...')
            skip=round(1/pg.timestep); % Number of elements to skip -- inverse of dt since once a year
            xlswrite(excelfilename,sim.incidence(:,1:skip:end)','pt-inc','B2:O52') % Write in data -- incidence
            % Quantities by CD4
            sexpops = {(pg.popismale==1),(pg.popismale==0),(pg.popismale==0.5)};
            table=zeros(length(sim.pts(1:skip:end)),12);
            cellcount=0;
            for s = 1:3
                for c = 1:4
                    cellcount=cellcount+1;
                    table(:,cellcount) = table(:,cellcount) + max(0,squeeze(sum(sim.tx1bycd4(c,sexpops{s},1:skip:end),2))); % Make sure it's positive -- might not be if people are going off treatment
                end
            end
            xlswrite(excelfilename,table,'pt-newtreat1','B2:M52')
            
            disp('    2/7 Opening workbook...')
            exobj = actxserver('Excel.Application');
            exobj.Visible = 1;
            exobj.Workbooks.Open(excelfilename); % Open file
            
            disp('    3/7 Running macros...')
            exobj.Run('SetARTCovPrevtool'); % Run macro
            exobj.Run('SetARTCovPrevtool'); % Run macro
            exobj.Run('SetARTCovPrevtool'); % Run macro
            exobj.Run('SetARTCovPrevtool'); % Run macro
            exobj.Run('SetARTCovPrevtool'); % Run macro
            exobj.Run('IncUpdateYears'); % Run macro
            exobj.Run('Commit'); % Run macro
            
            disp('    4/7 Saving workbook...')
            exobj.Workbooks.Item(1).Save; % Save file
            disp('    5/7 Setting saved state...')
            exobj.Workbooks.Item(1).Saved=1; % Save file
            disp('    6/7 Closing workbook...')
            exobj.Workbooks.Item(1).Close; % Close file
            exobj.Quit;
            exobj.release;
            
            disp('    7/7 Reading output...')
            output=xlsread(excelfilename,'commit','B175'); % Get results
            
            % Put in limit for deaths
            costperdeath = 1e4; % Scale factor for deaths
            if ~exist('origsim','var'), origsim=sim; end % For first iteration
            origdeaths=sum(sum(origsim.hivdeaths(:,costpoints)));
            newdeaths=sum(sum(sim.hivdeaths(:,costpoints)));
            deathsfactor = costperdeath*max(0,origdeaths-newdeaths); % Add a factor for punishing extra deaths
            output = output + deathsfactor; % Add a factor for punishing extra deaths
            fprintf('                 Deaths factor: %f\n',deathsfactor)
        end
    end


end






