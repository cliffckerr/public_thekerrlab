%% HIVBATCH
% Runs the HIV plot thing in batch mode.
% Version: 2014jun10

nruns = 40;

if ~matlabpool('size'), matlabpool, end
parfor r=1:nruns
    fprintf('R U N  %i/%i\n\n\n',r,nruns)
    filename = sprintf('hivbatch-%02i.mat',r);
    hivplot(filename,r)
end

disp('D O N E')
