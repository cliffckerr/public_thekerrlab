%% HIVBATCHPLOT
% This plots the HIV example for the batch data created by hivbatch.m.
% Version: 2014aug05


%% Set things
disp('Starting...')
dosave = 1;
maxevals = 2000;
methods = {'BALLSD', 'Simplex', 'Levenberg-Marquardt', 'Simulated annealing', 'Genetic algorithm'};
initialguess=[1.78 0.22 5.57 0.08 0.1 0.04 44.77 3.41 34.68]'*1e6;
[~, ordering] = sort(initialguess);
programnames={'Behavior change','Condom','PMTCT','Circumcision','FSW','MSM','ART','Testing','OVC'};

%% Create data structures
nprograms = length(initialguess);
nmethods = length(methods);
niters = 41;
infectiondata = zeros(nmethods,maxevals,niters);


%% Load data
disp('Loading data...')
for i=0:niters-1
    filename = sprintf('hivbatch-%02i.mat',i);
    tmp = load(filename);
    if i==0
        pardata = tmp.pardata;
        defaultinfectiondata = tmp.infectiondata;
    else
        infectiondata(:,:,i) = tmp.infectiondata;
        infectiondata(2:3,:,i) = defaultinfectiondata(2:3,:);
    end
end


%% Plot
disp('Plotting...')
figure('position',[1000 100 800 800]);
xdata = 1:maxevals;

% Plot labels
ax=axes('position',[0 0 1 1],'units','normalized'); hold on
text(0.02,0.97,'A','fontsize',16,'fontweight','bold')
text(0.02,0.40,'B','fontsize',16,'fontweight','bold')
xlim([0 1])
ylim([0 1])
set(ax,'visible','off')

% New infections
nyears = 5;
quantiles = [0.5 0.25 0.75];
cksubplot([1 2], [1 1], [95 85], [0 0], [10 -2]); hold on
mcolors = {[0.5 0 1], [0.7 0.7 0.7], [0.9 0.6 0], [0 0.8 0], [0 0.6 1]};
handles = zeros(nmethods,2);
for m = 1:nmethods
    thesedata = squeeze(infectiondata(m,:,:)/nyears);
    results = quantile(thesedata,quantiles,2);
    [h1, h2] = errorshade(xdata, results(:,1), results(:,2), results(:,3), mcolors{m}, 0.3);
    handles(m,:) = [h1, h2];
end
xlabel('Function evaluations')
ylabel({'New infections per year',' '});
xlim([0 maxevals])
ylim([1000 2500])
lh = legend(handles(:,1), methods,'location','northeast');
set(lh, 'Box', 'off')
set(lh, 'Color', 'none')

% Pie charts
explodepie = 0; % Whether or not to explode the pie
piedata = {initialguess(ordering), squeeze(pardata(1,end,ordering))}; % Data is initial guess and then optimal from BALLSD
pielabels = cell(nprograms,1);
for p = 1:nprograms, pielabels{p} = ''; end
axes('position',[0.03 0.00 0.4 0.37])
pie(piedata{1}+eps, explodepie+zeros(nprograms,1), pielabels)
title('Current allocation','fontweight','bold')
legend(programnames(ordering),'location',[0.41 0.03 0.2 0.3])
axes('position',[0.6 0.00 0.4 0.37])
pie(piedata{2}+eps, explodepie+zeros(nprograms,1), pielabels)
title('Optimal allocation','fontweight','bold')

if dosave, savefig('hivbatch.svg'), end

disp('Done.')