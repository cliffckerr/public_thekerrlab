%% MONOCOLORMAP
% This program generates a value-monotonic colormap. The idea is that it is
% still visible in black and white, but clearer in color.
%
% The optional input argument sets whether the maximum color is white (1)
% or yellow (0).
%
% The transitions are as follows:
% black -> blue
% blue -> magenta
% magenta -> green
% green -> yellow
%
% Version: 2014feb06

function cmap=monocolormap(varargin)

if nargin>0, white=varargin{1}; else white=0; end % If input arguments, 

% Define primitives
delta=0.01;
rampup=(delta:delta:1)';
rampdown=(1:-delta:delta)';
npts=length(rampup);
flat0=zeros(npts,1);
flat1=ones(npts,1);
cmap=zeros(npts*(5+white),3);
p1=0*npts+1:1*npts;
p2=1*npts+1:2*npts;
p3=2*npts+1:3*npts;
p4=3*npts+1:4*npts;
p5=4*npts+1:5*npts;
if white, p6=5*npts+1:6*npts; end


cmap(p1,:)=[         flat0 0.0+rampup*0.2 rampup*0.5]; % Black -> Blue
cmap(p2,:)=[         flat0 0.2+rampup*0.2 rampdown*0.5]; % Blue -> Green
cmap(p3,:)=[    rampup*0.5 0.4+rampup*0.1 rampup*0.5]; % Green -> Gray
cmap(p4,:)=[0.5+rampup*0.3 0.5+rampup*0.2 0.3+rampdown*0.2]; % Gray -> Red
cmap(p5,:)=[0.8+rampup*0.2 0.7+rampup*0.3 rampdown*0.3]; % Red -> Yellow
if white, cmap(p6,:)=[         flat1          flat1 rampup]; end% Yellow -> White

colormap(cmap)

end

%% For plotting

% RandStream.setDefaultStream(RandStream('mt19937ar','seed',5))
% sampledata=cksmooth(rand(100),50);
% sampledata=sampledata-min(sampledata(:));
% sampledata=sampledata/max(sampledata(:));
% 
% figure('position',[1000 800 900 300])
% tmp=colormap;
% subplot(1,2,1); hold on
% plot((1:length(tmp))/length(tmp),tmp(:,1),'r')
% plot((1:length(tmp))/length(tmp),tmp(:,2),'g')
% plot((1:length(tmp))/length(tmp),tmp(:,3),'b')
% ylabel('Color intensities (RGB)')
% xlabel('Function value')
% title('Colormap: Jet')
% h=subplot(1,2,2);
% pcolor(sampledata)
% colormap(h,'jet')
% colorbar
% shading interp
% 
% figure('position',[1000 300 900 300])
% subplot(1,2,1); hold on
% plot((1:length(cmap))/length(cmap),cmap(:,1),'r')
% plot((1:length(cmap))/length(cmap),cmap(:,2),'g')
% plot((1:length(cmap))/length(cmap),cmap(:,3),'b')
% title('Colormap: Monotonic')
% ylabel('Color intensities (RGB)')
% xlabel('Function value')
% g=subplot(1,2,2);
% pcolor(sampledata)
% colormap(g,cmap)
% colorbar
% shading interp