%% VALLEYPLOTNEW
% This plots the valley, but better.
% Version: 2014jun05

function valleyplotnew()
tic

%% Set things
disp('Starting...')
seed = 0;
dosave = 1;
maxevals = 300;
nsteps = 200;
firststeps = 100;
npars = 10;
simannealtemp = 10;
initialguess = [1.5, -1.5 zeros(1,npars-2)];
methods = {'BALLSD', 'Simplex', 'Levenberg-Marquardt', 'Simulated annealing', 'Genetic algorithm'};
plotsizes = [-2,2,-2,3];


%% Create data structures
steps = unique([1:firststeps round(10.^(linspace(log10(firststeps+1),log10(maxevals),nsteps-firststeps)))]);
nsteps = length(steps);
nmethods = length(methods);
pardata = zeros(nmethods,nsteps,npars);
evaldata = zeros(nmethods,nsteps);
errdata = zeros(nmethods,nsteps);
m = 0; s = 0;


%% Calculate Rosenbrock function
    function E = rosenbrock(x)
        E = 100*(x(2) - x(1)^2)^2 + (1 - x(1))^2;
        
        if m>0 && s>0, 
            evaldata(m,s) = evaldata(m,s)+1; 
        end
    end

xpoints = plotsizes(1):0.1:plotsizes(2);
ypoints = plotsizes(3):0.1:plotsizes(4);
nxpts = length(xpoints);
nypts = length(ypoints);
valley = zeros(nypts,nxpts);
for i=1:nxpts
    for j=1:nypts
        valley(j,i) = rosenbrock([xpoints(i) ypoints(j)]);
    end
end

initialerr = rosenbrock(initialguess);
valley = valley/initialerr;
valley(valley==0) = min(valley(valley~=0)); % Remove zero elements with next smallest value



%% Set options
% For BALLSD
options.stepsize = 0.2;
options.sinc = 2;
options.sdec = 2;
options.pinc = 2;
options.pdec = 2;

% For other algorithms
options.Display = 'off';
options.Algorithm = 'levenberg-marquardt'; % To avoid lsqnonlin error messages
options.StallIterLimit = 1e6; % To stop simulated annealing from dying early
options.StallGenLimit = 1e6; % To stop genetic algorithm from dying early
options.PopulationSize = 40;
options.InitialTemperature = simannealtemp*mean(abs(initialguess));

%% Calculate everything
disp('Calculating...')
count = 0;
for m = 1:nmethods
    fprintf('  %s\n',methods{m})
    for s = 1:nsteps
        count = count+1;
        fprintf('    %i %i (%i/%i)\n',m,s, count,nmethods*nsteps)
        rng(seed)
        options.MaxFunEvals = steps(s);
        options.Generations = ceil(steps(s)/options.PopulationSize);
        options.PopInitRange = transpose(quantile(initialguess,[0 1]));
        if m==1,     x = ballsd(@rosenbrock, initialguess, options);
        elseif m==2, x = fminsearch(@rosenbrock, initialguess, options);
        elseif m==3, x = lsqnonlin(@rosenbrock, initialguess, [], [], options);
        elseif m==4, x = simulannealbnd(@rosenbrock, initialguess, [], [], options);
        elseif m==5, x = ga(@rosenbrock, length(initialguess), [], [], [], [], [], [], [], options);
        end
        pardata(m,s,:) = x;
    end
end


%% Recalculate errors
disp('Recalculating errors...')
for m = 1:nmethods
    for s = 1:nsteps
        errdata(m,s) = rosenbrock(squeeze(pardata(m,s,:))) / initialerr;
        errdata(m,s) = min(errdata(m,1:s)); % Find best-value-ever-found
    end
end

%% Plot
figure('position',[1000 100 800 800]);

% Plot labels
ax=axes('position',[0 0 1 1],'units','normalized'); hold on
text(0.02,0.97,'A','fontsize',16,'fontweight','bold')
text(0.02,0.37,'B','fontsize',16,'fontweight','bold')
text(0.51,0.37,'C','fontsize',16,'fontweight','bold')
xlim([0 1])
ylim([0 1])
set(ax,'visible','off')

cksubplot([1 2], [1 1], [95 110], [0 0], [8 5]); hold on
surf(xpoints,ypoints,valley)
view([0 90])
shading interp
box on
h = colorbar;
set(gca,'clim',[0 1.5])
colorbarlabel(h,'Relative error')
xlim(plotsizes(1:2))
ylim(plotsizes(3:4))

colors = {[0.5 0 1], [0.7 0.7 0.7], [0.9 0.6 0], [0 0.8 0], [0 0.6 1]};
delta = 2;
randomness = 0.0;

plotdata = pardata;
for m=1:nmethods
    for s = 2:nsteps
        if all(plotdata(m,s-1,:) == plotdata(m,s,:))
            plotdata(m,s,:) = plotdata(m,s,:) + randomness*randn(1,1,npars);
        end
    end
end

h = zeros(nmethods+1,1);
for m = nmethods:-1:1
    x = [initialguess(1) plotdata(m,:,1)];
    y = [initialguess(2) plotdata(m,:,2)];
    z = [0 (evaldata(m,:))]+delta;
    h(m) = plot3(x, y, z, '-s', 'color',colors{m},'linewidth',1.5,'markersize',8);
end
h(nmethods+1) = scatter3(1,1,delta+1,200,[1 0 0],'linewidth',2,'marker','+');
xlabel('x_1')
ylabel('x_2')
legend(h, [methods(:); {'Optimum'}],'location','southwest')

% Resize colormap
cm = monocolormap;
oldpts = length(cm);
newpts = 1e3;
newcm = zeros(newpts,3);
for i=1:3
    newcm(:,i) = interp1(linspace(0,1,oldpts), cm(:,i), (linspace(0,1,newpts).^0.75));
end
colormap(newcm)

% Make parameter plot
cksubplot([2 2], [1 2], [85 60], [0 0], [7 -6]); hold on
for m = nmethods:-1:1
    y = ones(nsteps+1,1);
    for s = 1:nsteps
        x = [0 steps];
        index = find(evaldata(m,:)<=steps(s),1,'last');
        if isempty(index), y(s+1) = 1;
        else y(s+1) = errdata(m,index);
        end
    end
    plot(x, y, '-', 'color',colors{m},'linewidth',2,'markersize',5);
    xlim([0 100])
    ylim([0 1.02])
end
ylabel('Relative error')
xlabel('Function evaluations')



% Make error plot
cksubplot([2 2], [2 2], [85 60], [0 0], [7 -6]); hold on
zeros(nmethods,1);
for m = 1:nmethods
    y = ones(nsteps+1,1);
    for s = 1:nsteps
        x = [0 steps];
        index = find(evaldata(m,:)<=steps(s),1,'last');
        if isempty(index), y(s+1) = 1;
        else y(s+1) = errdata(m,index);
        end
    end
    plot3(x, y, -m*ones(size(x)), '-', 'color',colors{m},'linewidth',2,'markersize',5);
    xlim([10 maxevals])
    ylim([1e-6 1.1])
end
view([0 90])
legend(methods,'location','northeast')
set(gca,'yscale','log')
ylabel('Relative error')
xlabel('Function evaluations')


if dosave, savefig('valley.png'), end

disp('Done.')
toc

end