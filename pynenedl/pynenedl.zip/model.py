"""
MODEL

The new network simulation for exploring traveling waves and SSM integration.
Built solely on Python, using Izhikevich neurons and MPI support. Runs in
real-time with over 8000 cells.

Usage:
    python model.py # Run simulation, optionally plot a raster
    python simmovie.py # Show a movie of the results
    python model.py scale=20 # Run simulation, set scale=20

MPI usage:
    mpiexec -n 4 nrniv -python -mpi model.py

Version: 2014feb21 by cliffk
"""


###############################################################################
### HOUSEKEEPING
###############################################################################

## Import things
from neuron import h, init # Import NEURON
from izhi import pyramidal, fastspiking, lowthreshold, thalamocortical, reticular # Import Izhikevich model
from pylab import any, inf, sqrt, exp, seed, ones, zeros, mean, rand, hstack, array, concatenate, figure, scatter, xlabel, ylabel, title, xlim, ylim, transpose, vstack, disp, show # Load plotting and math functions
from time import time; verystart=time() # Measure start time of simulation
from sys import argv # For handling command-line arguments
from datetime import datetime # For saving date info to file
import cellpopdata as cpd # Import population and connection data
ER2, IF2, IL2, ER5, EB5, IF5, IL5, ER6, IF6, IL6, AMPA, NMDA, GABAA, GABAB, opsin, Epops, Ipops, allpops = cpd.names2inds() # Define populations

## Set up MPI: see Hines and Carnevale 2008
pc = h.ParallelContext() # MPI: Initialize the ParallelContext class
nhosts = int(pc.nhost()) # Find number of hosts




###############################################################################
### SET PARAMETERS
###############################################################################

if pc.id()==0: print('\nSetting parameters...')


## Basic parameters
scale=32 # Size of simulation in thousands of cells
duration = 6*1e3 # Duration of the simulation, in ms
h.dt = 0.5 # Internal integration timestep to use
loopstep = 5 # Step size in ms for simulation loop -- not coincidentally the step size for the LFP
progupdate = 100 # How frequently to update progress, in ms
randseed = 0 # Random seed to use
maxspikestoplot = 3e6 # Maximum number of spikes to plot
limitmemory = True # Whether or not to limit RAM usage
doplot = True # Whether or not to plot a raster


## Saving parameters
dosave = True # Whether or not to write spikes etc. to a file
savelfps = True # Whether or not to save LFPs
lfppops = [[ER2], [ER5], [EB5], [ER6]] # Populations for calculating the LFP from
saveraw = False # Whether or not to record raw voltages etc.
verbosity = 0 # Whether to write nothing (0), diagnostic information on events (1), or everything (2) a file directly from izhi.mod
filename = 'opto-without-conns'  # Set file output name


## Connection parameters
useconnprobdata = True # Whether or not to use INTF6 connectivity data
useconnweightdata = True # Whether or not to use INTF6 weight data
mindelay = 2 # Minimum connection delay, in ms
velocity = 100 # Conduction velocity in um/ms (e.g. 50 = 0.05 m/s)
modelsize = 10000 # Size of network in um
scaleconnweight = 0*4*array([[2, 1], [2, 0.1]]) # Connection weights for EE, EI, IE, II synapses, respectively
receptorweight = [1, 1, 1, 1, 1] # Scale factors for each receptor
scaleconnprob = 200/scale*array([[1, 1], [1, 1]]) # Connection probabilities for EE, EI, IE, II synapses, respectively -- scale for scale since size fixed
connfalloff = 100*array([2, 3]) # Connection length constants in um for E and I synapses, respectively
toroidal = True # Whether or not to have toroidal topology
connprobs = cpd.setconnprobs() # Set inter-population connection probabilities from data
connweights = cpd.setconnweights() # Set inter-population connection weights from data
if useconnprobdata == False: connprobs = array(connprobs>0,dtype='int') # Optionally cnvert from float data into binary yes/no
if useconnweightdata == False: connweights = array(connweights>0,dtype='int') # Optionally convert from float data into binary yes/no


## STDP parameters
usestdp = False # Whether or not to use STDP
stdprates = 0.1*array([[1, -1], [0, 0]]) # Potentiation/depression for E->anything and I->anything, e.g. [0,:] is pot/dep for E cells
timebetweensaves = 2*1e3 # How many ms between saves (can't be smaller than loopstep)
maxweight = 50 # Maximum synaptic weight
timeoflastsave = -inf # Never saved


## Background input parameters
usebackground = True # Whether or not to use background stimuli
backgroundrate = 100 # Rate of stimuli (in Hz)
backgroundnumber = 1e9 # Number of spikes
backgroundnoise = 1 # Fractional noise
backgroundweight = 4.0*array([1,0.1]) # Weight for background input for E cells and I cells
backgroundreceptor = NMDA # Which receptor to stimulate


## Stimulus parameters
usestims = True # Whether or not to use stimuli at all
optoreceptor = opsin # Set which receptor to stimulate
optoisi = 100 # Interstimulus interval
optovar = 0.0 # Variation in ISI
optowidth = 0.2 # Stimulus width in s
optoweight = 10 # Weight of stimuli
optosta = 3 # Starting time in s
optofin = 6 # Finishing time in s
optoshape = 'square' # Shape of stimulus
stimpops = {'opto':[ER5, EB5, ER6]}
stimfraction = {'opto':0.4} # No idea what this should be...
stimrate = {'opto':500} # 500 is the highest rate that can be used without significantly slowing down the simulation
stimnoise = {'opto':0}
stimloc = {'opto':modelsize*array([[0.0,1.0],[0.0,1.0]])} # Location of cells to be stimulated
stimfalloff = {'opto': [array([0.5,0.5]), 2000]} # Weight fall-off characteristics of the stimulus: center and Gaussian width in um



###############################################################################
### MORE HOUSEKEEPING
###############################################################################

## Check for input arguments
for arg in argv[1:]: # Skip first argument, which is file name
    varname = arg.split('=') # Separate out variable name
    if len(varname)==2: # Make sure it split properly, but if not, assume it's something else (e.g. a NEURON argument) and fail silently
        if varname[0] in locals(): # Check that variable exists
            exec(arg) # Actually set variable            
            if pc.id()==0: print('  Setting %s' % arg)
        else: raise Exception('Variable "%s" not found' % varname[0])

## Limit memory
if limitmemory:
    import resource, os
    freemem = 0.95*float(os.popen("free -b").readlines()[1].split()[3]) # Get free memory, set maximum to 75%
    resource.setrlimit(resource.RLIMIT_AS, (freemem, freemem)) # Limit memory usage
    if pc.id()==0: print('  Note: RAM limited to %0.2f GB' % (freemem/1e9))
    
## Peform a mini-benchmarking test for future time estimates
if pc.id()==0:
	print('Benchmarking...')
	benchstart = time()
	for i in range(int(1.36e6)): tmp=0 # Number selected to take 0.1 s on my machine
	performance = 1/(10*(time() - benchstart))*100
	print('  Running at %0.0f%% default speed (%0.0f%% total)' % (performance, performance*nhosts))
 
 

###############################################################################
### CREATE MODEL
###############################################################################

ncells, popnumbers, cellpops, cellnames, cellclasses, EorI = cpd.cellproperties(scale) # Get basic data about the population
if pc.id()==0: print("\nCreating simulation of %i cells for %0.1f s on %i hosts..." % (sum(popnumbers),duration/1000.,nhosts)) # Print diagnostic information
pc.barrier()


## Preliminaries
cells=[] # Create empty list for storing cells
dummies=[] # Create empty list for storing fake sections
gidvec=[] # Empty list for storing GIDs
if ncells % nhosts == 0: cellsperhost=ncells//nhosts # Calculate how many cells there will be on each host
else: raise Exception('Cells must be evenly divisble by hosts, sorry (# cells=%i, # hosts=%i)' % (ncells, nhosts))


## Set cell types
celltypes=[]
for c in range(ncells): # Loop over each cell
    if cellclasses[c]==1: celltypes.append(pyramidal) # Append a pyramidal cell
    elif cellclasses[c]==2: celltypes.append(fastspiking) # Append a fast-spiking interneuron
    elif cellclasses[c]==3: celltypes.append(lowthreshold) # Append a low-threshold-spiking interneuron
    elif cellclasses[c]==4: celltypes.append(thalamocortical) # Append a thalamocortical cell
    elif cellclasses[c]==5: celltypes.append(reticular) # Append a thalamocortical cell
    else: raise Exception('Undefined cell class "%s"' % cellclasses[c]) # No match? Cause an error


## Set positions
cortthaldist=3000 # CK: WARNING, KLUDGY -- Distance from relay nucleus to cortex -- ~1 cm = 10,000 um
zlayerpositions = [1740+cortthaldist, (1740+1130)/2+cortthaldist, 1130+cortthaldist, 488+cortthaldist, 300, 0] # Can't remember where I got these distances from...
verticalextent = 100 # Vertical spread in um
seed(randseed) # Reset random number generator
xlocs = modelsize*rand(ncells) # Create random x locations
ylocs = modelsize*rand(ncells) # Create random y locations
zlocs = verticalextent*rand(ncells) # Create random z locations
for c in range(ncells):
    if cellnames[c][-1]=='2': zlocs[c]+=zlayerpositions[0] # Layer 2/3 cell
    elif cellnames[c][-1]=='4': zlocs[c]+=zlayerpositions[1] # Layer 4 cell
    elif cellnames[c][-1]=='5': zlocs[c]+=zlayerpositions[2] # Layer 5 cell
    elif cellnames[c][-1]=='6': zlocs[c]+=zlayerpositions[3] # Layer 6 cell
    elif cellnames[c]=='TRN': zlocs[c]+=zlayerpositions[4] # Thalamic reticular nucleus cell
    elif cellnames[c]=='TCR': zlocs[c]+=zlayerpositions[5] # Thalamocortical relay nucleus cell
    else: raise Exception('Undefined cell name "%s"' % cellnames[c]) # No match? Cause an error


## Actually create the cells
spikerecorders = [] # Empty list for storing spike-recording Netcons
hostspikevecs = [] # Empty list for storing host-specific spike vectors
for c in range(cellsperhost):
   gid=cellsperhost*int(pc.id())+c # Increment global identifier       
   dummies.append(h.Section()) # Create fake sections
   if cellclasses[gid]==3: cells.append(fastspiking(dummies[c], vt=-47, cellid=gid)) # Don't use LTS cell, but instead a FS cell with a low threshold
   else: cells.append(celltypes[gid](dummies[c], cellid=gid)) # Create a new cell of the appropriate type (celltypes[gid]) and store it
   if verbosity>0: cells[-1].useverbose(verbosity, filename+'log.txt') # Turn on diagnostic to file
   gidvec.append(gid)
   pc.set_gid2node(gid,pc.id())
   
   spikevec = h.Vector()
   hostspikevecs.append(spikevec)
   spikerecorder = h.NetCon(cells[c], None)
   spikerecorder.record(spikevec)
   spikerecorders.append(spikerecorder)
   pc.cell(gid,spikerecorders[c])
print('  Number of cells on node %i: %i' % (pc.id(),len(cells)))
pc.barrier()


## Calculate distances and probabilities
if pc.id()==0: print('Calculating connection probabilities (est. time: %i s)...' % (performance*cellsperhost**2/3e6))
conncalcstart = time() # See how long connecting the cells takes
nconnpars = 5 # Connection parameters: pre- and post- cell ID, weight, distances, delays
conndata = [[] for i in range(nconnpars)] # List for storing connections
for c in range(cellsperhost): # Loop over all postsynaptic cells on this host (has to be postsynaptic because of gid_connect)
    gid = cellsperhost*int(pc.id())+c # Post-synaptic GID
    if toroidal: 
        xpath=(abs(xlocs-xlocs[gid]))**2
        xpath2=(modelsize-abs(xlocs-xlocs[gid]))**2
        xpath[xpath2<xpath]=xpath2[xpath2<xpath]
        ypath=(abs(ylocs-ylocs[gid]))**2
        ypath2=(modelsize-abs(ylocs-ylocs[gid]))**2
        ypath[ypath2<ypath]=ypath2[ypath2<ypath]
        distances = sqrt(xpath + ypath) # Calculate all pairwise distances
    else: distances = sqrt((xlocs-xlocs[gid])**2 + (ylocs-ylocs[gid])**2) # Calculate all pairwise distances
    allconnprobs = scaleconnprob[EorI,EorI[gid]] * connprobs[cellpops,cellpops[gid]] * exp(-distances/connfalloff[EorI]) # Calculate pairwise probabilities
    allconnprobs[gid] = 0 # Prohibit self-connections using the cell's GID
    seed(randseed+gid) # Reset random number generator  
    allrands = rand(ncells) # Create an array of random numbers for checking each connection    
    makethisconnection = allconnprobs>allrands # Perform test to see whether or not this connection should be made
    preids = array(makethisconnection.nonzero()[0],dtype='int') # Return True elements of that array for presynaptic cell IDs
    postids = array(gid+zeros(len(preids)),dtype='int') # Post-synaptic cell IDs
    conndata[0].append(preids) # Append pre-cell ID
    conndata[1].append(postids) # Append post-cell ID
    conndata[2].append(distances[preids]) # Distances
    conndata[3].append(mindelay + distances[preids]/float(velocity)) # Calculate the delays
    wt1 = scaleconnweight[EorI[preids],EorI[postids]] # N weight scale factors -- WARNING, might be flipped
    wt2 = connweights[cellpops[preids],cellpops[postids],:] # NxM inter-population weights
    wt3 = receptorweight[:] # M receptor weights
    finalweights = transpose(wt1*transpose(wt2*wt3)) # Multiply out population weights with receptor weights to get NxM matrix
    conndata[4].append(finalweights) # Initialize weights to 0, otherwise get memory leaks
for pp in range(nconnpars): conndata[pp] = array(concatenate([conndata[pp][c] for c in range(cellsperhost)])) # Turn pre- and post- cell IDs lists into vectors
nconnections = len(conndata[0]) # Find out how many connections we're going to make
conncalctime = time()-conncalcstart # See how long it took
if pc.id()==0: print('  Done; time = %0.1f s' % conncalctime)


## Actually make connections
if pc.id()==0: print('Making connections (est. time: %i s)...' % (performance*nconnections/9e4))
print('  Number of connections on host %i: %i' % (pc.id(), nconnections))
connstart = time() # See how long connecting the cells takes
connlist = [] # Create array for storing each of the connections
stdpconndata = [] # Store data on STDP connections
if usestdp: # STDP enabled?
    stdpmechs = [] # Initialize array for STDP mechanisms
    precons = [] # Initialize array for presynaptic spike counters
    pstcons = [] # Initialize array for postsynaptic spike counters
for con in range(nconnections): # Loop over each connection
    pregid = conndata[0][con] # GID of presynaptic cell    
    pstgid = conndata[1][con] # Index of postsynaptic cell
    pstid = pstgid % cellsperhost # Index of postynaptic cell -- convert from GID to local
    newcon = pc.gid_connect(pregid, cells[pstid]) # Create a connection
    newcon.delay = conndata[3][con] # Set delay
    for r in range(cpd.nreceptors): newcon.weight[r] = conndata[4][con][r] # Set weight of connection
    connlist.append(newcon) # Connect the two cells
    if usestdp: # Using STDP?
        if sum(abs(stdprates[EorI[pregid],:]))>0: # Don't create an STDP connection if the learning rates are zero
            for r in range(cpd.nreceptors): # Need a different STDP instances for each receptor
                if newcon.weight[r]>0: # Only make them for nonzero connections
                    stdpmech = h.STDP(0,sec=dummies[pstid]) # Create STDP adjuster
                    stdpmech.potrate = stdprates[EorI[pregid],0] # Potentiation rate
                    stdpmech.deprate = stdprates[EorI[pregid],1] # Depression rate
                    stdpmech.wmax = maxweight # Maximum synaptic weight
                    precon = pc.gid_connect(pregid,stdpmech); precon.weight[0] = 1 # Send presynaptic spikes to the STDP adjuster
                    pstcon = pc.gid_connect(pstgid,stdpmech); pstcon.weight[0] = -1 # Send postsynaptic spikes to the STDP adjuster
                    h.setpointer(connlist[-1]._ref_weight[r],'synweight',stdpmech) # Associate the STDP adjuster with this weight
                    stdpmechs.append(stdpmech) # Save STDP adjuster
                    precons.append(precon) # Save presynaptic spike source
                    pstcons.append(pstcon) # Save postsynaptic spike source
                    stdpconndata.append([pregid,pstgid,r]) # Store presynaptic cell ID, postsynaptic, and receptor
nstdpconns = len(stdpconndata) # Get number of STDP connections
conntime = time()-connstart # See how long it took
if usestdp: print('  Number of STDP connections on host %i: %i' % (pc.id(), nstdpconns))
if pc.id()==0: print('  Done; time = %0.1f s' % conntime)
pc.barrier()





###############################################################################
### CREATE INPUTS
###############################################################################


## Define stimulus-making code
def makestim(isi=1, variation=0, width=0.05, weight=10, start=0, finish=1, stimshape='gaussian'):
    from pylab import r_, convolve, shape
    
    # Create event times
    timeres = 0.005 # Time resolution = 5 ms = 200 Hz
    pulselength = 10 # Length of pulse in units of width
    currenttime = 0
    timewindow = finish-start
    allpts = timewindow/timeres
    output = []
    while currenttime<timewindow:
        if currenttime>=0 and currenttime<timewindow: output.append(currenttime)
        currenttime = currenttime+isi+variation*(rand()-0.5)
    
    # Create single pulse
    npts = min(pulselength*width/timeres,allpts) # Calculate the number of points to use
    x = (r_[0:npts]-npts/2+1)*timeres
    if stimshape=='gaussian': 
        pulse = exp(-(x/width*2-2)**2) # Offset by 2 standard deviations from start
        pulse = pulse/max(pulse)
    elif stimshape=='square': 
        pulse = zeros(shape(x))
        pulse[int(npts/2):int(npts/2)+int(width/timeres)] = 1 # Start exactly on time
    else:
        raise Exception('Stimulus shape "%s" not recognized' % stimshape)
    
    # Create full stimulus
    events = zeros((allpts))
    events[array(array(output)/timeres,dtype=int)+1] = 1
    fulloutput = convolve(events,pulse,mode='same')*weight # Calculate the convolved input signal, scaled by rate
    fulltime = r_[int(start/timeres):int(finish/timeres)]*timeres*1e3 # Create time vector and convert to ms
    fulltime = hstack((0,fulltime,fulltime[-1]+timeres*1e3)) # Create "bookends" so always starts and finishes at zero
    fulloutput = hstack((0,fulloutput,0)) # Set weight to zero at either end of the stimulus period
    events = hstack((0,events,0)) # Ditto
    stimvecs = [fulltime, fulloutput, events] # Combine vectors into a matrix
    
    return stimvecs


## OPTOGENETIC STIMULATION
stimstruct = []
if usestims:
    stimstruct.append(['opto',    makestim(optoisi, optovar, optowidth, optoweight, optosta, optofin, optoshape)])
    stimrands=[] # Create input connections
    stimsources=[] # Create empty list for storing synapses
    stimconns=[] # Create input connections
    stimtimevecs = [] # Create array for storing time vectors
    stimweightvecs = [] # Create array for holding weight vectors
    if saveraw: 
        stimspikevecs=[] # A list for storing actual cell voltages (WARNING, slow!)
        stimrecorders=[] # And for recording spikes
    for stim in range(len(stimstruct)): # Loop over each stimulus type
        stimtype = stimstruct[stim][0] # Natural or microstim or opto
        stimvecs = stimstruct[stim][1] # Time-probability vectors
        stimtimevecs.append(h.Vector().from_python(stimvecs[0]))
        
        for c in range(cellsperhost):
            gid = cellsperhost*int(pc.id())+c # For deciding E or I    
            seed(randseed+gid) # Reset random number generator for this cell
            if stimfraction[stimtype]>rand(): # Don't do it for every cell necessarily
                if any(cellpops[gid]==stimpops[stimtype]) and xlocs[gid]>=stimloc[stimtype][0,0] and xlocs[gid]<=stimloc[stimtype][0,1] and ylocs[gid]>=stimloc[stimtype][1,0] and ylocs[gid]<=stimloc[stimtype][1,1]:
                    
                    maxweightincrease = 20 # Otherwise could get infinitely high, infinitely close to the stimulus
                    distancefromstimulus = sqrt(sum((array([xlocs[gid], ylocs[gid]])-modelsize*stimfalloff['opto'][0])**2))
                    fallofffactor = min(maxweightincrease,(stimfalloff['opto'][1]/distancefromstimulus)**2)
                    stimweightvecs.append(h.Vector().from_python(stimvecs[1]*fallofffactor)) # Scale by the fall-off factor
                    
                    stimrand = h.Random()
                    stimrand.MCellRan4(randseed+gid,randseed+gid+1e6) # If everything has the same seed, should happen at the same time
                    stimrand.negexp(1)
                    stimrands.append(stimrand)
                    
                    stimsource = h.NetStim() # Create a NetStim
                    stimsource.interval = stimrate[stimtype]**-1*1e3 # Interval between spikes
                    stimsource.number = 1e9 # Number of spikes
                    stimsource.noise = stimnoise[stimtype] # Fractional noise in timing
                    stimsource.noiseFromRandom(stimrand) # Set it to use this random number generator
                    stimsources.append(stimsource) # Save this NetStim
                    
                    stimconn = h.NetCon(stimsource, cells[c]) # Connect this noisy input to a cell
                    for r in range(cpd.nreceptors): stimconn.weight[r]=0 # Initialize weights to 0, otherwise get memory leaks
                    stimweightvecs[-1].play(stimconn._ref_weight[0], stimtimevecs[-1]) # Play most-recently-added vectors into weight
                    stimconn.delay=2 # Specify the delay in ms -- shouldn't make a spot of difference
                    stimconns.append(stimconn) # Save this connnection
    
                    if saveraw:
                        stimspikevec = h.Vector() # Initialize vector
                        stimspikevecs.append(stimspikevec) # Keep all those vectors
                        stimrecorder = h.NetCon(stimsource, None)
                        stimrecorder.record(stimspikevec) # Record simulation time
                        stimrecorders.append(stimrecorder)
    print('  Number of stimuli created on host %i: %i' % (pc.id(), len(stimsources)))


## Add background inputs
if usebackground:
    if pc.id()==0: print('Creating background inputs...')
    backgroundsources=[] # Create empty list for storing synapses
    backgroundrands=[] # Create random number generators
    backgroundconns=[] # Create input connections
    if saveraw:
        backgroundspikevecs=[] # A list for storing actual cell voltages (WARNING, slow!)
        backgroundrecorders=[] # And for recording spikes
    for c in range(cellsperhost): 
        gid = cellsperhost*int(pc.id())+c # For deciding E or I
        backgroundrand = h.Random()
        backgroundrand.MCellRan4(gid,gid*2)
        backgroundrand.negexp(1)
        backgroundrands.append(backgroundrand)
        
        backgroundsource = h.NetStim() # Create a NetStim
        backgroundsource.interval = backgroundrate**-1*1e3 # Take inverse of the frequency and then convert from Hz^-1 to ms
        backgroundsource.number = backgroundnumber # Number of spikes
        backgroundsource.noise = backgroundnoise # Fractional noise in timing
        backgroundsource.noiseFromRandom(backgroundrand) # Set it to use this random number generator
        backgroundsources.append(backgroundsource) # Save this NetStim
        
        backgroundconn = h.NetCon(backgroundsource, cells[c]) # Connect this noisy input to a cell
        for r in range(cpd.nreceptors): backgroundconn.weight[r]=0 # Initialize weights to 0, otherwise get memory leaks
        backgroundconn.weight[backgroundreceptor] = backgroundweight[EorI[gid]] # Specify the weight -- 1 is NMDA receptor for smoother, more summative activation
        backgroundconn.delay=2 # Specify the delay in ms -- shouldn't make a spot of difference
        backgroundconns.append(backgroundconn) # Save this connnection
        
        if saveraw:
            backgroundspikevec = h.Vector() # Initialize vector
            backgroundspikevecs.append(backgroundspikevec) # Keep all those vectors
            backgroundrecorder = h.NetCon(backgroundsource, None)
            backgroundrecorder.record(backgroundspikevec) # Record simulation time
            backgroundrecorders.append(backgroundrecorder)
    print('  Number created on host %i: %i' % (pc.id(), len(backgroundsources)))

pc.barrier()




###############################################################################
### RUN SIMULATION
###############################################################################


## Initialize STDP -- just for recording
weightchanges = []
if usestdp:
    if pc.id()==0: print('\nSetting up STDP...')
    weightchanges = [[] for ps in range(nstdpconns)] # Create an empty list for each STDP connection -- warning, slow with large numbers of connections!
    for ps in range(nstdpconns): weightchanges[ps].append([0, stdpmechs[ps].synweight]) # Time of save (0=initial) and the weight


## Set up LFP recording
lfptime = [] # List of times that the LFP was recorded at
nlfps = len(lfppops) # Number of distinct LFPs to calculate
hostlfps = [] # Voltages for calculating LFP
lfpcellids = [[] for p in range(nlfps)] # Create list of lists of cell IDs
for c in range(cellsperhost): # Loop over each cell and decide which LFP population, if any, it belongs to
    gid = cellsperhost*int(pc.id())+c # Get this cell's GID
    for p in range(nlfps): # Loop over each LFP population
        thispop = cellpops[gid] # Population of this cell
        if sum(lfppops[p]==thispop)>0: # There's a match
            lfpcellids[p].append(c) # Flag this cell as belonging to this LFP population


## Set up raw recording
rawrecordings = [] # A list for storing actual cell voltages (WARNING, slow!)
if saveraw: 
    if pc.id()==0: print('\nSetting up raw recording...')
    nquantities = 4 # Number of variables from each cell to record from
    for c in range(cellsperhost):
        recvecs = [h.Vector() for q in range(nquantities)] # Initialize vectors
        recvecs[0].record(h._ref_t) # Record simulation time
        recvecs[1].record(cells[c]._ref_V) # Record cell voltage
        recvecs[2].record(cells[c]._ref_u) # Record cell recovery variable
        recvecs[3].record(cells[c]._ref_I) # Record cell current
        rawrecordings.append(recvecs) # Keep all those vectors


## "Actually" run
if pc.id()==0: print('\nRunning...')
runstart = time() # See how long the run takes
pc.set_maxstep(10) # MPI: Set the maximum integration time in ms -- not very important
init() # Initialize the simulation
while h.t<duration:
    pc.psolve(min(duration,h.t+loopstep)) # MPI: Get ready to run the simulation (it isn't actually run until pc.runworker() is called I think)
    if pc.id()==0 and (h.t % progupdate)==0: print('  t = %0.1f s (%i%%; time remaining: %0.1f s)' % (h.t/1e3, int(h.t/duration*100), (duration-h.t)*(time()-runstart)/h.t))
    
    # Calculate LFP -- WARNING, need to think about how to optimize
    if savelfps:
        lfptime.append(h.t) # Append current time
        tmplfps = zeros((nlfps)) # Create empty array for storing LFP voltages
        for p in range(nlfps):
            for c in range(len(lfpcellids[p])):
                tmplfps[p] += cells[lfpcellids[p][c]].V # Add voltage to LFP estimate
        hostlfps.append(tmplfps) # Add voltages
    
    # Periodic weight saves
    if usestdp: 
        timesincelastsave = h.t - timeoflastsave
        if timesincelastsave>=timebetweensaves:
            timeoflastsave = h.t
            for ps in range(nstdpconns):
                if stdpmechs[ps].synweight != weightchanges[ps][-1][-1]: # Only store connections that changed; [ps] = this connection; [-1] = last entry; [-1] = weight
                    weightchanges[ps].append([timeoflastsave, stdpmechs[ps].synweight])

runtime = time()-runstart # See how long it took
if pc.id()==0: print('  Done; run time = %0.1f s; real-time ratio: %0.2f.' % (runtime, duration/1000/runtime))
pc.barrier() # Wait for all hosts to get to this point


## Pack data from all hosts
if pc.id()==0: print('\nGathering spikes...')
gatherstart = time() # See how long it takes to plot
for host in range(nhosts): # Loop over hosts
    if host==pc.id(): # Only act on a single host
        hostspikecells=array([])
        hostspiketimes=array([])
        for c in range(len(hostspikevecs)):
            thesespikes = array(hostspikevecs[c]) # Convert spike times to an array
            nthesespikes = len(thesespikes) # Find out how many of spikes there were for this cell
            hostspiketimes = concatenate((hostspiketimes, thesespikes)) # Add spikes from this cell to the list
            hostspikecells = concatenate((hostspikecells, (c+host*cellsperhost)*ones(nthesespikes))) # Add this cell's ID to the list
            if saveraw:
                for q in range(nquantities):
                    rawrecordings[c][q] = array(rawrecordings[c][q])
        messageid=pc.pack([hostspiketimes, hostspikecells, hostlfps, conndata, stdpconndata, weightchanges, rawrecordings]) # Create a mesage ID and store this value
        pc.post(host,messageid) # Post this message


## Unpack data from all hosts
if pc.id()==0: # Only act on a single host
    allspikecells = array([])
    allspiketimes = array([])
    lfps = zeros((len(lfptime),nlfps)) # Create an empty array for appending LFP data; first entry is for time
    allconnections = [array([]) for i in range(nconnpars)] # Store all connections
    allconnections[nconnpars-1] = zeros((0,cpd.nreceptors)) # Create an empty array for appending connections
    allstdpconndata = zeros((0,3)) # Create an empty array for appending STDP connection data
    if usestdp: weightchanges = []
    if saveraw: allraw = []
    for host in range(nhosts): # Loop over hosts
        pc.take(host) # Get the last message
        hostdata = pc.upkpyobj() # Unpack them
        allspiketimes = concatenate((allspiketimes, hostdata[0])) # Add spikes from this cell to the list
        allspikecells = concatenate((allspikecells, hostdata[1])) # Add this cell's ID to the list
        if savelfps: lfps += array(hostdata[2]) # Sum LFP voltages
        for pp in range(nconnpars): allconnections[pp] = concatenate((allconnections[pp], hostdata[3][pp])) # Append pre/post synapses
        if usestdp and len(hostdata[4]): # Using STDP and at least one STDP connection
            allstdpconndata = concatenate((allstdpconndata, hostdata[4])) # Add data on STDP connections
            for ps in range(len(hostdata[4])): weightchanges.append(hostdata[5][ps]) # "ps" stands for "plastic synapse"
        if saveraw:
            for c in range(len(hostdata[6])): allraw.append(hostdata[6][c]) # Append cell-by-cell
    totalspikes = len(allspiketimes) # Keep a running tally of the number of spikes
    totalconnections = len(allconnections[0]) # Total number of connections
    totalstdpconns = len(allstdpconndata) # Total number of STDP connections
    
    # Record input spike times
    if saveraw and usebackground:
        allbackgroundspikecells=array([])
        allbackgroundspiketimes=array([])
        for c in range(len(backgroundspikevecs)):
            thesespikes = array(backgroundspikevecs[c])
            allbackgroundspiketimes = concatenate((allbackgroundspiketimes, thesespikes)) # Add spikes from this stimulator to the list
            allbackgroundspikecells = concatenate((allbackgroundspikecells, c+zeros(len(thesespikes)))) # Add this cell's ID to the list
        backgrounddata = transpose(vstack([allbackgroundspikecells,allbackgroundspiketimes]))
    else: backgrounddata = [] # For saving s no error
    
    if saveraw and usestims:
        allstimspikecells=array([])
        allstimspiketimes=array([])
        for c in range(len(stimspikevecs)):
            thesespikes = array(stimspikevecs[c])
            allstimspiketimes = concatenate((allstimspiketimes, thesespikes)) # Add spikes from this stimulator to the list
            allstimspikecells = concatenate((allstimspikecells, c+zeros(len(thesespikes)))) # Add this cell's ID to the list
        stimspikedata = transpose(vstack([allstimspikecells,allstimspiketimes]))
    else: stimspikedata = [] # For saving so no error
gathertime = time()-gatherstart # See how long it took
if pc.id()==0: print('  Done; gather time = %0.1f s.' % gathertime)
pc.barrier()


## Run and clean up
pc.runworker() # MPI: Start simulations running on each host
pc.done() # MPI: Close MPI






###############################################################################
### ANALYSIS
###############################################################################


## Analyzing
print('\nAnalyzing...')
firingrate = float(totalspikes)/ncells/duration*1e3 # Calculate firing rate -- confusing but cool Python trick for iterating over a list
connspercell = totalconnections/float(ncells) # Calculate the number of connections per cell
print('  Spikes: %i (%0.2f Hz)' % (totalspikes, firingrate))
print('  Connections: %i (%i STDP; %0.2f per cell)' % (totalconnections, totalstdpconns, connspercell))
print('  Mean connection distance: %0.2f um' % mean(allconnections[2]))
print('  Mean connection delay: %0.2f ms' % mean(allconnections[3]))


## Saving
if dosave:
    print('Saving output as %s...' % filename)
    savestart = time() # See how long it takes to save
    from scipy.io import savemat # analysis:ignore -- because used in exec() statement
    
    # Save simulation code
    filestosave = ['model.py','cellpopdata.py', 'izhi.py', 'izhi.mod', 'stdp.mod'] # Files to save
    simcode = [argv, filestosave] # Start off with input parameters, if any, and then the list of files being saved
    for f in range(len(filestosave)): # Loop over each file
        fobj = open(filestosave[f]) # Open it for reading
        simcode.append(fobj.readlines()) # Append to list of code to save
        fobj.close() # Close file object
    
    # Tidy variables
    spikedata = vstack([allspikecells,allspiketimes]).T # Put spike data together
    connections = vstack([allconnections[0],allconnections[1]]).T # Put connection data together
    distances = allconnections[2] # Pull out distances
    delays = allconnections[3] # Pull out delays
    stimdata = [vstack(stimstruct[c][1]).T for c in range(len(stimstruct))] # Only pull out vectors, not text, in stimdata
    weights = allconnections[4] # Pull out weights
    stdpdata = allstdpconndata # STDP connection data
    
    # Save variables
    info = {'timestamp':datetime.today().strftime("%d %b %Y %H:%M:%S"), 'runtime':runtime, 'arguments':argv[:], 'popnames':cpd.popnames, 'popEorI':cpd.popEorI} # Save date, runtime, and input arguments
    variablestosave = ['info', 'simcode', 'spikedata', 'cellpops', 'cellnames', 'cellclasses', 'xlocs', 'ylocs', 'zlocs', 'connections', 'distances', 'delays', 'weights', 'EorI', 'stimdata']
    if savelfps:  variablestosave.extend(['lfptime', 'lfps'])   
    if usestdp: variablestosave.extend(['stdpdata', 'weightchanges'])
    if saveraw: variablestosave.extend(['backgrounddata', 'stimspikedata', 'allraw'])
    savecommand = "savemat(filename, {"
    for var in range(len(variablestosave)): savecommand += "'" + variablestosave[var] + "':" + variablestosave[var] + ", " # Create command out of all the variables
    savecommand = savecommand[:-2] + "}, oned_as='column')" # Omit final comma-space and complete command
    exec(savecommand) # Actually perform the save
    
    savetime = time()-savestart # See how long it took to save
    print('  Done; time = %0.1f s' % savetime)


## Plotting
if doplot: # Whether or not to plot
    print('Plotting...')
    def raster(): # Define a function for plotting a raster
        plotstart = time() # See how long it takes to plot
        EorIcolors = array([(1,0.4,0) , (0,0.2,0.8)]) # Define excitatory and inhibitory colors -- orange and turquoise
        cellcolors = EorIcolors[array(EorI)[array(allspikecells,dtype=int)]] # Set each cell to be either orange or turquoise
        figure() # Open a new figure
        scatter(allspiketimes,allspikecells,10,cellcolors,linewidths=0.5,marker='|') # Create raster  
        xlabel('Time (ms)')
        ylabel('Cell ID')
        title('cells=%i syns/cell=%0.1f noise=%0.1f rate=%0.1f Hz' % (ncells,connspercell,backgroundweight[0],firingrate),fontsize=12)
        xlim(0,duration)
        ylim(0,ncells)
        plottime = time()-plotstart # See how long it took
        print('  Done; time = %0.1f s' % plottime)
        show()
    if (totalspikes>maxspikestoplot): disp('  Too many spikes (%i vs. %i)' % (totalspikes, maxspikestoplot)) # Plot raster, but only if not too many spikes
    elif nhosts>1: disp('  Too many cores (%i)' % nhosts) # Plot raster, but only if not too many spikes
    else: raster() 

## Wrapping up
totaltime = time()-verystart # See how long it took in total
print('\nDone; total time = %0.1f s.' % totaltime)
if nhosts>1 or doplot==False: h.quit() # Quit extra processes, or everything if plotting wasn't requested (since assume non-interactive)