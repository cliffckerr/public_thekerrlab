"""
CELLPOPDATA

This program returns the data on cell numbers, names, connection probability
matrix and the connection weight matrix. It's based on conndiagram.py in the
NEST paper repository, and modified to reflect Ashutosh's network.hoc for the 
M1 model.

Version: 2014jan09 by cliffk
"""

from pylab import array, zeros, sum

# Set population quantities
popnames = ['ER2', 'IF2', 'IL2', 'ER5', 'EB5', 'IF5', 'IL5', 'ER6', 'IF6', 'IL6']
popclasses =   [1,     2,     3,     1,     1,     2,     3,     1,     2,     3] # Izhikevich population type
popEorI =      [0,     1,     1,     0,     0,     1,     1,     0,     1,     1] # Whether it's excitatory or inhibitory
popratios =  [150,    25,    25,   167,    72,    40,    40,   192,    32,    32] # Cell population numbers 
receptornames = ['AMPA', 'NMDA', 'GABAA', 'GABAB', 'opsin'] # Names of the different receptors
npops = len(popnames) # Number of populations
nreceptors = len(receptornames) # Number of receptors


# Convert poptypes and EorI into vectors for each cell
def cellproperties(scale=1):
    cellpops = [] # Store list of populations for each cell -- e.g. ER2 vs. IF2
    cellnames = [] # Store list of classes types for each cell -- e.g. pyramidal vs. interneuron
    cellclasses = [] # Store list of classes types for each cell -- e.g. pyramidal vs. interneuron
    EorI = [] # Store list of excitatory/inhibitory for each cell
    popnumbers = scale*array(popratios) # Number of neurons in each population
    ncells = int(sum(popnumbers)) # Calculate the total number of cells
    for p in range(npops): # Loop over each population
        for c in range(int(popnumbers[p])): # Loop over each cell in that population
            cellpops.append(p) # Append this cell's population type to the list
            cellnames.append(popnames[p]) # Append this cell's population type to the list
            cellclasses.append(popclasses[p]) # Just use integers to index them
            EorI.append(popEorI[p]) # Append this cell's excitatory/inhibitory state to the list
    return ncells, popnumbers, array(cellpops), cellnames, array(cellclasses), array(EorI)


# Assign numbers to each of the different variables so they can be used in the other functions
def names2inds():
    for i,name in enumerate(popnames): exec(name+'=i') # Set population names to the integers
    for i,name in enumerate(receptornames): exec(name+'=i') # Set population names to the integers
    allpops = array(range(npops)) # Create an array with all the population numbers
    Epops = allpops[array(popEorI)==0] # Pick out numbers corresponding to excitatory populations
    Ipops = allpops[array(popEorI)==1] # Pick out numbers corresponding to inhibitory populations
    return ER2, IF2, IL2, ER5, EB5, IF5, IL5, ER6, IF6, IL6, AMPA, NMDA, GABAA, GABAB, opsin, Epops, Ipops, allpops # analysis:ignore (from exec statements)
ER2, IF2, IL2, ER5, EB5, IF5, IL5, ER6, IF6, IL6, AMPA, NMDA, GABAA, GABAB, opsin, Epops, Ipops, allpops = names2inds() # And call it, so it's accessible to the other functions


# Define connectivity matrix (copied out of network.hoc; correct as of 11mar26)
def setconnprobs():
    connprobs=zeros((npops,npops))
    connprobs[ER2,ER2]=0.2 # weak by wiring matrix in (Weiler et al., 2008)
    connprobs[ER2,EB5]=0.8*2 # strong by wiring matrix in (Weiler et al., 2008)
    connprobs[ER2,ER5]=0.8*2 # strong by wiring matrix in (Weiler et al., 2008)
    connprobs[ER2,IL5]=0.51 # L2/3 E -> L5 LTS I (justified by (Apicella et al., 2012)
    connprobs[ER2,ER6]=0 # none by wiring matrix in (Weiler et al., 2008)
    connprobs[ER2,IL2]=0.51
    connprobs[ER2,IF2]=0.43
    connprobs[EB5,ER2]=0 # none by wiring matrix in (Weiler et al., 2008)
    connprobs[EB5,EB5]=0.04 * 4 # set using (Kiritani et al., 2012) Fig. 6D, Table 1, value x 4 
    connprobs[EB5,ER5]=0 # set using (Kiritani et al., 2012) Fig. 6D, Table 1 
    connprobs[EB5,ER6]=0 # none by suggestion of Ben and Gordon over phone
    connprobs[EB5,IL5]=0 # ruled out by (Apicella et al., 2012) Fig. 7
    connprobs[EB5,IF5]=0.43 # CK: was 0.43 but perhaps the cause of the blow-up?
    connprobs[ER5,ER2]=0.2 # weak by wiring matrix in (Weiler et al., 2008)
    connprobs[ER5,EB5]=0.21 * 4 # set using (Kiritani et al., 2012) Fig. 6D, Table 1, value x 4
    connprobs[ER5,ER5]=0.11 * 4 # set using (Kiritani et al., 2012) Fig. 6D, Table 1, value x 4 
    connprobs[ER5,ER6]=0.2 # weak by wiring matrix in (Weiler et al., 2008)
    connprobs[ER5,IL5]=0 # ruled out by (Apicella et al., 2012) Fig. 7
    connprobs[ER5,IF5]=0.43
    connprobs[ER6,ER2]=0 # none by wiring matrix in (Weiler et al., 2008)
    connprobs[ER6,EB5]=0.2 # weak by wiring matrix in (Weiler et al., 2008)
    connprobs[ER6,ER5]=0.2 # weak by wiring matrix in (Weiler et al., 2008)
    connprobs[ER6,ER6]=0.2 # weak by wiring matrix in (Weiler et al., 2008)
    connprobs[ER6,IL6]=0.51
    connprobs[ER6,IF6]=0.43
    connprobs[IL2,ER2]=0.35
    connprobs[IL2,IL2]=0.09
    connprobs[IL2,IF2]=0.53
    connprobs[IF2,ER2]=0.44
    connprobs[IF2,IL2]=0.34
    connprobs[IF2,IF2]=0.62
    connprobs[IL5,EB5]=0.35
    connprobs[IL5,ER5]=0.35
    connprobs[IL5,IL5]=0.09
    connprobs[IL5,IF5]=0.53
    connprobs[IF5,EB5]=0.44
    connprobs[IF5,ER5]=0.44
    connprobs[IF5,IL5]=0.34
    connprobs[IF5,IF5]=0.62
    connprobs[IL6,ER6]=0.35
    connprobs[IL6,IL6]=0.09
    connprobs[IL6,IF6]=0.53
    connprobs[IF6,ER6]=0.44
    connprobs[IF6,IL6]=0.34
    connprobs[IF6,IF6]=0.62
    return connprobs

# Define weights (copied out of network.hoc on 11mar27)
def setconnweights():
    connweights=zeros((npops,npops,nreceptors))
    connweights[ER2,ER2,AMPA]=0.66
    connweights[ER2,EB5,AMPA]=0.36
    connweights[ER2,ER5,AMPA]=0.93
    connweights[ER2,IL5,AMPA]=0.36
    connweights[ER2,ER6,AMPA]=0
    connweights[ER2,IL2,AMPA]=0.23
    connweights[ER2,IF2,AMPA] = 0.23
    connweights[EB5,ER2,AMPA]=0# ruled out based on Ben and Gordon conversation
    connweights[EB5,EB5,AMPA]=0.66
    connweights[EB5,ER5,AMPA]=0 # pulled from Fig. 6D, Table 1 of (Kiritani et al., 2012)
    connweights[EB5,ER6,AMPA]=0# ruled out based on Ben and Gordon conversation
    connweights[EB5,IL5,AMPA]=0 # ruled out by (Apicella et al., 2012) Fig. 7
    connweights[EB5,IF5,AMPA]=0.23#(Apicella et al., 2012) Fig. 7F (weight = 1/2 x weight for ER5->IF5)
    connweights[ER5,ER2,AMPA]=0.66
    connweights[ER5,EB5,AMPA]=0.66
    connweights[ER5,ER5,AMPA]=0.66
    connweights[ER5,ER6,AMPA]=0.66
    connweights[ER5,IL5,AMPA]=0# ruled out by (Apicella et al., 2012) Fig. 7
    connweights[ER5,IF5,AMPA]=0.46# (Apicella et al., 2012) Fig. 7E (weight = 2 x weight for EB5->IF5)
    connweights[ER6,ER2,AMPA]=0
    connweights[ER6,EB5,AMPA]=0.66
    connweights[ER6,ER5,AMPA]=0.66
    connweights[ER6,ER6,AMPA]=0.66
    connweights[ER6,IL6,AMPA]=0.23
    connweights[ER6,IF6,AMPA]=0.23
    connweights[IL2,ER2,GABAB]=0.83
    connweights[IL2,IL2,GABAB]=1.5
    connweights[IL2,IF2,GABAB]=1.5
    connweights[IF2,ER2,GABAA]=1.5
    connweights[IF2,IL2,GABAA]=1.5
    connweights[IF2,IF2,GABAA]=1.5
    connweights[IL5,EB5,GABAB]=0.83
    connweights[IL5,ER5,GABAB]=0.83
    connweights[IL5,IL5,GABAB]=1.5
    connweights[IL5,IF5,GABAB]=1.5
    connweights[IF5,EB5,GABAA]=1.5
    connweights[IF5,ER5,GABAA]=1.5
    connweights[IF5,IL5,GABAA]=1.5
    connweights[IF5,IF5,GABAA]=1.5
    connweights[IL6,ER6,GABAB]=0.83
    connweights[IL6,IL6,GABAB]=1.5
    connweights[IL6,IF6,GABAB]=1.5
    connweights[IF6,ER6,GABAA]=1.5
    connweights[IF6,IL6,GABAA]=1.5
    connweights[IF6,IF6,GABAA]=1.5
    return connweights

## For diagnostic purposes -- plot connectivity. Based on conndiagram.py.
def plotconnectivity():
    from pylab import figure, axes, shape, size, imshow, colorbar, clim, hold, plot, xlim, ylim
    from bicolormap import bicolormap

    # Create plot
    figh = figure(figsize=(8,6))
    figh.subplots_adjust(left=0.02) # Less space on left
    figh.subplots_adjust(right=0.98) # Less space on right
    figh.subplots_adjust(top=0.96) # Less space on bottom
    figh.subplots_adjust(bottom=0.02) # Less space on bottom
    figh.subplots_adjust(wspace=0) # More space between
    figh.subplots_adjust(hspace=0) # More space between
    h = axes()
    connprobs = setconnprobs()
    connweights = setconnweights()
    totalconns = zeros(shape(connprobs))
    for c1 in range(size(connprobs,0)):
        for c2 in range(size(connprobs,1)):
            for w in range(nreceptors):
                totalconns[c1,c2] += connprobs[c1,c2]*connweights[c1,c2,w]*(-1 if w>=2 else 1)
    imshow(totalconns,interpolation='none',cmap=bicolormap(gap=0))

    # Plot grid lines
    hold(True)
    for p in range(npops):
        plot(array([0,npops])-0.5,array([p,p])-0.5,'-',c=(0.7,0.7,0.7))
        plot(array([p,p])-0.5,array([0,npops])-0.5,'-',c=(0.7,0.7,0.7))

    # Make pretty
    h.set_xticks(range(npops))
    h.set_yticks(range(npops))
    h.set_xticklabels(popnames)
    h.set_yticklabels(popnames)
    h.xaxis.set_ticks_position('top')
    xlim(-0.5,npops-0.5)
    ylim(npops-0.5,-0.5)
    clim(-abs(totalconns).max(),abs(totalconns).max())
    colorbar()

    return totalconns
