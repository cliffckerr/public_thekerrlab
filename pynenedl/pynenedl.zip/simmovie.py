"""
SIMMOVIE

Make a movie of a simulation.

Version: 2014feb24
"""

from scipy.io import loadmat
from pylab import figure, array, size, zeros, subplot, ion, show, pause, hold, sum
from os import system
from time import time

## Set options
filename='../data/opto-with-conns.mat'
maxframes = 1000 # Maximum number of non-movie frames
starttime = 2.5 # Time in seconds to start at
endtime = 4.5 # Time in seconds to end at
binsize = 10 # Bin size in ms
figsize = [1280,720] # Figure size in pixels
recalculate = True # Whether or not to rebin spikes
dosave = True
if dosave:
    moviedir='../data/movies/'
    moviename='02-optostimtest7.mpg'
    maxmovieframes = 1e4 # Maximum number of movie frames

## Initialize
print('Initializing...')
data = loadmat(filename)
xlocs = data['xlocs'].flatten()/1e3 # Convert to mm
ylocs = data['ylocs'].flatten()/1e3
EorI = data['EorI'].flatten()
spikedata = data['spikedata']
ncells = len(xlocs)
xmax = round(xlocs.max())
ymax = round(ylocs.max())
tmax = spikedata[:,1].max()
totalspikes = size(spikedata,0)


print('Calculating spike bins (estimated time: %0.1f s)...' % (float(totalspikes)/4e5)) 
tick = time()
nbins = int(tmax/binsize)+1 # Calculate number of bins; +1 for edge effects
spikecounts=zeros((ncells,nbins)) # Number of spike counts
timebins = array(range(nbins))*binsize/1e3 # Calculate time bins
spikecells = spikedata[:,0] # Pull out cell IDs
spikebins = array(spikedata[:,1]/binsize,dtype=int) # Convert times to bins
for s in range(totalspikes): # Loop over each spike
    spikecounts[spikecells[s],spikebins[s]] += 1 # Increment this bin
spikingrate = sum(spikecounts,axis=0)*1e3/binsize/ncells # Get the total spike counts over time

print('Plotting...')
def makeplot():
    EorIcolors = array([(1,0.4,0) , (0,0.2,0.8)]) # Define excitatory and inhibitory colors -- orange and turquoise
    ion()
    fig = figure(figsize=(figsize[0]/100,figsize[1]/100),dpi=100)
    fig.subplots_adjust(left=0.05) # Less space on left
    fig.subplots_adjust(right=0.98) # Less space on right
    fig.subplots_adjust(bottom=0.08) # Less space on bottom
    fig.subplots_adjust(wspace=0.25) # More space between
    fig.subplots_adjust(hspace=0.30) # More space between
    raster = subplot(1,2,1)
    posplot = subplot(2,2,2)
    barplot = subplot(2,2,4)
    maxspikes = 5*sum(spikecounts,axis=0).mean() # Find out the maximum number of spikes in any given timestep
    maxiters = min(int(len(timebins)),int(endtime*1e3/binsize)) # See how many iterations to go for
    pastfired = []
    
    for b in range(int(starttime*1e3/binsize),maxiters):
        fired = array(spikecounts[:,b]>0).flatten() # Find which neurons fired in this timestep
        print('  bin = %i of %i; %i spikes' % (b, maxiters, sum(fired)))
        efired = (fired * (EorI==0)) # Perform logical and
        ifired = (fired * (EorI==1)) # Perform logical and
        numefired = sum(efired) # Number of E cells that fired
        numifired = sum(ifired) # Number of I cells that fired
        numfired = numefired+numifired # Total number of cells that fired
        
        raster.cla()
        
        # Show previous cells that fired
        maxprevioussteps = 10
        numtoplot = min(len(pastfired),maxprevioussteps)
        for p in range(numtoplot):
            past = numtoplot-p
            pfired = pastfired[-past]
            pefired = (pfired * (EorI==0)) # Perform logical and
            pifired = (pfired * (EorI==1)) # Perform logical and
            pnumefired = sum(pefired) # Number of E cells that fired
            pnumifired = sum(pifired) # Number of I cells that fired
            if pnumefired: raster.scatter(xlocs[pefired],ylocs[pefired],c=pnumefired*[(EorIcolors[0]+1+past)/(2+past)],linewidth=0)
            if pnumifired: raster.scatter(xlocs[pifired],ylocs[pifired],c=pnumifired*[(EorIcolors[1]+1+past)/(2+past)],linewidth=0)
            
            
        if numefired: raster.scatter(xlocs[efired],ylocs[efired],c=numefired*[EorIcolors[0]],linewidth=0)
        if numifired: raster.scatter(xlocs[ifired],ylocs[ifired],c=numifired*[EorIcolors[1]],linewidth=0)
        
        
        raster.set_xlabel('X position (mm)')
        raster.set_ylabel('Y position (mm)')
        raster.set_title('t = %0.3f s' % timebins[b])
        raster.set_xlim(0,xmax)
        raster.set_ylim(0,ymax)
    
        posplot.cla(); 
        hold(True)
        posplot.plot(timebins[:maxiters],spikingrate[:maxiters])
        posplot.plot([timebins[b]]*2,[0,spikingrate.max()],'k',linewidth=0.5)
        posplot.set_xlabel('Time (s)')
        posplot.set_ylabel('Firing rate (Hz)')
        posplot.set_title('Firing rate = %0.2f Hz' % spikingrate[b])
        posplot.set_xlim(0,timebins[maxiters-1])
        posplot.set_ylim(0,spikingrate.max())
        
        barplot.cla()
        barplot.bar([0.25,1.25],[numefired,numifired],width=0.5,color=EorIcolors)
        barplot.set_xticks(array([0,1])+0.5)
        barplot.set_xticklabels(('Excitatory','Inhibitory'))
        barplot.set_ylabel('Spikes')
        barplot.set_xlim(0,2)
        barplot.set_ylim(0,maxspikes)
        barplot.set_title('E = %i | I = %i | total spikes = %i' % (numefired, numifired, numfired))
        show()
        pause(0.001)
        pastfired.append(fired)
        
        if dosave: fig.savefig('tmpmovie%04i.png' % b) # Save PNG files for movie
makeplot()

if dosave:
    print('Making movie...')
    system('mkdir -p ' + moviedir)
    system("mencoder 'mf://tmpmovie*.png' -mf type=png:fps=10 -ovc lavc -lavcopts vcodec=wmv2 -oac copy -o %s" % (moviedir+moviename))
    print('  Cleaning up...')
    system('rm tmpmovie*.png')

print('Done.')
